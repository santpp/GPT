const CACHE="agora-shell-0.7.0-f7b45dcb343a68de";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-f7b45dcb343a68de/agora-logo.svg", "/assets/release-f7b45dcb343a68de/app.css", "/assets/release-f7b45dcb343a68de/app.js", "/assets/release-f7b45dcb343a68de/demo.js", "/assets/release-f7b45dcb343a68de/icon.svg", "/assets/release-f7b45dcb343a68de/integrations.js", "/assets/release-f7b45dcb343a68de/layout.css", "/assets/release-f7b45dcb343a68de/live-inbox.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
