# Agora Digital App · 1.1.1

> **1.1.1:** se devuelve la imagen de Ágora (letra Author, texto negro y más grande, sin vidrio, puntos ni cápsulas de color), el canal de origen se ve de un vistazo y se corrigen dos fallos. Lee `REVISION.md`. Lo demás de este archivo sigue valiendo.

Un solo sistema para toda la operación comercial: el CRM que viene de Go High Level, los
convenios de pago, las tareas del equipo y la trazabilidad de cada contacto. La estructura
visual y la navegación son las del Tablero Comercial v3, con la barra de vidrio esmerilado
del sistema.

Los servidores no cambian de sitio: no hay migraciones ni cambios en la base de datos. Lo
que sí hace falta para las pantallas nuevas son nueve rutas más, documentadas una por una
en `construccion/API.md`.

---

## Qué hay dentro

```
public_html/            lo que se sube al servidor
  index.html            la única página: el sistema decide qué módulo enseñar
  manifest.webmanifest  para instalarla como aplicación
  sw.js                 avisos (push) y apertura de la conversación al tocarlos
  version.json
  .htaccess             qué direcciones cargan la página
  assets/
    sistema.css         el sistema de diseño, sin tocar
    modulos.css         la capa que viste los módulos heredados y lo nuevo
    config.js           ►► lo único que hay que editar al instalar ◄◄
    agora-app.js        el armazón, los módulos propios y las rutas
    agora-modulos.js    los módulos que venían de Ágora, empaquetados
    demo.js             datos de prueba (no se carga desde index.html)
    manual/, icons/, imágenes

prueba.html             el archivo de pruebas: ábrelo con doble clic
construccion/
  API.md                ►► lo que el servidor tiene que responder ◄◄
  LEEME-construccion.md cómo se arma el paquete
  …                     los parches y las pruebas
capturas/               cómo quedó cada pantalla
```

---

## La barra de arriba

De izquierda a derecha, igual que el ecosistema:

- **La marca** y, detrás de la barra inclinada, **el módulo en uso** con su contador. Se
  pulsa y abre el menú completo de módulos, en dos columnas y por grupos.
- **El logo del cliente**, que sube el SuperAdmin, y la **subcuenta** cuando hay más de una.
- **El periodo** en el centro: el mes anterior, el de ahora (con su punto verde) y el que
  viene. Gobierna el Resumen y la Auditoría.
- A la derecha: **historial** de lo último que viste, **Buscar (⌘K)**, **Athena**, los
  accesos de **Inicio**, **Ajustes** y **Auditoría**, el **estado del espacio**
  (Activa o Bloqueada), el **tema** y tu **cuenta**.

La barra deja pasar lo que hay debajo y lo desenfoca, como la de un iPhone. Donde el
navegador no sabe desenfocar, se queda opaca y se ve igual de bien.

---

## Los módulos

| Grupo | Módulo | Qué hace |
|---|---|---|
| **Operación** | **Resumen** | El pulso del negocio: ingreso recurrente, resultado, caja y lo que viene. |
| | **ARP Comercial** | Las cifras del día, el tiempo de respuesta, los anuncios y la rentabilidad. |
| | **Bandeja de conversaciones** | Todos los canales en una lista, con recordatorios de seguimiento. |
| | **Contactos** | Las fichas de la subcuenta, con su historial y sus etiquetas. |
| | **Oportunidades** | Los embudos por etapa y las ventas ganadas. |
| | **Tareas** | Lo que cada ejecutivo tiene por delante. |
| **Contratos** | **Contratos** · **Con convenio** · **Registro** | Los convenios de pago, de principio a fin. |
| **Administración** | **Auditoría** | Quién tocó qué contacto, qué cambió, cuándo y desde dónde. |
| | **Usuarios y roles** | Quién entra, con qué rol, y la identidad del espacio. |
| | **Ajustes** · **Ayuda** | Cuentas conectadas, equipo importado, avisos y manual. |

### Direcciones

`/inicio` · `/comercial` · `/bandeja` · `/contactos` · `/oportunidades` · `/tareas` ·
`/contratos` (y `/contratos/nuevo`, `/contratos/{uid}`) · `/con-convenio` · `/registro` ·
`/auditoria` · `/usuarios` · `/ajustes` · `/ayuda` · `/conversations/{id}`.

Las de antes siguen valiendo: `/tablero` y `/conexiones` llevan a ARP Comercial y a
Ajustes. La única que se movió de verdad es la de Contactos del panel de Contratos, que
ahora es `/con-convenio` y se llama **Con convenio**, porque `/contactos` ya era del CRM.

### Atajos

`1`–`9` y `0` abren los módulos en orden · `M` abre el menú de módulos · `J` llama a
Athena · `N` nuevo convenio · `/` busca dentro de la vista · `D` cambia el tema · `?`
muestra la lista · `Esc` cierra.

---

## Lo que se midió, pantalla por pantalla

**Resumen.** Ingreso recurrente del mes con su variación, la línea de los últimos seis
meses, y seis cifras: recaudado, recurrente anual, saldo de caja, clientes activos,
clientes en baja y egresos. Debajo, los espacios atendidos con su logo, quiénes responden
por el sistema y los cobros por vencer.

**ARP Comercial.** Sobre lo que ya traía (leads del día, embudo por etapa y rentabilidad
del mes) se agregaron tres bloques:

- **Operación del día.** El **tiempo de respuesta promedio (SLA)** con su meta y su
  semáforo, cuántas conversaciones se salieron de la meta, las que están sin leer, los
  leads del día y la primera respuesta más lenta. Y tres ruedas: sin leer por asesor,
  fuente de los leads y leads por ejecutivo.
- **Inversión en anuncios.** Lo invertido hoy, **cuánto va gastado en el mes**, el avance
  del presupuesto, impresiones, coste por conversión, coste por lead, retorno por cada
  cien y las campañas que más consumen. Cuando la conexión con Meta vence, el bloque lo
  dice y manda a Ajustes en vez de quedarse en blanco.
- **Desempeño del equipo.** La tabla del mes suma los **leads asignados a cada
  ejecutivo** y su **tasa de conversión**, que sale sola de ahí: cierres entre leads. El
  total del equipo usa la suma de los dos, no el promedio de los porcentajes.
- **Eficacia de ventas.** El **tiempo de cierre promedio** frente a su meta, el valor
  cerrado, la velocidad de venta, el ticket promedio y la tasa de cierre, con filtro por
  embudo y por ejecutivo, y la tabla de quién cierra más rápido.

**Bandeja.** En cada chat hay un botón de **recordatorio**: se elige el día y la hora en
que hay que volver a escribir (o se usa un atajo: esta tarde, mañana, en 3 días, la
semana que viene). Queda la tarea a tu nombre, el chat se marca y **se va de primero en
la lista** hasta que mandas el mensaje; al mandarlo, el recordatorio se cumple solo.

**Tareas.** Para hoy, vencidas, abiertas y hechas; filtro por responsable; y desde cada
tarea se abre el chat del contacto.

**Auditoría.** Movimientos del periodo con quién, qué hizo, sobre qué contacto, desde qué
equipo y con qué dirección IP. El detalle enseña qué valor había antes y cuál quedó. Se
exporta a un archivo que abre cualquier hoja de cálculo.

**Usuarios y roles.** Cinco roles —SuperAdmin, Administración, Supervisión, Ejecutivo y
Consulta— con la matriz de lo que abre cada uno. Desde aquí se agrega gente, se cambia el
rol y se desactiva. El SuperAdmin sube además **el logo del cliente**, que sale en la
barra y en su pantalla de inicio.

**Athena.** El agente vive en la barra y responde sobre lo que el sistema ya tiene
cargado: cómo va el mes, quién tiene conversaciones sin leer, cuánto llevas gastado en
anuncios, qué convenios están por firmar. Hoy lee del tablero, sin salir a internet;
cuando el servidor exponga el agente, se cambia una sola función.

---

## Probarlo

Abre **`prueba.html`** con doble clic. No hace falta servidor ni internet: lleva todo
dentro y responde las dos APIs con datos inventados, con la misma forma que los de verdad.
Lo que escribas se olvida al recargar.

Vale la pena recorrer: el menú de módulos, el cambio de mes en el Resumen, el bloque de
anuncios y el de eficacia en ARP Comercial, poner un recordatorio en un chat y verlo
aparecer en Tareas, el detalle de un movimiento en Auditoría, subir un logo en Usuarios y
roles, y preguntarle algo a Athena.

---

## Instalarlo

1. **Edita `assets/config.js`**: la dirección de cada API.

   - En el mismo dominio: `AGORA_API = '/api/'` y `CONTRATOS_API = '/api/'`. Las rutas no
     chocan hoy: el CRM usa `/api/me`, `/api/workspace/…` y `/api/admin/…`; Contratos usa
     `/api/yo`, `/api/contratos`, `/api/usuarios`, `/api/registro` y `/api/ghl/…`.
   - En dominios distintos: pon la dirección completa de cada uno. Las sesiones van por
     cookie, así que cada servidor debe permitir el origen de esta página (CORS con
     credenciales) y marcar sus cookies `SameSite=None; Secure`. Si eso no se puede tocar,
     pon los dos detrás del mismo dominio con un proxy.

2. **Sube `public_html/`** sobre la carpeta pública. Puedes borrar lo que ya no se usa:
   `assets/release-cfd2864ac360cd90/`, `conexiones.html` y los archivos sueltos del panel
   anterior (`panel.html`, `panel.css`, `panel.js`).

3. **Revisa el `.htaccess`**: trae todas las direcciones. Si tu servidor no es Apache ni
   OpenLiteSpeed, la regla es: `/api/…` entra en PHP y todo lo demás carga `index.html`.

4. **Monta las rutas nuevas** siguiendo `construccion/API.md`. Mientras no estén, esos
   módulos enseñan su estado vacío y el resto del sistema funciona igual.

5. **Entra y recarga con Ctrl+Mayús+R.**

`router.php` y `agora-private/` no vienen en el paquete a propósito: no cambian. Sigue
usando los que ya tienes y agrégales las rutas del punto 4.

---

## Lo que conviene saber

- **El trabajador de servicio** es el de siempre con la caché renombrada: los avisos y la
  apertura de la conversación al tocarlos siguen igual. La caché vieja se borra sola.
- **La pantalla de mantenimiento** sigue puesta. El estado de la barra (Activa o
  Bloqueada) la enciende y la apaga, y solo quien administra puede cambiarlo.
- **Pendiente de traer:** el tutorial de primeros pasos, la huella o Face ID y la
  invitación a instalar la aplicación eran de la cáscara anterior y no están en esta
  versión. El acceso con código al correo y el de administración sí.
- **Las capturas del manual** todavía muestran las pantallas de antes: hay que volver a
  tomarlas cuando el sistema esté arriba.
- **Los roles nuevos** (SuperAdmin y Supervisión) hay que aplicarlos también en el
  servidor: lo que decide el navegador solo acomoda la pantalla.

---

## Cómo se armó

Los módulos del panel de Contratos no se reescribieron: `construccion/parches.py` toma su
archivo original y sustituye solo el armazón, de modo que se ve exactamente qué cambió.
Los módulos que venían de Ágora se empaquetan con esbuild y llevan dos parches, en
`construccion/parches-agora.py`: el tablero suma los bloques nuevos y la bandeja suma los
recordatorios.

```bash
cd construccion
python3 parches-agora.py     # los dos cambios a los módulos heredados
npx esbuild entry.js --bundle --format=iife --target=es2021 \
  --outfile=../public_html/assets/agora-modulos.js --charset=utf8
python3 parches.py           # construye assets/agora-app.js
python3 prueba.py            # construye prueba.html
node verificar.js            # recorre los módulos en un navegador y captura
node interactuar.js          # abre un chat, pone un recordatorio, filtra, cambia de mes
```

La última corrida pasó por los trece módulos, el tema oscuro, el celular, el menú, la
paleta, Athena y los flujos hondos: **sin errores de consola**.
