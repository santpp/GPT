# Lo que el servidor tiene que responder

Agora Digital App no habla con Go High Level ni con Meta desde el navegador: habla con tu
servidor, y tu servidor es quien va a buscar los datos. Así la clave de la cuenta nunca
sale del servidor y una pantalla abierta no gasta la cuota de la API.

Las rutas que ya existían (`me`, `workspace/inbox`, `workspace/contacts`,
`workspace/board`, `workspace/won`, `admin/…`, y las de Contratos) **no cambian**. Aquí
están solo las nuevas, con la forma exacta que el sistema espera. Mientras no existan, el
archivo de pruebas las responde con datos inventados y los módulos funcionan igual.

Todas cuelgan de la base de Ágora (`window.AGORA_API`, normalmente `/api/`). Las que
escriben llevan la cabecera `X-CSRF-Token`, como el resto.

---

## 1 · Resumen del negocio

```
GET  workspace/resumen?period=YYYY-MM
```

El pulso del negocio de Agora Digital App: lo que cobras por el servicio. Solo para
SuperAdmin.

```jsonc
{
  "mrr": 285,                  // ingreso recurrente al cierre del mes
  "mrrAnterior": 285,          // el mismo dato del mes pasado, para la variación
  "clientesActivos": 1,
  "enPausa": 0,
  "recaudado": 0,              // cobrado en el mes, con IVA
  "arr": 3420,                 // mrr × 12
  "caja": -783,                // cobros − egresos
  "churn": 0,                  // clientes que se dieron de baja en el mes
  "churnPct": 0,               // sobre la cartera al inicio del mes (0 a 1)
  "egresos": 20,
  "inversion": 0,              // parte de los egresos que fue inversión
  "serie": [{"ym": "2026-06", "v": 0}, {"ym": "2026-07", "v": 0}],   // seis meses, para la línea
  "espacios": [{"id": 1, "nombre": "ASOCIM", "logo": "https://…/logo.png", "plan": "Plan Operación", "mrr": 285, "estado": "activo"}],
  "superadmins": [{"id": 1, "nombre": "Eduardo Bocaranda", "correo": "info@agoradigital.app"}],
  "porVencer": [{"cliente": "ASOCIM", "monto": 285, "vence": "2026-11-30", "estado": "pendiente"}]
}
```

`estado` de un espacio: `activo`, `pausa` o `baja`.

---

## 2 · Operación del día

```
GET  workspace/dia?connectionId=1&date=YYYY-MM-DD&period=YYYY-MM
```

Lo que está esperando respuesta ahora y de dónde viene. Sale de las conversaciones de la
subcuenta en Go High Level.

```jsonc
{
  "conversacionesDia": 14,     // abiertas hoy
  "atendidas": 9,
  "sinLeer": 5,
  "sinLeerAyer": 14,           // para la comparación
  "sinLeerPorAsesor": [{"nombre": "Lisbella Montilla", "n": 3}],
  "slaIncumplido": 4,          // pasaron la meta sin primera respuesta
  "slaIncumplidoAyer": 43,
  "slaTolerancia": 3,          // a partir de aquí el semáforo se pone rojo
  "slaPromedio": "3 min 12 s", // ya formateado, para mostrarlo tal cual
  "slaPromedioSeg": 192,       // el mismo dato en segundos, para comparar
  "slaPromedioSegAyer": 420,
  "slaMetaTexto": "5 min",
  "peorRespuesta": "18 min",
  "peorAsesor": "María Carvajal",
  "leads": 4,
  "leadsAyer": 27,
  "leadsPorFuente": [{"fuente": "Redes sociales", "n": 4}],
  "leadsPorUsuario": [{"nombre": "Lisbella Montilla", "n": 2}]
}
```

**Cómo se calcula el SLA.** Por cada conversación con un mensaje entrante del día: el
tiempo entre ese mensaje y la primera respuesta saliente. Si todavía no hay respuesta,
cuenta el tiempo transcurrido. «Incumplido» es el que pasó de la meta. En Go High Level
sale de `conversations/{id}/messages` ordenado por `dateAdded`, mirando `direction`.

---

## 3 · Inversión en anuncios (Meta)

```
GET  workspace/ads?connectionId=1&period=YYYY-MM&date=YYYY-MM-DD
```

```jsonc
{
  "estado": "ok",              // ok · expired · not_connected · permission
  "dia": 18.40,                // invertido hoy
  "diaAyer": 23.15,
  "mes": 412.75,               // cuánto va gastado en el mes
  "presupuestoMes": 600,       // opcional; si viene, se dibuja el avance
  "impresiones": 12480,
  "clics": 311,
  "conversiones": 9,
  "costePorConversion": 45.86,
  "costePorLead": 4.60,
  "retornoPorCien": 69.10,     // vendido entre invertido, por cien
  "actualizado": "hace 20 minutos",
  "campanas": [{"nombre": "Diplomado · Captación", "gasto": 210.40, "conversiones": 5}]
}
```

Con `estado` distinto de `ok`, el módulo enseña por qué y manda a Ajustes; no hace falta
enviar las cifras. Eso cubre el caso de la captura: **la conexión vencida**.

De la Marketing API de Meta: `act_{id}/insights` con `time_range` del día y del mes,
campos `spend`, `impressions`, `clicks`, `actions`; y `level=campaign` para las campañas.

---

## 4 · Eficacia de ventas

```
GET  workspace/eficacia?connectionId=1&period=YYYY-MM&pipelineId=&userId=
```

El tiempo de cierre, que es el parámetro de eficiencia que se quiere vigilar.

```jsonc
{
  "pipelineId": "", "userId": "",
  "pipelines": [{"id": "pl_1", "nombre": "Admisiones 2026"}],
  "usuarios": [{"id": "us_1", "nombre": "Lisbella Montilla"}],
  "duracionPromedioDias": 11,
  "duracionTexto": "11 días",
  "metaDias": 10,              // la meta; si falta, no se dibuja el semáforo
  "valorTotal": 13260,
  "cerradas": 9,
  "ticket": 1473,
  "velocidad": 36164,          // valor que entra al mes con el ritmo actual
  "tasaCierre": 27,            // porcentaje de las oportunidades trabajadas
  "porUsuario": [{"nombre": "Lisbella Montilla", "cerradas": 4, "valor": 6240, "dias": 8}]
}
```

**Cómo se calcula el tiempo de cierre.** Por cada oportunidad ganada en el periodo, los
días entre `dateAdded` y la fecha en que pasó a `won`. El promedio se pondera por número
de cierres, no por oportunidad.

---

## 4 bis · Desempeño del equipo: leads y conversión

La tabla de desempeño del mes (en `workspace/board-month`, que ya existe) necesita un
campo más en cada fila del equipo:

```jsonc
"team": [{
  "id": "us_01", "name": "Lisbella Montilla",
  "leads": 14,              // ← nuevo: leads que se le asignaron dentro del mes
  "closings": 3,
  "goal": 5000, "sold": 5200, "difference": 200, "progress": 104, "state": "lograda"
}]
```

Con eso el sistema calcula solo la **tasa de conversión** de cada quien —cierres entre
leads asignados, por cien— y la del equipo completo, que usa la suma de los dos totales y
no el promedio de los porcentajes (promediar porcentajes de bases distintas da un número
que no significa nada).

Un lead cuenta en el mes en que **se asignó**, no en el que entró: así la conversión
compara contra lo que esa persona realmente tuvo en la mano ese mes. En Go High Level
sale de `contacts/` con `assignedTo` y la fecha de asignación.

Si el campo no viene, las dos columnas quedan con una raya y el resto de la tabla
funciona igual.

---

## 5 · Tareas

```
GET   workspace/tareas?period=YYYY-MM&usuario=
POST  workspace/tareas
POST  workspace/tareas/{id}/estado
```

```jsonc
// GET
{
  "items": [{
    "id": "tk_101",
    "titulo": "Llamar a Mariana para cerrar la inscripción",
    "detalle": "Pidió el convenio por WhatsApp",
    "responsable": "Lisbella Montilla",
    "vence": "2026-11-03", "hora": "14:30",
    "estado": "pendiente",            // pendiente · hecha
    "origen": "recordatorio",         // recordatorio · manual · sistema · convenio
    "contacto": "Mariana Pérez Alvarado",
    "contactId": "ct_7001",
    "conversationId": "cv_1001"
  }],
  "resumen": {"pendientes": 7, "hechas": 1}
}

// POST workspace/tareas
{"titulo": "…", "detalle": "…", "vence": "2026-11-05", "hora": "09:00",
 "responsable": "…", "origen": "manual", "contactId": null, "conversationId": null}

// POST workspace/tareas/{id}/estado
{"estado": "hecha"}
```

---

## 6 · Recordatorios de seguimiento

```
POST    workspace/reminders?connectionId=1&conversationId=cv_1001
DELETE  workspace/reminders?connectionId=1&conversationId=cv_1001
```

```jsonc
// POST
{"at": "2026-11-04T09:00", "nota": "Quedó en confirmar con su esposo",
 "contactId": "ct_7002", "contactName": "Luis Alberto Ramírez"}
// respuesta
{"at": "2026-11-04T09:00"}
```

El servidor hace tres cosas con un recordatorio:

1. lo guarda contra la conversación;
2. **crea la tarea** del punto 5, con `origen: "recordatorio"` y la misma fecha y hora;
3. lo devuelve en la bandeja, para que la conversación se ponga de primera.

```
GET workspace/inbox?… → { …, "reminders": {"cv_1001": {"at": "2026-11-04T09:00", "nota": "…"}} }
```

El recordatorio se cumple solo: cuando se manda un mensaje en esa conversación, el
servidor lo cierra y cierra su tarea. El sistema ya lo quita de la lista al enviar.

---

## 7 · Auditoría

```
GET  workspace/auditoria?period=YYYY-MM&modulo=&usuario=&contacto=
```

La trazabilidad. Esto **no se borra ni se edita**: solo se agrega.

```jsonc
{
  "items": [{
    "id": "a1",
    "at": "2026-11-03T11:44:00Z",
    "actor": "Lisbella Montilla", "rol": "Ejecutivo",
    "accion": "edito",                       // creo · edito · elimino · envio · firmo · entro · salio · asigno · exporto · bloqueo
    "accionTexto": "Editó la ficha",         // en palabras, para la tabla
    "modulo": "contacto",                    // contacto · conversacion · oportunidad · convenio · usuario · ajuste · sesion
    "objeto": "Ficha del contacto",
    "contacto": "Mariana Pérez Alvarado", "contactId": "ct_7001",
    "dispositivo": "Chrome · Windows", "ip": "190.202.14.8",
    "origen": "sistema",                     // sistema · ghl (lo que entra por sincronización)
    "antes": {"telefono": "+58 412 1122334"},
    "despues": {"telefono": "+58 412 1122999"}
  }],
  "resumen": {"total": 12}
}
```

`antes` y `despues` son opcionales; cuando vienen, el detalle muestra la tabla de cambios.
Lo que entra desde Go High Level se marca con `origen: "ghl"` y `actor: "Sincronización"`,
para que se distinga de lo que hizo una persona.

---

## 8 · Usuarios y roles

```
GET   workspace/usuarios
POST  workspace/usuarios
POST  workspace/usuarios/rol
POST  workspace/usuarios/estado
```

```jsonc
// GET: la lista única, venga de donde venga
{"items": [{
  "id": "us_1", "nombre": "Eduardo Bocaranda", "correo": "info@agoradigital.app",
  "rol": "SUPERADMIN",                 // SUPERADMIN · ADMIN · SUPERVISOR · EJECUTIVO · CONSULTA
  "estado": "activo",                  // activo · inactivo
  "origen": "sistema",                 // sistema · contratos · ghl
  "ultimoAcceso": "2026-11-03T11:50:00Z",
  "yo": true                           // opcional: marca a quien está mirando
}]}

// POST workspace/usuarios
{"nombre": "…", "correo": "…", "clave": "…", "rol": "EJECUTIVO"}
// POST workspace/usuarios/rol     → {"id": "us_3", "rol": "SUPERVISOR"}
// POST workspace/usuarios/estado  → {"id": "us_3", "estado": "inactivo"}
```

El equipo que viene de Go High Level se devuelve con `origen: "ghl"`: se ve, pero no se
edita desde aquí (se edita en la cuenta de origen y entra por sincronización).

**Los cinco roles y lo que abren** están en la matriz del módulo; el servidor debe aplicar
la misma regla, porque la del navegador solo acomoda la pantalla.

---

## 9 · Identidad del espacio

```
GET   workspace/branding
POST  workspace/branding
```

```jsonc
{"nombre": "ASOCIM", "logo": "https://…/logo.png", "bloqueado": false}
```

El `POST` recibe `{"nombre": "…", "logo": "data:image/png;base64,…"}` o `logo: null` para
quitarlo. El servidor lo guarda como archivo y devuelve la dirección. Solo SuperAdmin.

El logo sale en la barra, al lado del módulo, y en el Resumen. `bloqueado` es el estado
que enseña la barra y lo cambia `POST admin/maintenance {"on": true}`, que ya existe.

---

## Cómo entra Go High Level

El servidor ya tiene `GhlClient.php` y el resto de la capa. Lo nuevo se apoya en lo mismo:

| Lo que se muestra | De dónde sale en Go High Level |
|---|---|
| Conversaciones, sin leer, SLA | `conversations/search` y `conversations/{id}/messages` |
| Leads del día y su fuente | `contacts/` filtrado por `dateAdded`, campo `source` |
| Leads por ejecutivo | `assignedTo` del contacto, cruzado con los usuarios de la subcuenta |
| Oportunidades y eficacia de cierre | `opportunities/search` con `status`, `dateAdded` y la fecha de cambio a ganada |
| Equipo | `users/` de la subcuenta (ya se importa) |
| Tareas y recordatorios | se guardan en la base de Ágora, no en Go High Level |
| Inversión y campañas | Marketing API de Meta, con la cuenta publicitaria conectada |

Dos consejos que ya valen para lo que existe: guarda en caché cada lectura el tiempo del
`sync_interval_seconds` de la subcuenta, y calcula el día completo una vez por minuto en
el cron en vez de al abrir la pantalla. Así la cuota de la cuenta rinde aunque todo el
equipo tenga el tablero abierto.
