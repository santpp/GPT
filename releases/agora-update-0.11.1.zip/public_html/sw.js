const CACHE="agora-shell-0.11.1-b4470cc049abc8fd";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-b4470cc049abc8fd/agora-logo.svg", "/assets/release-b4470cc049abc8fd/app.css", "/assets/release-b4470cc049abc8fd/app.js", "/assets/release-b4470cc049abc8fd/board.js", "/assets/release-b4470cc049abc8fd/contacts.js", "/assets/release-b4470cc049abc8fd/icon.svg", "/assets/release-b4470cc049abc8fd/integrations.js", "/assets/release-b4470cc049abc8fd/layout.css", "/assets/release-b4470cc049abc8fd/live-inbox.js", "/assets/release-b4470cc049abc8fd/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
