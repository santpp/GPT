<?php
// Datos de prueba para el arnés (se borran con el argumento "clean").
require getenv('AGORA_ROOT').'/src/bootstrap.php';
$tag='harness';
if(($argv[1]??'')==='clean'){
  $t=query('SELECT id FROM tenants WHERE location_id=?',['loc-'.$tag])->fetchColumn();
  if($t){foreach(['audit_log','workspace_tasks','workspace_branding'] as $x)query("DELETE FROM $x WHERE tenant_id=?",[$t]);query('DELETE FROM device_sessions WHERE tenant_id=?',[$t]);query('DELETE FROM ghl_connections WHERE tenant_id=?',[$t]);query('DELETE FROM users WHERE tenant_id=?',[$t]);query('DELETE FROM tenants WHERE id=?',[$t]);}
  echo "limpio\n";exit;
}
query('INSERT INTO tenants(name,location_id) VALUES(?,?)',['Agora Digital','loc-'.$tag]);$t=(int)db()->lastInsertId();
query("INSERT INTO users(tenant_id,email,password_hash,role,display_name,active) VALUES(?,?,?,'administrator',?,TRUE)",[$t,'owner@harness.test',password_hash('clave-de-prueba-123',PASSWORD_DEFAULT),'Eduardo Bocaranda']);
query("INSERT INTO ghl_connections(tenant_id,name,location_id,token_ciphertext,status) VALUES(?,?,?,?,'connected')",[$t,'ASOCIM · Admisiones','loc-ghl-'.$tag,'x']);$c=(int)db()->lastInsertId();
foreach([['ana','Lisbella Montilla'],['luis','María Carvajal']] as [$id,$name])query("INSERT INTO external_users(connection_id,external_user_id,email,display_name,permissions,scopes,active) VALUES(?,?,?,?,'{}','[]',1)",[$c,$id,$id.'@harness.test',$name]);
$now=time();
foreach([['cv1','ana','inbound',$now-120,2,'Mariana Pérez Alvarado'],['cv2','luis','inbound',$now-1500,1,'Luis Alberto Ramírez'],['cv3','ana','outbound',$now-600,0,'Carla Sofía Montes']] as [$id,$who,$dir,$at,$un,$name])
  query('INSERT INTO conversation_index(connection_id,conversation_id,payload,unread_count,assigned_to) VALUES(?,?,?,?,?)',[$c,$id,json_encode(['id'=>$id,'contactId'=>'ct'.$id,'contactName'=>$name,'locationId'=>'loc-ghl-'.$tag,'assignedTo'=>$who,'lastMessageDirection'=>$dir,'lastMessageDate'=>$at*1000,'unreadCount'=>$un,'lastMessageType'=>'TYPE_WHATSAPP','lastMessageBody'=>'Hola, quiero información']),$un,$who]);
$items=[];
foreach(query('SELECT payload FROM conversation_index WHERE connection_id=?',[$c])->fetchAll() as $r)$items[]=json_decode($r['payload'],true);
query('INSERT INTO ghl_inbox_snapshots(connection_id,payload,total,synced_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE payload=VALUES(payload),total=VALUES(total),synced_at=NOW()',[$c,json_encode($items),count($items)]);
require getenv('AGORA_ROOT').'/src/DemoSpace.php';DemoSpace::ensure($t);
echo "sembrado $t $c\n";
