const CACHE="agora-shell-1.8.6-68f44577b62093be";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-68f44577b62093be/agora-logo.png", "/assets/release-68f44577b62093be/agora-logo.svg", "/assets/release-68f44577b62093be/agora-mark.png", "/assets/release-68f44577b62093be/agora-mark.svg", "/assets/release-68f44577b62093be/announce.js", "/assets/release-68f44577b62093be/app.css", "/assets/release-68f44577b62093be/app.js", "/assets/release-68f44577b62093be/board.js", "/assets/release-68f44577b62093be/contact-editor.js", "/assets/release-68f44577b62093be/contacts.js", "/assets/release-68f44577b62093be/dark.css", "/assets/release-68f44577b62093be/dashboard.js", "/assets/release-68f44577b62093be/fonts/LEEME.txt", "/assets/release-68f44577b62093be/format.js", "/assets/release-68f44577b62093be/icon.svg", "/assets/release-68f44577b62093be/icons/apple-touch-icon.png", "/assets/release-68f44577b62093be/icons/badge-96.png", "/assets/release-68f44577b62093be/icons/favicon-180.png", "/assets/release-68f44577b62093be/icons/favicon-32.png", "/assets/release-68f44577b62093be/icons/favicon-48.png", "/assets/release-68f44577b62093be/icons/icon-192.png", "/assets/release-68f44577b62093be/icons/icon-512.png", "/assets/release-68f44577b62093be/icons/icon-maskable-512.png", "/assets/release-68f44577b62093be/integrations.js", "/assets/release-68f44577b62093be/layout.css", "/assets/release-68f44577b62093be/live-inbox.js", "/assets/release-68f44577b62093be/message-view.js", "/assets/release-68f44577b62093be/native.js", "/assets/release-68f44577b62093be/opportunity-editor.js", "/assets/release-68f44577b62093be/passkeys.js", "/assets/release-68f44577b62093be/push.js", "/assets/release-68f44577b62093be/skeleton.js", "/assets/release-68f44577b62093be/theme.js", "/assets/release-68f44577b62093be/won-alert.js", "/assets/release-68f44577b62093be/won.js", "/assets/release-68f44577b62093be/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{
 if(e.data?.type==='ACTIVATE')self.skipWaiting();
 // La app pregunta qué versión atiende los avisos, para notar si se quedó atrás.
 if(e.data?.type==='VERSION')e.ports?.[0]?.postMessage({cache:CACHE});
});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
// A notice arrives for a conversation: it is shown, and opening it goes to that
// conversation. Nothing of the message is stored by the worker.
self.addEventListener('push',event=>{
 let data={};
 try{data=event.data?event.data.json():{}}catch{data={}}
 // El aviso trae el título y el texto arriba; los datos de navegación van aparte.
 // Antes se leían los datos como si fueran el aviso y se perdía quién escribía.
 const source=data.notification&&typeof data.notification==='object'?data.notification:data;
 const title=typeof source.title==='string'&&source.title?source.title:'Ágora';
 const body=typeof source.body==='string'&&source.body?source.body:'Tienes un mensaje nuevo.';
 const path=typeof data.data?.path==='string'?data.data.path:'/bandeja';
 const safe=/^\/[A-Za-z0-9/_-]{0,120}$/.test(path)?path:'/bandeja';
 const unread=Number.isFinite(Number(data.unread))?Math.max(0,Number(data.unread)):null;
 const connection=/^\d{1,12}$/.test(String(data.data?.connectionId??''))?String(data.data.connectionId):'';
 event.waitUntil(Promise.all([
  self.registration.showNotification(title,{body,data:{path:safe,connection},tag:safe,renotify:true,icon:'/assets/icons/icon-192.png',badge:'/assets/icons/badge-96.png'}),
  // El número del icono donde el sistema lo permite (iPhone instalada, escritorio).
  unread!==null&&self.navigator?.setAppBadge?(unread>0?self.navigator.setAppBadge(unread):self.navigator.clearAppBadge()).catch(()=>{}):Promise.resolve(),
 ]));
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 const path=event.notification.data?.path||'/bandeja';
 const connection=/^\d{1,12}$/.test(String(event.notification.data?.connection??''))?event.notification.data.connection:'';
 // La dirección completa de Ágora, no sólo la ruta: así el sistema sabe a qué
 // app instalada pertenece y no la abre en una pestaña de Chrome.
 // Con la subcuenta del aviso, para abrir esa conversación y no otra.
 const target=new URL(path,self.location.origin).href+(connection&&path.startsWith('/conversations/')?'?c='+connection:'');
 event.waitUntil((async()=>{
  const open=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  const mine=open.filter(client=>new URL(client.url).origin===self.location.origin);
  // Si la app ya está abierta, se reutiliza esa ventana, en primer plano.
  for(const client of mine){
   try{const focused=await client.focus();await (focused||client).navigate(target);return}catch(error){}
  }
  await self.clients.openWindow(target);
 })());
});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
