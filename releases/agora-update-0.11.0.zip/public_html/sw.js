const CACHE="agora-shell-0.11.0-9a97536ae5f0757c";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-9a97536ae5f0757c/agora-logo.svg", "/assets/release-9a97536ae5f0757c/app.css", "/assets/release-9a97536ae5f0757c/app.js", "/assets/release-9a97536ae5f0757c/board.js", "/assets/release-9a97536ae5f0757c/contacts.js", "/assets/release-9a97536ae5f0757c/icon.svg", "/assets/release-9a97536ae5f0757c/integrations.js", "/assets/release-9a97536ae5f0757c/layout.css", "/assets/release-9a97536ae5f0757c/live-inbox.js", "/assets/release-9a97536ae5f0757c/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
