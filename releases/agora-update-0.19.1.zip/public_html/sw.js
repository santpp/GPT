const CACHE="agora-shell-0.19.1-d4335c1edb606f0e";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-d4335c1edb606f0e/agora-logo.svg", "/assets/release-d4335c1edb606f0e/app.css", "/assets/release-d4335c1edb606f0e/app.js", "/assets/release-d4335c1edb606f0e/board.js", "/assets/release-d4335c1edb606f0e/contact-editor.js", "/assets/release-d4335c1edb606f0e/contacts.js", "/assets/release-d4335c1edb606f0e/dashboard.js", "/assets/release-d4335c1edb606f0e/icon.svg", "/assets/release-d4335c1edb606f0e/integrations.js", "/assets/release-d4335c1edb606f0e/layout.css", "/assets/release-d4335c1edb606f0e/live-inbox.js", "/assets/release-d4335c1edb606f0e/native.js", "/assets/release-d4335c1edb606f0e/opportunity-editor.js", "/assets/release-d4335c1edb606f0e/push.js", "/assets/release-d4335c1edb606f0e/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
// A notice arrives for a conversation: it is shown, and opening it goes to that
// conversation. Nothing of the message is stored by the worker.
self.addEventListener('push',event=>{
 let data={};
 try{data=event.data?event.data.json():{}}catch{data={}}
 const payload=data.notification||data.data||data;
 const title=typeof payload.title==='string'&&payload.title?payload.title:'Ágora';
 const body=typeof payload.body==='string'?payload.body:'Tienes un mensaje nuevo.';
 const path=typeof (data.data?.path)==='string'?data.data.path:(typeof payload.path==='string'?payload.path:'/bandeja');
 const safe=/^\/[A-Za-z0-9/_-]{0,120}$/.test(path)?path:'/bandeja';
 event.waitUntil(self.registration.showNotification(title,{body,data:{path:safe},tag:safe,icon:'/assets/icon.svg',badge:'/assets/icon.svg'}));
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 const path=event.notification.data?.path||'/bandeja';
 event.waitUntil((async()=>{
  const open=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  for(const client of open){if(new URL(client.url).origin===self.location.origin){await client.focus();await client.navigate(path).catch(()=>{});return}}
  await self.clients.openWindow(path);
 })());
});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
