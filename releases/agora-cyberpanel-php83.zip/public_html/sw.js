const CACHE="agora-shell-0.17.0-c7fdbdb2031fa98c";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-c7fdbdb2031fa98c/agora-logo.svg", "/assets/release-c7fdbdb2031fa98c/app.css", "/assets/release-c7fdbdb2031fa98c/app.js", "/assets/release-c7fdbdb2031fa98c/board.js", "/assets/release-c7fdbdb2031fa98c/contact-editor.js", "/assets/release-c7fdbdb2031fa98c/contacts.js", "/assets/release-c7fdbdb2031fa98c/dashboard.js", "/assets/release-c7fdbdb2031fa98c/icon.svg", "/assets/release-c7fdbdb2031fa98c/integrations.js", "/assets/release-c7fdbdb2031fa98c/layout.css", "/assets/release-c7fdbdb2031fa98c/live-inbox.js", "/assets/release-c7fdbdb2031fa98c/opportunity-editor.js", "/assets/release-c7fdbdb2031fa98c/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
