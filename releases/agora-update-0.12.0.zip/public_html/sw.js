const CACHE="agora-shell-0.12.0-d462e33c1ad5303d";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-d462e33c1ad5303d/agora-logo.svg", "/assets/release-d462e33c1ad5303d/app.css", "/assets/release-d462e33c1ad5303d/app.js", "/assets/release-d462e33c1ad5303d/board.js", "/assets/release-d462e33c1ad5303d/contacts.js", "/assets/release-d462e33c1ad5303d/icon.svg", "/assets/release-d462e33c1ad5303d/integrations.js", "/assets/release-d462e33c1ad5303d/layout.css", "/assets/release-d462e33c1ad5303d/live-inbox.js", "/assets/release-d462e33c1ad5303d/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
