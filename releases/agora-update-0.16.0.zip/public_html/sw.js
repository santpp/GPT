const CACHE="agora-shell-0.16.0-346a53ee1b74c068";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-346a53ee1b74c068/agora-logo.svg", "/assets/release-346a53ee1b74c068/app.css", "/assets/release-346a53ee1b74c068/app.js", "/assets/release-346a53ee1b74c068/board.js", "/assets/release-346a53ee1b74c068/contact-editor.js", "/assets/release-346a53ee1b74c068/contacts.js", "/assets/release-346a53ee1b74c068/dashboard.js", "/assets/release-346a53ee1b74c068/icon.svg", "/assets/release-346a53ee1b74c068/integrations.js", "/assets/release-346a53ee1b74c068/layout.css", "/assets/release-346a53ee1b74c068/live-inbox.js", "/assets/release-346a53ee1b74c068/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
