const CACHE="agora-shell-0.13.0-f26146045d88c0ec";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-f26146045d88c0ec/agora-logo.svg", "/assets/release-f26146045d88c0ec/app.css", "/assets/release-f26146045d88c0ec/app.js", "/assets/release-f26146045d88c0ec/board.js", "/assets/release-f26146045d88c0ec/contacts.js", "/assets/release-f26146045d88c0ec/icon.svg", "/assets/release-f26146045d88c0ec/integrations.js", "/assets/release-f26146045d88c0ec/layout.css", "/assets/release-f26146045d88c0ec/live-inbox.js", "/assets/release-f26146045d88c0ec/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{if(e.data?.type==='ACTIVATE')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
