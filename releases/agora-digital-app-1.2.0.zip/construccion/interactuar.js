const {chromium}=require('playwright');const path=require('path');
const F='file://'+path.resolve(__dirname,'../prueba.html');const S=path.resolve(__dirname,'capturas');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:1440,height:980}});
const errs=[];p.on('pageerror',e=>errs.push('[página] '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('[consola] '+m.text())});
await p.goto(F,{waitUntil:'load'});await p.waitForTimeout(1400);

// Bandeja: abrir conversación y poner un recordatorio
await p.evaluate(()=>location.hash='#/bandeja');await p.waitForTimeout(1800);
await p.click('[data-live-id]');await p.waitForTimeout(1600);
await p.screenshot({path:path.join(S,'bandeja-abierta.png')});
await p.click('#live-recordar');await p.waitForTimeout(700);
await p.screenshot({path:path.join(S,'recordatorio.png')});
await p.click('[data-rec-atajo="1|09:00"]');await p.waitForTimeout(200);
await p.click('#rec-form button.primary');await p.waitForTimeout(1200);
await p.screenshot({path:path.join(S,'recordatorio-puesto.png')});
console.log('recordatorio:',await p.evaluate(()=>({aviso:!!document.querySelector('#live-rec:not([hidden])'),primera:document.querySelector('#live-list .conversation-item')?.classList.contains('con-rec'),chips:document.querySelectorAll('.rec-chip').length})));

// La tarea aparece en Tareas
await p.evaluate(()=>location.hash='#/tareas');await p.waitForTimeout(1600);
console.log('tareas tras el recordatorio:',await p.evaluate(()=>document.querySelectorAll('#app tbody tr').length));

// Usuarios y roles
await p.evaluate(()=>location.hash='#/usuarios');await p.waitForTimeout(1600);
await p.screenshot({path:path.join(S,'usuarios.png'),fullPage:true});

// ARP Comercial: bajar hasta anuncios y eficacia
await p.evaluate(()=>location.hash='#/comercial');await p.waitForTimeout(3200);
await p.evaluate(()=>window.scrollTo(0,1500));await p.waitForTimeout(700);
await p.screenshot({path:path.join(S,'comercial-anuncios.png')});
await p.evaluate(()=>window.scrollTo(0,document.body.scrollHeight));await p.waitForTimeout(900);
await p.screenshot({path:path.join(S,'comercial-eficacia.png')});

// Resumen con el periodo de octubre
await p.evaluate(()=>{window.scrollTo(0,0);location.hash='#/inicio'});await p.waitForTimeout(1500);
await p.click('[data-mes="2026-10"]');await p.waitForTimeout(1500);
await p.screenshot({path:path.join(S,'resumen-octubre.png')});

console.log(errs.length?'ERRORES:\n'+[...new Set(errs)].join('\n'):'Sin errores.');
await b.close();})();
