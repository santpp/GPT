#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Construye assets/agora-app.js a partir del panel.js de Contratos.

Los cuatro módulos del panel (Contratos, Con convenio, Personas y Registro) se conservan
carácter por carácter: lo que se sustituye es el armazón —módulos, rutas, barra, acceso,
paleta y atajos— y al final se injertan shell-v2.js (la barra, el menú de módulos, el
periodo, Athena y el puente con Ágora) y modulos-nuevos.js (Resumen, Tareas, Auditoría y
Usuarios y roles).

Cada sustitución es por rango de líneas del panel.js original y se aplica de abajo arriba.
Si el archivo de partida cambiara, el script avisa antes de tocar nada.
"""
import pathlib
import sys

SRC = pathlib.Path('/home/claude/src_contratos/public/panel/panel.js')
SHELL = pathlib.Path('/home/claude/uni/build/shell-v2.js')
NUEVOS = pathlib.Path('/home/claude/uni/build/modulos-nuevos.js')
OUT = pathlib.Path('/home/claude/uni/public_html/assets/agora-app.js')

lines = SRC.read_text(encoding='utf-8').split('\n')

EXPECTED = {
    2: '/* =====================================================================================',
    16: 'const store = {',
    65: '/* ---------- API (las mismas rutas del panel anterior) ---------- */',
    122: 'const MODS = {',
    172: None,            # noAccess
    178: 'let R = route(), GEN = 0;',
    197: 'function render(focus) {',
    273: 'const state = {',
    716: 'V.entrar = {',
    751: 'function openAccount() {',
    768: 'function keysModal() {',
    774: "function openCmd(initial = '') {",
    836: "    if (key === 'mod') { closeAll(); go(MODS[v].path); return; }",
    843: "  if ((el = c('[data-filter]'))) { Object.assign(state.contratos, {estado: el.dataset.filter, p: 0}); repaint(); return; }",
    887: '/* =====================================================================================',
}
for n, text in EXPECTED.items():
    if text is not None and lines[n - 1] != text:
        sys.exit(f'La línea {n} no es la esperada:\n  esperado: {text}\n  real:     {lines[n - 1]}')

# =======================================================================================
#  Los bloques nuevos
# =======================================================================================

HEADER = '''/* =====================================================================================
   Agora Digital App
   -------------------------------------------------------------------------------------
   Un solo sistema para toda la operación comercial:

     Operación       Resumen · ARP Comercial · Bandeja de conversaciones · Contactos ·
                     Oportunidades · Tareas
     Contratos       Contratos · Con convenio · Registro
     Administración  Auditoría · Usuarios y roles · Ajustes · Ayuda

   La barra de arriba lleva la marca, el módulo en uso con su menú, el periodo, los
   accesos a Inicio, Ajustes y Auditoría, el estado del espacio, el historial y Athena.

   Cada módulo habla con la API de su sistema; las dos bases se configuran en
   assets/config.js. Go High Level entra por el servidor, no desde aquí.
   ===================================================================================== */'''

STORE = '''const store = {
  get: (k, d) => { try { const v = localStorage.getItem('agora_' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem('agora_' + k, JSON.stringify(v)); } catch { /* modo privado */ } },
};'''

API = '''/* =====================================================================================
   Las dos APIs
   -------------------------------------------------------------------------------------
   Cada sistema conserva sus rutas. Las bases salen de assets/config.js, así el mismo
   paquete sirve si los dos viven en el mismo dominio o en dominios distintos.
   ===================================================================================== */
const CONTRATOS_API = (window.CONTRATOS_API || '/api/');
const AGORA_API = (window.AGORA_API || '/api/');

/* ---------- API de Contratos (las mismas rutas de siempre) ---------- */
async function api(path, {method = 'GET', body} = {}) {
  let r;
  try {
    r = await fetch(CONTRATOS_API + path, {method, credentials: 'same-origin', cache: 'no-store', headers: body !== undefined ? {'Content-Type': 'application/json'} : {}, body: body !== undefined ? JSON.stringify(body) : undefined});
  } catch {
    throw new Error(navigator.onLine ? 'No se pudo conectar con el servidor. Inténtalo de nuevo.' : 'Sin conexión. Revisa tu internet.');
  }
  let d = {}; try { d = await r.json(); } catch { /* respuesta vacía */ }
  // Si caduca la sesión de Contratos pero sigue abierta la de Ágora, no se echa a nadie.
  if (r.status === 401 && path !== 'login' && path !== 'yo') {
    ME = null; DATA.reset();
    if (AGORA_ME) { toast('Tu sesión de Contratos se cerró. Vuelve a entrar desde tu cuenta.'); go(homePath(), {replace: true}); }
    else go('/entrar', {replace: true});
  }
  if (!r.ok) throw Object.assign(new Error(d.error || `No se pudo completar (código ${r.status}).`), {status: r.status});
  return d;
}'''

MODS = '''/* =====================================================================================
   Los módulos, en tres grupos
   -------------------------------------------------------------------------------------
   Las direcciones de Ágora siguen valiendo (/bandeja, /contactos, /oportunidades,
   /conversations/{id}); /tablero y /conexiones quedan como alias de las nuevas.
   ===================================================================================== */
const GRUPOS = {
  operacion: {name: 'Operación'},
  contratos: {name: 'Contratos'},
  administracion: {name: 'Administración'},
};
const MODS = {
  inicio: {g: 'operacion', view: 'inicio', name: 'Resumen', icon: 'home', path: '/inicio', c: 'var(--brand)', periodo: true,
    desc: 'El pulso del negocio: ingreso, resultado y caja.', ok: () => esSuperAdmin()},
  comercial: {g: 'operacion', view: 'ag_dashboard', ag: 'dashboard', name: 'ARP Comercial', icon: 'pie', path: '/comercial', c: 'var(--mod-vino)',
    desc: 'Las cifras del día, los anuncios y la rentabilidad.', ok: () => agoraReady()},
  bandeja: {g: 'operacion', view: 'ag_inbox', ag: 'inbox', name: 'Bandeja de conversaciones', icon: 'chat', path: '/bandeja', c: 'var(--mod-azul)',
    desc: 'Todos los canales en una sola lista.', ok: () => agoraReady(), n: () => unread || null},
  contactos: {g: 'operacion', view: 'ag_contacts', ag: 'contacts', name: 'Contactos', icon: 'users', path: '@@AG_CONTACTOS@@', c: 'var(--mod-azul)',
    desc: 'Las fichas de la subcuenta y su historial.', ok: () => agoraReady()},
  oportunidades: {g: 'operacion', view: 'ag_board', ag: 'board', name: 'Oportunidades', icon: 'trend', path: '/oportunidades', c: 'var(--mod-oro)',
    desc: 'Los embudos por etapa y las ventas ganadas.', ok: () => agoraReady(), n: () => wonPendientes || null},
  tareas: {g: 'operacion', view: 'tareas', name: 'Tareas', icon: 'check', path: '/tareas', c: 'var(--ok-solid)',
    desc: 'Lo que cada ejecutivo tiene pendiente hoy.', ok: () => !!ME || agoraReady(), n: () => tareasPendientes()},
  convenios: {g: 'contratos', view: 'contratos', name: 'Contratos', icon: 'invoice', path: '/contratos', c: 'var(--mod-oro)',
    desc: 'Convenios de pago: estado, firma y documentos.', ok: () => can('ver'), n: () => DATA.contratos?.length},
  conConvenio: {g: 'contratos', view: 'contactos', name: 'Con convenio', icon: 'user', path: '/con-convenio', c: 'var(--mod-oro)',
    desc: 'Personas con convenio y búsqueda en la cartera.', ok: () => can('ver'), n: () => DATA.contratos ? clientes().length : null},
  registro: {g: 'contratos', view: 'registro', name: 'Registro', icon: 'history', path: '/registro', c: 'var(--mod-oro)',
    desc: 'Todo lo que pasa con los convenios, con su hora.', ok: () => can('usuarios')},
  auditoria: {g: 'administracion', view: 'auditoria', name: 'Auditoría', icon: 'shield', path: '/auditoria', c: 'var(--mod-seguridad)', periodo: true,
    desc: 'Quién tocó qué contacto, cuándo y desde dónde.', ok: () => puedeAuditar()},
  usuarios: {g: 'administracion', view: 'usuarios', name: 'Usuarios y roles', icon: 'team', path: '/usuarios', c: 'var(--mod-seguridad)',
    desc: 'Quién entra, con qué rol y la identidad del espacio.', ok: () => esAdmin()},
  conexiones: {g: 'administracion', view: 'ag_settings', ag: 'settings', name: 'Ajustes', icon: 'gear', path: '/ajustes', c: 'var(--mod-seguridad)',
    desc: 'Cuentas conectadas, equipo importado y avisos.', ok: () => agoraAdmin()},
  ayuda: {g: 'administracion', view: 'ag_help', ag: 'help', name: 'Ayuda', icon: 'info', path: '/ayuda', c: 'var(--mod-azul)',
    desc: 'El manual de uso del sistema.', ok: () => agoraReady() || !!ME},
};
/** Los módulos a los que llega quien entró, en el orden de los grupos. */
const ALL = () => Object.keys(MODS).filter(k => MODS[k].ok());
const homeMod = () => ALL()[0] || null;
const homePath = () => { const m = homeMod(); return m ? MODS[m].path : '/entrar'; };
const homeRoute = () => { const m = homeMod() || 'convenios'; return {view: MODS[m].view, mod: m}; };
/** La clave de filtro de cada vista, para las tarjetas que filtran al pulsarlas. */
const FKEY = {contratos: 'estado', tareas: 'estado', usuarios: 'rol'};

function route() {
  const p = path();
  if (p === '/entrar') return {view: 'entrar'};
  for (const id of Object.keys(MODS)) if (p === MODS[id].path) return {view: MODS[id].view, mod: id};
  if (p === '/tablero') return {view: 'ag_dashboard', mod: 'comercial'};
  if (p === '/conexiones') return {view: 'ag_settings', mod: 'conexiones'};
  if (p === '/contratos/nuevo') return {view: 'nuevo', mod: 'convenios'};
  let m = p.match(/^\\/contratos\\/([a-f0-9]{24})$/); if (m) return {view: 'detalle', mod: 'convenios', uid: m[1]};
  m = p.match(/^\\/conversations\\/([A-Za-z0-9_-]{1,80})$/);
  if (m) return {view: 'ag_inbox', mod: 'bandeja', conversation: m[1]};
  if (p === '/') return homeRoute();
  return {...homeRoute(), unknown: true};
}'''

NO_ACCESS = '''const noAccess = () => `<div class="panel"><p class="empty"><b>Este módulo no está a tu alcance</b>${agoraReady() || ME ? 'Pídele a quien administra que revise tu rol.' : 'Entra en el sistema que lo gobierna.'}<br><a class="btn btn-sm" href="${href(homePath())}">Ir al inicio</a></p></div>`;'''

R_DECL = '''let R = route(), GEN = 0;'''

RENDER = '''function render(focus) {
  closeTip?.();
  R = route();
  const root = document.documentElement;
  if (!ME && !AGORA_ME) { root.classList.add('is-auth'); return V.entrar.render(); }
  if (R.view === 'entrar') { go(homePath(), {replace: true}); return; }
  root.classList.remove('is-auth'); $('#lg')?.remove();
  // Un enlace a una conversación concreta: la bandeja la abre al cargar.
  if (R.conversation && ws) {
    ws.pendingConversation = {id: R.conversation, explicit: false};
    history.replaceState(null, '', HASH ? location.pathname + '#/bandeja' : '/bandeja');
    R = {view: 'ag_inbox', mod: 'bandeja'};
  }
  if (R.unknown) history.replaceState(null, '', HASH ? location.pathname + '#' + homePath() : homePath());
  topbar();
  const gen = ++GEN;
  const v = V[R.view];
  if (!v) { paint(failed('Esta pantalla no existe.')); return; }
  if (R.mod && !MODS[R.mod].ok()) { paint(noAccess()); return; }
  paint(v.render(), true);
  if (v.need) {
    v.need().then(() => { if (gen === GEN) { topbar(); paint(v.render()); } })
      .catch(err => { if (gen === GEN) { v.error = err.message; paint(v.render()); v.error = ''; } });
  }
  anotarHistorial();
  document.title = `${R.view === 'nuevo' ? 'Nuevo convenio' : MODS[R.mod]?.name || 'Inicio'} · Agora Digital App`;
  if (focus) $('#app').focus({preventScroll: true});
  if (focus) scrollTo({top: 0});
}
function paint(html, enter) {
  const app = $('#app');
  // Si lo que había era un módulo de Ágora, se suelta antes de reemplazarlo: así para
  // sus relojes, sus consultas en vivo y sus escuchas, como hacía en su propia cáscara.
  disposeAgora();
  // En la barra no cabe el periodo cuando la pantalla es estrecha: baja al lienzo.
  const per = MODS[R.mod]?.periodo ? `<div class="per-m">${periodBar()}</div>` : '';
  app.innerHTML = `${per}<div class="${enter ? 'view-enter' : ''}">${html}</div>`;
  placeThumbs(document);
  V[R.view]?.mounted?.(app);
}'''

STATE = '''const state = {
  contratos: {q: '', estado: '', p: 0, sk: 'creado_en', sd: -1},
  contactos: {tab: 'clientes', q: '', p: 0, sk: 'ultimo', sd: -1, consulta: '', resultados: null, aviso: '', buscando: false, error: ''},
  nuevo: null,
  detalle: {verPdf: false},
  personas: {q: '', p: 0},
  registro: {q: '', tipo: '', p: 0},
  tareas: {q: '', estado: 'abiertas', resp: '', p: 0, sk: 'vence', sd: 1},
  auditoria: {q: '', modulo: '', actor: '', p: 0},
  usuarios: {q: '', rol: '', p: 0},
};
const PER = 25;'''

ENTRAR = '''V.entrar = {
  render() {
    document.documentElement.classList.add('is-auth');
    let s = $('#lg');
    if (!s) { s = document.createElement('div'); s.id = 'lg'; s.className = 'lg'; document.body.append(s); }
    s.innerHTML = `<div class="lg-wrap" role="main">
      <div class="lg-logo">${LOGO}<small>Digital App</small></div>
      <h1>Bienvenido de nuevo</h1>
      <p class="lg-sub">Entra con el acceso que uses hoy. Los dos pueden estar abiertos a la vez.</p>
      <div class="lg-pair">
        <section class="lg-card">
          <header><span class="lg-ic" style="--c:var(--mod-oro)">${icon('invoice')}</span><div><h2>Contratos</h2><p>Convenios de pago, firma y registro.</p></div></header>
          <form novalidate>
            <label class="fld">Correo<input id="lg-mail" type="email" autocomplete="username" autofocus></label>
            <label class="fld">Clave<span class="pw-in"><input id="lg-pw" type="password" autocomplete="current-password"><button class="pw-eye" type="button" aria-pressed="false">Mostrar</button></span></label>
            <p class="fld-err" role="alert"></p><button class="btn btn-cta lg-go" type="submit">Entrar en Contratos</button>
          </form>
          <p class="lg-help">¿No puedes entrar? Pídele a quien administra que te restablezca la clave.</p>
        </section>
        <section class="lg-card">
          <header><span class="lg-ic" style="--c:var(--mod-vino)">${icon('chat')}</span><div><h2>Operación comercial</h2><p>Resumen, bandeja, contactos y oportunidades.</p></div></header>
          <div class="ag-login">${agoraLoginForms()}</div>
          <p class="lg-help">Entras con el mismo correo con el que formas parte del equipo.</p>
        </section>
      </div>
      <p class="lg-foot">${icon('lock')}Agora Digital App · Cada conversación, una oportunidad.</p></div>`;
    const entrado = async () => { await Promise.all([bootContratos(), bootAgora()]); await bootEspacio(); const back = store.get('volver', ''); store.set('volver', ''); go(back && back !== '/entrar' ? back : homePath(), {replace: true}); };
    const card = s.querySelector('.lg-card');
    const eye = s.querySelector('.pw-eye'), pw = s.querySelector('#lg-pw');
    eye.onclick = () => { const v = pw.type === 'password'; pw.type = v ? 'text' : 'password'; eye.textContent = v ? 'Ocultar' : 'Mostrar'; eye.setAttribute('aria-pressed', String(v)); };
    s.querySelector('form').onsubmit = async e => {
      e.preventDefault();
      const correo = s.querySelector('#lg-mail').value.trim(), clave = pw.value, err = card.querySelector('.fld-err'), b = s.querySelector('.lg-go');
      const shake = () => { card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake'); };
      if (!correo || !clave) { err.textContent = 'Escribe tu correo y tu clave.'; shake(); return; }
      busy(b, true, 'Entrando…'); err.textContent = '';
      try { const d = await api('login', {method: 'POST', body: {correo, clave}}); ME = d.usuario; DATA.reset(); await entrado(); }
      catch (x) { busy(b, false); err.textContent = x.message; shake(); pw.select(); }
    };
    bindAgoraLogin(s, entrado);
    s.querySelector(document.activeElement?.id === 'lg-pw' ? '#lg-pw' : '#lg-mail')?.focus();
    return '';
  },
};
async function salir() {
  closeAll(); cerrarAthena();
  if (ME) { try { await api('logout', {method: 'POST'}); } catch { /* igual se sale */ } }
  if (AGORA_ME) { try { await agoraApi('logout', {method: 'POST'}); } catch { /* igual se sale */ } }
  window.dispatchEvent(new Event('agora:logout'));
  ME = null; DATA.reset(); state.nuevo = null;
  DATOS.resumen = DATOS.tareas = DATOS.auditoria = DATOS.usuarios = null;
  go('/entrar', {replace: true});
}'''

ACCOUNT = '''function openAccount() {
  const fila = (nombre, color, icono, detalle, accion) => `<div class="acct-row"><span class="lg-ic" style="--c:${color}">${icon(icono)}</span><span class="tx"><b>${nombre}</b><small>${detalle}</small></span>${accion}</div>`;
  const el = openPop($('#b-acct'), `<div class="acct-sys">
      ${fila('Contratos', 'var(--mod-oro)', 'invoice', ME ? `${esc(ME.nombre)} · ${esc(ROLES[ME.rol]?.l || ME.rol)}` : 'Sin sesión', ME ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Abierta</span>' : '')}
      ${fila('Operación comercial', 'var(--mod-vino)', 'chat', AGORA_ME ? `${esc(AGORA_ME.user?.email || '')}${ws && ws.name() ? ' · ' + esc(ws.name()) : ''}` : 'Sin sesión', AGORA_ME ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Abierta</span>' : '<button class="btn btn-sm btn-tint" type="button" data-agora-login>Entrar</button>')}
    </div>
    <div><h4>Tema</h4>${seg('tema', [['auto', 'Automático'], ['light', 'Claro'], ['dark', 'Oscuro']], store.get('tema', 'auto'), 'Tema')}</div>
    <div class="acct-ft">${ME ? `<button class="btn btn-sm" type="button" data-clave>${icon('lock')}Cambiar mi clave</button>` : ''}<button class="btn btn-sm" type="button" data-keys>${icon('keyboard')}Atajos</button><button class="btn btn-sm btn-danger" type="button" data-logout>${icon('logout')}Salir</button></div>`, 'acct', {align: 'right'});
  if (el) placeThumbs(el);
}'''

KEYS = '''function keysModal() {
  const mods = ALL().slice(0, 10);
  openModal(modalHead('Atajos de teclado', 'Funcionan cuando no estás escribiendo en un campo.') + `<div class="keys"><div><h3>Ir a</h3><dl>${mods.map((id, i) => `<dt><kbd>${(i + 1) % 10}</kbd></dt><dd>${esc(MODS[id].name)}</dd>`).join('')}</dl></div>
    <div><h3>Acciones</h3><dl><dt><kbd>${IS_MAC ? '⌘K' : 'Ctrl K'}</kbd></dt><dd>Buscar o ir a…</dd><dt><kbd>M</kbd></dt><dd>Abrir el menú de módulos</dd><dt><kbd>J</kbd></dt><dd>Preguntarle a Athena</dd>${can('editar') ? '<dt><kbd>N</kbd></dt><dd>Nuevo convenio</dd>' : ''}<dt><kbd>/</kbd></dt><dd>Buscar en la vista</dd><dt><kbd>D</kbd></dt><dd>Tema claro u oscuro</dd><dt><kbd>Esc</kbd></dt><dd>Cerrar</dd><dt><kbd>?</kbd></dt><dd>Esta ayuda</dd></dl></div></div>`);
}'''

CMD = '''/* ---------- Paleta ⌘K: módulos, acciones y convenios ---------- */
function openCmd(initial = '') {
  const s = openModal(`<div class="cmdk-in">${icon('search')}<input type="search" placeholder="Busca un módulo, un cliente o una acción…" value="${esc(initial)}" aria-label="Buscar o ir a" autocomplete="off"></div><div class="cmdk-list" role="listbox"></div><div class="cmdk-ft"><span><kbd>↑</kbd><kbd>↓</kbd> moverte</span><span><kbd>Enter</kbd> abrir</span><span><kbd>Esc</kbd> cerrar</span></div>`, {cls: 'cmdk'});
  const inp = s.querySelector('input'), list = s.querySelector('.cmdk-list'); let sel = 0, items = [];
  const paintList = () => {
    const q = norm(inp.value.trim());
    const mods = ALL().map(id => ({g: GRUPOS[MODS[id].g].name, i: MODS[id].icon, c: MODS[id].c, t: MODS[id].name, d: MODS[id].desc, go: MODS[id].path}));
    const acc = [
      ...(can('editar') ? [{g: 'Acciones', i: 'plus', t: 'Nuevo convenio', d: 'Elige el contacto y arma el plan de pago', go: '/contratos/nuevo'},
        {g: 'Acciones', i: 'search', t: 'Buscar en la cartera', d: 'Contactos de la subcuenta, para crear un convenio', fn: () => { state.contactos.tab = 'agora'; go('/con-convenio'); }}] : []),
      ...(MODS.tareas.ok() ? [{g: 'Acciones', i: 'check', t: 'Nueva tarea', d: 'Para ti o para alguien del equipo', fn: () => { go('/tareas'); setTimeout(() => tareaModal(), 260); }}] : []),
      {g: 'Acciones', i: 'athena', t: 'Preguntarle a Athena', d: 'Resume tus cifras del sistema', fn: () => abrirAthena()},
      ...(agoraReady() ? [{g: 'Acciones', i: 'coins', t: 'Ventas ganadas', d: 'Completar las que están sin monto', fn: () => { if (ws) ws.pendingOppTab = 'won'; go('/oportunidades'); }}] : []),
      ...(!AGORA_ME ? [{g: 'Acciones', i: 'lock', t: 'Entrar en la operación comercial', d: 'Para el resumen, la bandeja y las oportunidades', fn: agoraLoginModal}] : []),
      ...(ME ? [{g: 'Acciones', i: 'lock', t: 'Cambiar mi clave', d: 'La del panel de Contratos', fn: claveModal}] : []),
      {g: 'Acciones', i: document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', t: 'Cambiar tema', fn: toggleTheme},
      {g: 'Acciones', i: 'keyboard', t: 'Atajos de teclado', fn: keysModal},
    ];
    const conv = (DATA.contratos || []).map(c => ({g: 'Convenios', i: 'invoice', c: 'var(--mod-oro)', t: c.cliente, d: `${c.correo} · ${(ESTADO[c.estado]?.l || c.estado).toLowerCase()} · v${c.version}`, go: '/contratos/' + c.uid}));
    const tar = (DATOS.tareas || []).filter(t => t.estado !== 'hecha').map(t => ({g: 'Tareas', i: 'check', c: 'var(--ok-solid)', t: t.titulo, d: `${t.responsable || 'Sin asignar'}${t.vence ? ' · vence ' + fday(t.vence) : ''}`, go: '/tareas'}));
    items = [...mods, ...acc, ...conv, ...tar].filter(x => !q || norm(x.t + ' ' + (x.d || '') + ' ' + x.g).includes(q)).slice(0, 40);
    sel = Math.min(sel, Math.max(0, items.length - 1));
    let g = '';
    list.innerHTML = items.length ? items.map((x, i) => `${x.g !== g ? `<p class="mdm-gt">${(g = x.g)}</p>` : ''}<div class="mdm-i ${i === sel ? 'is-kb' : ''}" role="option" aria-selected="${i === sel}" data-i="${i}"><span class="mdm-ic" style="--c:${x.c || 'var(--brand)'}">${icon(x.i)}</span><span class="tx"><b>${esc(x.t)}</b>${x.d ? `<small>${esc(x.d)}</small>` : ''}</span></div>`).join('')
      : `<p class="empty"><b>Nada coincide</b>${can('editar') && q.length > 1 ? `<button class="btn btn-sm" type="button" data-agora>Buscar «${esc(inp.value.trim())}» en la cartera</button>` : 'Prueba con otro nombre.'}</p>`;
    list.querySelector('.is-kb')?.scrollIntoView({block: 'nearest'});
  };
  const run = i => { const x = items[i]; if (!x) return; closeModal(true); if (x.fn) x.fn(); else go(x.go); };
  inp.oninput = () => { sel = 0; paintList(); };
  inp.onkeydown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); paintList(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); paintList(); }
    if (e.key === 'Enter') { e.preventDefault(); run(sel); }
  };
  list.onclick = e => {
    const it = e.target.closest('[data-i]'); if (it) return run(+it.dataset.i);
    if (e.target.closest('[data-agora]')) { const q = inp.value.trim(); closeModal(true); state.contactos.tab = 'agora'; go('/con-convenio'); buscarAgora(q); }
  };
  paintList(); inp.focus(); inp.select();
  if (!DATA.contratos && can('ver')) loadContratos().then(paintList).catch(() => {});
}'''

MOD_BRANCH = '''    if (key === 'rol-sys' || key === 'cpm-e') return;'''

FILTER_BRANCH = '''  if ((el = c('[data-filter]'))) {
    const st = state[R.view], k = FKEY[R.view];
    if (st && k) { st[k] = st[k] === el.dataset.filter ? '' : el.dataset.filter; st.p = 0; repaint(); }
    return;
  }'''

KEYDOWN = '''  if (typing || e.metaKey || e.ctrlKey || e.altKey || (!ME && !AGORA_ME) || modal) return;
  const k = e.key.toLowerCase(), mods = ALL();
  const n = k === '0' ? 9 : (/^[1-9]$/.test(k) ? +k - 1 : -1);
  if (n >= 0 && mods[n]) { closePop(); go(MODS[mods[n]].path); }
  else if (k === 'm') { closePop(); moduleMenu(); }
  else if (k === 'j') { closePop(); abrirAthena(); }
  else if (k === 'n' && can('editar')) go('/contratos/nuevo');
  else if (k === 'd') toggleTheme();
  else if (k === '/') { const f = $('#app input[type=search]'); if (f) { e.preventDefault(); f.focus(); } }
  else if (e.key === '?') keysModal();
});'''

BOOT = '''/* =====================================================================================
   Arranque: ¿qué sesiones hay abiertas?
   ===================================================================================== */
async function bootContratos() {
  try { ME = (await api('yo')).usuario || null; } catch { ME = null; }
  if (!ME) DATA.reset();
}
applyTheme();
if (AG_READY && window.AGORA_MAINTENANCE !== false) { try { AG.installMaintenance(); } catch { /* sin vigilancia */ } }
(async () => {
  await Promise.all([bootContratos(), bootAgora()]);
  if (ME || AGORA_ME) await bootEspacio();
  const p = path();
  if (!ME && !AGORA_ME) {
    if (p !== '/entrar') { store.set('volver', p); history.replaceState(null, '', HASH ? location.pathname + '#/entrar' : '/entrar'); }
  } else if (p === '/entrar' || p === '/') {
    const back = store.get('volver', ''); store.set('volver', '');
    const target = back && back !== '/entrar' && back !== '/' ? back : homePath();
    history.replaceState(null, '', HASH ? location.pathname + '#' + target : target);
  }
  render();
})();'''

# =======================================================================================
#  Las sustituciones, de abajo arriba
# =======================================================================================
injerto = SHELL.read_text(encoding='utf-8') + '\n' + NUEVOS.read_text(encoding='utf-8') + '\n' + BOOT

PATCHES = [
    (887, 896, injerto),
    (878, 885, KEYDOWN),
    (875, 875, "  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { if (!ME && !AGORA_ME) return; e.preventDefault(); if (modal?.querySelector('.cmdk')) closeModal(); else openCmd(); return; }"),
    (843, 843, FILTER_BRANCH),
    (836, 836, MOD_BRANCH),
    (774, 802, CMD),
    (768, 771, KEYS),
    (751, 756, ACCOUNT),
    (716, 741, ENTRAR),
    (273, 281, STATE),
    (197, 224, RENDER),
    (178, 195, R_DECL),
    (172, 172, NO_ACCESS),
    (122, 139, MODS),
    (65, 77, API),
    (16, 19, STORE),
    (2, 6, HEADER),
]
for start, end, new in PATCHES:
    lines[start - 1:end] = new.split('\n')

out = '\n'.join(lines)

# La ruta del panel que se movió, y la de Ágora que se queda donde estaba.
out = out.replace("'/contactos'", "'/con-convenio'")
out = out.replace("'@@AG_CONTACTOS@@'", "'/contactos'")
if '@@' in out:
    sys.exit('Quedó un marcador sin resolver en el resultado.')

OUT.write_text(out, encoding='utf-8')
print(f'agora-app.js escrito: {len(out.split(chr(10)))} líneas, {len(out.encode()) / 1024:.1f} KB')
