/* =====================================================================================
   ARP Comercial · lo que se midió aparte
   -------------------------------------------------------------------------------------
   Tres bloques que el tablero no traía y que se piden desde la operación:

     1. Operación del día — el tiempo de respuesta (SLA), las conversaciones sin leer por
        asesor, de dónde vienen los leads y a quién le tocaron.
     2. Inversión en anuncios — lo invertido hoy, cuánto va gastado en el mes, las
        impresiones, el coste por conversión y las campañas que más consumen.
     3. Eficacia de ventas — cuánto tarda un cierre, cuánto vale y a qué ritmo entra.

   Las cifras salen del servidor, que es quien habla con Go High Level y con Meta. Las
   piezas de dibujo (rueda, barras) las presta el armazón en window.AgoraUI.
   ===================================================================================== */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const UI = () => window.AgoraUI || {};
const nf = new Intl.NumberFormat('es-VE', {maximumFractionDigits: 0});
const num = v => v === null || v === undefined || !isFinite(Number(v)) ? '—' : nf.format(Number(v));
const dinero = v => (UI().usd ? UI().usd(v) : (v === null || v === undefined ? '—' : 'US$ ' + nf.format(Number(v))));
const rueda = (items, opc) => UI().donut ? UI().donut(items, opc) : '';
const barras = items => UI().barras ? UI().barras(items) : '';

/** Cuánto cambió frente a ayer, con su flecha. */
function contra(hoy, ayer, {alReves = false} = {}) {
  if (ayer === null || ayer === undefined || !isFinite(Number(ayer)) || Number(ayer) === 0) return '';
  const d = ((Number(hoy) - Number(ayer)) / Number(ayer)) * 100;
  if (!isFinite(d)) return '';
  const sube = d > 0, bueno = alReves ? !sube : sube;
  return `<span class="delta ${bueno ? 'up' : 'down'}">${sube ? '↑' : '↓'} ${nf.format(Math.abs(Math.round(d)))} %</span><span class="delta-t">frente a ayer</span>`;
}
const sec = (t, s = '', a = '') => s || a
  ? `<div class="t-sec-row"><div><h2 class="t-sec">${t}</h2>${s ? `<p>${s}</p>` : ''}</div>${a}</div>`
  : `<h2 class="t-sec">${t}</h2>`;
const panelx = (t, s, body, extra = '') => `<section class="panel"><div class="panel-h"><div><h2 class="t-panel">${t}</h2>${s ? `<p>${s}</p>` : ''}</div>${extra}</div>${body}</section>`;
const tile = (l, v, f = '', cls = '') => `<div class="micro ${cls}"><h3>${esc(l)}</h3><p class="t-metric">${v}</p>${f ? `<span class="f">${f}</span>` : ''}</div>`;
const cargando = n => `<div class="grid g2">${'<div class="micro"><span class="sk w60"></span><span class="sk big"></span></div>'.repeat(n)}</div>`;

/** Los huecos que el tablero deja para estos bloques. */
export const slotsDia = () => '<div id="arp-dia"></div><div id="arp-ads"></div>';
export const slotEficacia = () => '<div id="arp-efi"></div>';

/* =====================================================================================
   1 · Operación del día
   ===================================================================================== */
function pintarDia(nodo, d) {
  if (!d) { nodo.innerHTML = ''; return; }
  const semaforo = d.slaIncumplido === 0 ? 'ok' : d.slaIncumplido <= (d.slaTolerancia ?? 3) ? 'warn' : 'bad';
  const meta = d.slaMetaTexto || '5 min';
  const total = Math.max(1, d.conversacionesDia || d.slaIncumplido || 1);
  const enMeta = Math.round(100 * (1 - (d.slaIncumplido || 0) / total));
  nodo.innerHTML = `${sec('Operación del día', 'Lo que está esperando respuesta ahora mismo y de dónde viene.')}
    <div class="grid g-hero">
      <section class="hero">
        <div>
          <p class="t-label">Tiempo de respuesta promedio (SLA)</p>
          <p class="t-hero" style="margin-top:10px">${esc(d.slaPromedio || '—')}</p>
          <p class="f">${contra(d.slaPromedioSeg, d.slaPromedioSegAyer, {alReves: true}) || 'Primer día con medición.'} · La meta es responder en menos de ${esc(meta)}.</p>
        </div>
        <div class="goal">
          <div class="pair"><span>Dentro de la meta</span><b class="${semaforo === 'bad' ? 'down' : semaforo === 'ok' ? 'up' : ''}">${enMeta} %</b></div>
          <div class="track" role="img" aria-label="Dentro de la meta: ${enMeta} %"><span class="fill ${semaforo}" style="width:${Math.max(3, enMeta)}%"></span></div>
          <p class="f">${d.slaIncumplido ? `${num(d.slaIncumplido)} de ${num(d.conversacionesDia)} pasaron de ${esc(meta)} sin respuesta.` : 'Hoy todas se respondieron dentro de la meta.'}</p>
          <div class="lts"><span class="lt lt-ok"><i aria-hidden="true"></i>En meta ${num((d.conversacionesDia || 0) - (d.slaIncumplido || 0))}</span><span class="lt lt-bad"><i aria-hidden="true"></i>Fuera de meta ${num(d.slaIncumplido)}</span></div>
        </div>
      </section>
      <div class="grid g2">
        ${tile('Sin leer ahora', num(d.sinLeer), contra(d.sinLeer, d.sinLeerAyer, {alReves: true}) || 'Conversaciones que nadie ha abierto')}
        ${tile('Leads del día', num(d.leads), contra(d.leads, d.leadsAyer))}
        ${tile('Primera respuesta más lenta', esc(d.peorRespuesta || '—'), d.peorAsesor ? `De ${esc(d.peorAsesor)}` : 'Sin registro')}
        ${tile('Conversaciones atendidas', num(d.atendidas), `${num(d.conversacionesDia)} abiertas hoy`)}
      </div>
    </div>
    <div class="grid g3 mt">
      ${panelx('Sin leer por asesor', 'Quién tiene conversaciones esperando.', rueda((d.sinLeerPorAsesor || []).map(x => ({l: x.nombre, n: x.n})), {rotulo: 'Conversaciones sin leer por asesor'}))}
      ${panelx('Fuente de los leads', 'Por dónde entraron hoy.', rueda((d.leadsPorFuente || []).map(x => ({l: x.fuente, n: x.n})), {rotulo: 'Fuente de los leads'}))}
      ${panelx('Leads por ejecutivo', 'A quién le tocaron.', rueda((d.leadsPorUsuario || []).map(x => ({l: x.nombre, n: x.n})), {rotulo: 'Leads asignados por ejecutivo'}))}
    </div>`;
}

/* =====================================================================================
   2 · Inversión en anuncios (Meta)
   ===================================================================================== */
function pintarAds(nodo, a, periodoTexto) {
  if (!a) { nodo.innerHTML = ''; return; }
  if (a.estado && a.estado !== 'ok') {
    const porque = {
      expired: ['La conexión con Meta venció', 'Hay que volver a autorizarla para seguir trayendo el gasto, las impresiones y las campañas.'],
      not_connected: ['No hay cuenta publicitaria conectada', 'Conecta la cuenta de Meta para ver aquí lo invertido cada día.'],
      permission: ['Falta permiso para leer los anuncios', 'La clave de la cuenta no alcanza a los anuncios. Pídelo a quien administra la cuenta publicitaria.'],
    }[a.estado] || ['No se pudo leer la cuenta publicitaria', 'Vuelve a intentarlo en un momento.'];
    nodo.innerHTML = `${sec('Inversión en anuncios', 'Lo que se está invirtiendo en Meta y qué devuelve.')}
      ${panelx(esc(porque[0]), '', `<p class="empty"><b>${esc(porque[0])}</b>${esc(porque[1])}<br><a class="btn btn-sm btn-cta" href="/ajustes">Ir a Ajustes</a></p>`)}`;
    return;
  }
  const consumido = a.presupuestoMes ? Math.min(100, Math.round((Number(a.mes) / Number(a.presupuestoMes)) * 100)) : null;
  const campanas = (a.campanas || []).slice(0, 6);
  nodo.innerHTML = `${sec('Inversión en anuncios', `Lo invertido en Meta y lo que devuelve. Actualizado ${esc(a.actualizado || 'hoy')}.`)}
    <div class="grid g-hero">
      <section class="hero">
        <div>
          <p class="t-label">Invertido en ${esc(periodoTexto)}</p>
          <p class="t-hero" style="margin-top:10px">${esc(dinero(a.mes))}</p>
          <p class="f">Hoy van ${esc(dinero(a.dia))}${a.diaAyer !== undefined ? ` · ayer ${esc(dinero(a.diaAyer))}` : ''}.</p>
        </div>
        <div class="goal">
          ${a.presupuestoMes ? `<div class="pair"><span>Presupuesto del mes</span><b>${esc(dinero(a.presupuestoMes))}</b></div>
          <div class="track" role="img" aria-label="Presupuesto consumido: ${consumido} %"><span class="fill ${consumido > 95 ? 'bad' : consumido > 80 ? 'warn' : ''}" style="width:${consumido}%"></span></div>
          <p class="f">Llevas ${consumido} % del presupuesto. Quedan ${esc(dinero(Number(a.presupuestoMes) - Number(a.mes)))}.</p>`
            : '<p class="f">No hay presupuesto fijado para el mes. Se puede indicar en «Cifras del mes».</p>'}
        </div>
      </section>
      <div class="grid g2">
        ${tile('Impresiones', num(a.impresiones), a.clics !== undefined ? `${num(a.clics)} clics` : '')}
        ${tile('Coste por conversión', esc(dinero(a.costePorConversion)), `${num(a.conversiones)} conversiones`)}
        ${tile('Coste por lead', esc(dinero(a.costePorLead)), 'Inversión entre leads del día')}
        ${tile('Retorno por cada 100', esc(dinero(a.retornoPorCien)), 'Vendido entre invertido, por cien')}
      </div>
    </div>
    <div class="mt">${panelx('Campañas por gasto', 'Las que más consumen en el periodo.',
      barras(campanas.map(c => ({l: c.nombre, v: Number(c.gasto) || 0, texto: dinero(c.gasto) + (c.conversiones ? ` · ${num(c.conversiones)} conv.` : '')}))))}</div>`;
}

/* =====================================================================================
   3 · Eficacia de ventas
   ===================================================================================== */
function pintarEficacia(nodo, e, {onFiltro} = {}) {
  if (!e) { nodo.innerHTML = ''; return; }
  const sel = (id, rotulo, opciones, valor) => `<label class="fld">${rotulo}<select data-efi="${id}">${opciones.map(o => `<option value="${esc(o.id)}" ${String(o.id) === String(valor) ? 'selected' : ''}>${esc(o.nombre)}</option>`).join('')}</select></label>`;
  const metaDias = Number(e.metaDias) || 0;
  const dias = Number(e.duracionPromedioDias);
  const tono = !metaDias ? '' : dias <= metaDias ? 'ok' : dias <= metaDias * 1.3 ? 'warn' : 'bad';
  nodo.innerHTML = `${sec('Eficacia de ventas', 'Cuánto tarda un cierre, cuánto deja y a qué ritmo entra.',
    `<div class="acts">${sel('pipeline', 'Embudo', [{id: '', nombre: 'Todos los embudos'}, ...(e.pipelines || [])], e.pipelineId)}${sel('user', 'Ejecutivo', [{id: '', nombre: 'Todo el equipo'}, ...(e.usuarios || [])], e.userId)}</div>`)}
    <div class="grid g-hero">
      <section class="hero">
        <div>
          <p class="t-label">Tiempo de cierre promedio</p>
          <p class="t-hero" style="margin-top:10px">${esc(e.duracionTexto || '—')}</p>
          <p class="f">${metaDias ? `La meta es cerrar en ${num(metaDias)} días.` : 'Sin meta de cierre fijada.'} ${e.cerradas ? `Sobre ${num(e.cerradas)} ventas cerradas.` : ''}</p>
        </div>
        <div class="goal">
          ${metaDias ? `<div class="pair"><span>Frente a la meta</span><b class="${tono === 'bad' ? 'down' : tono === 'ok' ? 'up' : ''}">${dias <= metaDias ? '−' : '+'}${num(Math.abs(dias - metaDias))} días</b></div>
          <div class="track" role="img" aria-label="Tiempo de cierre frente a la meta"><span class="fill ${tono}" style="width:${Math.max(4, Math.min(100, Math.round((metaDias / Math.max(dias, 1)) * 100)))}%"></span></div>` : ''}
          <p class="f">La velocidad dice cuánto valor entra al mes con el ritmo de hoy.</p>
        </div>
      </section>
      <div class="grid g2">
        ${tile('Valor cerrado', esc(dinero(e.valorTotal)), `${num(e.cerradas)} ventas en el periodo`)}
        ${tile('Velocidad de venta', `${esc(dinero(e.velocidad))}<small class="por">/mes</small>`, 'Al ritmo actual de cierre')}
        ${tile('Ticket promedio', esc(dinero(e.ticket)), 'Valor entre ventas cerradas')}
        ${tile('Tasa de cierre', e.tasaCierre === null || e.tasaCierre === undefined ? '—' : `${num(e.tasaCierre)} %`, 'De las oportunidades trabajadas')}
      </div>
    </div>
    ${(e.porUsuario || []).length ? `<div class="mt">${panelx('Por ejecutivo', 'Quién cierra más rápido y cuánto deja.',
      `<div class="tw stack"><table><thead><tr><th scope="col">Ejecutivo</th><th scope="col" class="n">Cerradas</th><th scope="col" class="n">Valor</th><th scope="col" class="n">Días al cierre</th><th scope="col">Frente a la meta</th></tr></thead>
      <tbody>${e.porUsuario.map(u => {
        const t = !metaDias ? '' : u.dias <= metaDias ? 'ok' : u.dias <= metaDias * 1.3 ? 'warn' : 'bad';
        return `<tr><th scope="row">${esc(u.nombre)}</th><td class="n" data-label="Cerradas">${num(u.cerradas)}</td><td class="n" data-label="Valor">${esc(dinero(u.valor))}</td><td class="n" data-label="Días">${num(u.dias)}</td>
          <td data-label="Frente a la meta"><span class="cell-bar"><span class="track">${metaDias ? `<span class="fill ${t}" style="width:${Math.max(4, Math.min(100, Math.round((metaDias / Math.max(u.dias, 1)) * 100)))}%"></span>` : ''}</span><b>${metaDias ? (u.dias <= metaDias ? 'En meta' : '+' + num(u.dias - metaDias) + ' d') : '—'}</b></span></td></tr>`;
      }).join('')}</tbody></table></div>`)}</div>` : ''}`;
  nodo.querySelectorAll('[data-efi]').forEach(s => { s.onchange = () => onFiltro?.({pipelineId: nodo.querySelector('[data-efi="pipeline"]')?.value || '', userId: nodo.querySelector('[data-efi="user"]')?.value || ''}); });
}

/* =====================================================================================
   El enganche con el tablero
   ===================================================================================== */
export async function pintarExtras(container, {connection, period, request, active}) {
  const dia = container.querySelector('#arp-dia');
  const ads = container.querySelector('#arp-ads');
  const efi = container.querySelector('#arp-efi');
  if (dia) dia.innerHTML = cargando(2);
  if (ads) ads.innerHTML = cargando(2);

  const hoy = new Date().toISOString().slice(0, 10);
  const q = `connectionId=${encodeURIComponent(connection)}&period=${encodeURIComponent(period)}&date=${hoy}`;
  const periodoTexto = (window.AgoraUI?.mesNombre ? window.AgoraUI.mesNombre(period) : period).toLowerCase();

  const traer = async ruta => { try { return await request(ruta); } catch { return null; } };

  const [d, a] = await Promise.all([traer(`workspace/dia?${q}`), traer(`workspace/ads?${q}`)]);
  if (!active()) return;
  if (dia) pintarDia(dia, d);
  if (ads) pintarAds(ads, a, periodoTexto);
  if (window.AgoraUI) { window.AgoraUI.guardarDia?.(d); window.AgoraUI.guardarAds?.(a); }

  if (!efi) return;
  let filtro = {pipelineId: '', userId: ''};
  const cargarEfi = async () => {
    efi.innerHTML = cargando(2);
    const e = await traer(`workspace/eficacia?${q}&pipelineId=${encodeURIComponent(filtro.pipelineId)}&userId=${encodeURIComponent(filtro.userId)}`);
    if (!active()) return;
    pintarEficacia(efi, e, {onFiltro: f => { filtro = f; cargarEfi(); }});
    window.AgoraUI?.guardarEficacia?.(e);
  };
  await cargarEfi();
}
