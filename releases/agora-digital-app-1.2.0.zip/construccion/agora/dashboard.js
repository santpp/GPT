import {workspace,friendly} from './workspace.js';
import {skeleton} from './skeleton.js';
import {number,money as fmtMoney} from './format.js';
import {wonAlertState} from './won-alert.js';
import {slotsDia,slotEficacia,pintarExtras} from './arp-extra.js';
const money=value=>fmtMoney(value);

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const asList=value=>Array.isArray(value)?value:[];
// La cuenta no publica moneda, así que la cifra va sin símbolo.
const MONTHS=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const pad2=n=>String(n).padStart(2,'0');
const ymd=d=>`${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const PRESETS=[['today','Hoy'],['yesterday','Ayer'],['week','7 días'],['d30','30 días'],['month','Este mes'],['prev','Mes anterior'],['monthpick','Otro mes'],['custom','Rango']];
/** Periodo elegido: días para los leads y mes para el resumen mensual (el resumen es siempre de un mes natural). */
export function periodOf(sel,now=new Date()){
  const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  const cur=ymd(today).slice(0,7);
  const monthly=(y,m)=>{const last=new Date(y,m+1,0);return {from:ymd(new Date(y,m,1)),to:ymd(last<today?last:today),month:`${y}-${pad2(m+1)}`}};
  switch(sel?.kind){
    case 'yesterday':{const d=addDays(today,-1);return {from:ymd(d),to:ymd(d),month:cur,label:'ayer'}}
    case 'week':return {from:ymd(addDays(today,-6)),to:ymd(today),month:cur,label:'últimos 7 días'};
    case 'd30':return {from:ymd(addDays(today,-29)),to:ymd(today),month:cur,label:'últimos 30 días'};
    case 'month':return {...monthly(today.getFullYear(),today.getMonth()),label:'este mes'};
    case 'prev':{const p=new Date(today.getFullYear(),today.getMonth()-1,1);return {...monthly(p.getFullYear(),p.getMonth()),label:'mes anterior'}}
    case 'monthpick':{const m=/^(\d{4})-(\d{2})$/.exec(sel.month||'');if(m){const r=monthly(Number(m[1]),Number(m[2])-1);return {...r,label:monthNameShort(r.month)}}return {...monthly(today.getFullYear(),today.getMonth()),label:'este mes'}}
    case 'custom':{const ok=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'');if(ok(sel.from)&&ok(sel.to)&&sel.from<=sel.to)return {from:sel.from,to:sel.to,month:sel.to.slice(0,7)>cur?cur:sel.to.slice(0,7),label:`${dayLabel(sel.from)} – ${dayLabel(sel.to)}`};return {from:ymd(today),to:ymd(today),month:cur,label:'hoy'}}
    default:return {from:ymd(today),to:ymd(today),month:cur,label:'hoy'};
  }
}
const dayLabel=v=>{const [y,m,d]=v.split('-').map(Number);return `${d} ${MONTHS[m-1].slice(0,3)}${y!==new Date().getFullYear()?' '+y:''}`};
const cap=t=>t.charAt(0).toUpperCase()+t.slice(1);
/** Opciones de mes en español («Noviembre 2026»), del actual hacia atrás; incluye el elegido aunque sea más antiguo. */
const monthOptions=(selected,count=24)=>{
  const now=new Date(),seen=[];
  for(let i=0;i<count;i++){const d=new Date(now.getFullYear(),now.getMonth()-i,1);seen.push(`${d.getFullYear()}-${pad2(d.getMonth()+1)}`)}
  if(selected&&/^\d{4}-\d{2}$/.test(selected)&&!seen.includes(selected))seen.push(selected);
  return seen.map(v=>{const [y,m]=v.split('-');return `<option value="${v}"${v===selected?' selected':''}>${cap(MONTHS[Number(m)-1])} ${y}</option>`}).join('');
};
const monthNameShort=p=>{const [y,m]=String(p).split('-');return MONTHS[Number(m)-1]?`${MONTHS[Number(m)-1]} ${y}`:p};
const monthName=period=>{const [y,m]=String(period||'').split('-');return MONTHS[Number(m)-1]?`${MONTHS[Number(m)-1]} de ${y}`:period};

async function request(path,method='GET',csrf='',body=null){
  const r=await fetch((window.AGORA_API||'/api/')+path,{method,cache:'no-store',...(body!==null?{body:JSON.stringify(body)}:{}),headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrf}:{})}});
  let data;try{data=await r.json()}catch{throw Object.assign(Error(`El servidor devolvió una respuesta no válida (HTTP ${r.status}).`),{status:r.status})}
  if(!r.ok)throw Object.assign(Error((data.error||'Error de conexión')+(data.retryAfter?` Espera ${data.retryAfter} segundos.`:'')),{status:r.status,code:data.code});
  return data;
}

/* =====================================================================================
   Componentes del Tablero Comercial v3 (paneles, métricas, barras, gráficos, tablas)
   ===================================================================================== */
const compact=new Intl.NumberFormat('es-ES',{notation:'compact',maximumFractionDigits:1});
const tip=html=>` data-tip="${esc(html)}"`;
const niceMax=v=>{const p=10**Math.floor(Math.log10(v||1)),n=v/p;return (n<=1?1:n<=2?2:n<=2.5?2.5:n<=5?5:10)*p};
/** Cifra de una tarjeta. `note` puede ser texto o {html} (ya escapado). */
function metric(label,value,note,cls=''){
  return `<div class="micro ${cls}"><h3>${esc(label)}</h3><p class="t-metric">${value===null||value===undefined?'—':esc(value)}</p>${note?`<span class="f">${typeof note==='object'?note.html:esc(note)}</span>`:''}</div>`;
}
/** Una fila de tarjetas: si queda una sola en la última fila, ocupa todo el ancho. */
const metricGrid=items=>`<div class="grid g2">${items.map((html,i)=>items.length%2===1&&i===items.length-1?html.replace('class="micro ','class="micro span2 '):html).join('')}</div>`;
const panel=(title,sub,body,extra='')=>`<section class="panel"><div class="panel-h"><div><h2 class="t-panel">${title}</h2>${sub?`<p>${sub}</p>`:''}</div>${extra}</div>${body}</section>`;
const sec=(title,sub='',acts='')=>sub||acts
  ?`<div class="t-sec-row"><div><h2 class="t-sec">${title}</h2>${sub?`<p>${sub}</p>`:''}</div>${acts}</div>`
  :`<h2 class="t-sec">${title}</h2>`;
const empty=(title,text='')=>`<p class="empty"><b>${esc(title)}</b>${esc(text)}</p>`;

/** Barras horizontales. Cada elemento: {l, v, t?, label, small?, tip?, kind?}. */
function bars(items,{max}={}){
  const top=max??Math.max(1,...items.map(i=>Math.max(i.v||0,i.t||0)));
  return `<div class="bars">${items.map(i=>`<div class="bar-row"${tip(i.tip||`<b>${esc(i.l)}</b><br>${esc(i.label)}`)}><span class="lab" title="${esc(i.l)}">${esc(i.l)}</span><span class="track"><span class="fill ${esc(i.kind||'')}" style="width:${Math.min(100,100*(i.v||0)/top)}%"></span>${i.t!=null?`<span class="target" style="left:${Math.min(100,100*i.t/top)}%"></span>`:''}</span><span class="val">${esc(i.label)}${i.small?`<small>${esc(i.small)}</small>`:''}</span></div>`).join('')}</div>`;
}

/**
 * De dónde sale la ganancia: ventas, lo que se va en publicidad y comisiones,
 * y lo que queda. Columnas flotantes a escala, con el estilo de gráficos del v3.
 */
function waterfall(p){
  const sales=Number(p.sales)||0;
  if(sales<=0)return empty('Todavía no hay nada cerrado este mes.');
  const ads=p.ads===null||p.ads===undefined?null:Number(p.ads);
  const commissions=Number(p.commissions)||0;
  const profit=p.profit===null||p.profit===undefined?null:Number(p.profit);
  const afterAds=ads===null?sales:sales-ads;
  const afterCom=afterAds-commissions;
  const narrow=innerWidth<760;
  const share=v=>`${number(Math.round(Math.abs(v)/sales*100))} % de las ventas`;
  const steps=[
    {l:'Ventas',a:0,b:sales,color:'var(--c-deep)',text:money(sales),tip:`<b>Ventas</b><br>${esc(money(sales))}`},
    {l:narrow?'Publicidad':'Publicidad y gastos',a:sales,b:afterAds,missing:ads===null,color:'var(--muted-2)',text:ads===null?'':'−'+money(ads),tip:ads===null?'<b>Publicidad y gastos</b><br>Falta el dato':`<b>Publicidad y gastos</b><br>−${esc(money(ads))}<br>${share(ads)}`},
    {l:'Comisiones',a:afterAds,b:afterCom,color:'var(--muted-2)',text:'−'+money(commissions),tip:`<b>Comisiones</b><br>−${esc(money(commissions))}<br>${share(commissions)}`},
    {l:'Ganancia',a:0,b:profit??0,missing:profit===null,color:(profit??0)<0?'var(--bad-solid)':'var(--brand)',text:profit===null?'':(profit<0?'−':'')+money(Math.abs(profit)),tip:profit===null?'<b>Ganancia</b><br>Falta el dato':`<b>Ganancia</b><br>${profit<0?'−':''}${esc(money(Math.abs(profit)))}${profit>0?'<br>'+share(profit):''}`},
  ];
  const ends=steps.flatMap(s=>s.missing?[0]:[s.a,s.b]);
  const hi=niceMax(Math.max(sales,...ends)),lowest=Math.min(0,...ends),lo=lowest<0?-niceMax(-lowest):0;
  const W=narrow?400:600,H=260,L=narrow?44:54,R=12,T=30,B=34,w=W-L-R,ih=H-T-B;
  const y=v=>T+ih-(v-lo)/(hi-lo)*ih,x=i=>L+(i+.5)*w/steps.length,bw=Math.min(66,w/steps.length*.56);
  let g='';
  for(let k=0;k<=4;k++){const v=lo+(hi-lo)*k/4;g+=`<line class="gl" x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end">${esc(compact.format(v))}</text>`}
  if(lo<0)g+=`<line class="zero" x1="${L}" x2="${W-R}" y1="${y(0)}" y2="${y(0)}"/>`;
  steps.forEach((s,i)=>{
    const cx=x(i);
    if(s.missing){
      g+=`<rect class="miss" x="${cx-bw/2}" y="${y(0)-34}" width="${bw}" height="34" rx="6"/><text class="dl" x="${cx}" y="${y(0)-42}" text-anchor="middle">Falta el dato</text>`;
    }else{
      const top=y(Math.max(s.a,s.b)),height=Math.max(3,Math.abs(y(s.a)-y(s.b)));
      g+=`<rect x="${cx-bw/2}" y="${top}" width="${bw}" height="${height}" rx="6" fill="${s.color}"/><text class="dl" x="${cx}" y="${top-7}" text-anchor="middle">${esc(s.text)}</text>`;
      if(i<steps.length-1)g+=`<line class="link" x1="${cx+bw/2}" x2="${x(i+1)-bw/2}" y1="${y(s.b)}" y2="${y(s.b)}"/>`;
    }
    g+=`<text x="${cx}" y="${H-10}" text-anchor="middle">${esc(s.l)}</text>`;
    g+=`<rect class="hit" x="${cx-w/steps.length/2}" y="${T}" width="${w/steps.length}" height="${ih}"${tip(s.tip)}/>`;
  });
  const summary=`Ventas ${money(sales)}${ads===null?'':', publicidad y gastos '+money(ads)}, comisiones ${money(commissions)}${profit===null?'':', ganancia '+money(profit)}`;
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="De las ventas del mes a la ganancia. ${esc(summary)}">${g}</svg>`;
}

/** La regla de comisión en palabras: «10 %» o «5,00 por cierre». */
function commissionText(rule,word='cierres'){
  if(!rule)return '10 %';
  const one=String(word).replace(/s$/,'');
  return rule.kind==='per_closing'?`${money(rule.amount)} por ${one}`:`${number(rule.amount)} %`;
}
/** De dónde sale cada cifra, a un toque, para quien se pregunte «¿y esto de dónde?». */
function origin(month,word){
  const one=String(word).replace(/s$/,'');
  const rule=month.commission||{kind:'percent',amount:10};
  const commission=rule.kind==='per_closing'?`el monto fijo por ${one} (${money(rule.amount)}) por el número de ${word}`:`el ${number(rule.amount)} % de las ventas`;
  const row=(name,text)=>`<li><b>${esc(name)}</b>${esc(text)}</li>`;
  return `<details class="origin"><summary>¿De dónde salen estas cifras?</summary><ul>
    ${row('Ventas y '+word+': ','lo ganado en el mes en tu cuenta, más lo que se marca como «¿Venta ganada?» desde Ágora. Cada venta cuenta en el mes en que se cierra.')}
    ${row('Leads: ','los que la cuenta le asignó a cada quien dentro del mes. Un lead cuenta en el mes en que se asignó, no en el que entró.')}
    ${row('Conversión: ','los '+word+' de cada quien entre sus leads asignados del mes, por cien. El total del equipo usa la suma de los dos, no el promedio de los porcentajes.')}
    ${row('Publicidad: ','lo gastado en la cuenta publicitaria de Meta conectada durante el mes, más lo que escribas en «Cifras del mes» como otros gastos.')}
    ${row('Comisiones: ','calculadas con '+commission+'. La regla la fija el administrador en Conexiones y vale desde el mes en que se cambia.')}
    ${row('Ganancia: ','ventas menos publicidad y comisiones.')}
    ${row('Ganancia real del mes: ','la ganancia menos los costos fijos que escribes en «Cifras del mes».')}
    ${row('Costo por '+one+': ','publicidad entre el número de '+word+'.')}
    ${row('Ventas por cada 100 invertido: ','ventas entre publicidad, por cien.')}
    ${row('Vendedores: ','el equipo de tu cuenta. Quienes administran no aparecen aquí, pero lo que cierran sí cuenta en el total.')}
    ${row('Metas y costos fijos: ','los escribes tú en «Cifras del mes»; se guardan por subcuenta y por mes.')}
  </ul></details>`;
}

const STATES={lograda:['Meta lograda','ok'],cerca:['Cerca de la meta','warn'],apoyo:['Necesita apoyo','bad'],'sin-meta':['Sin meta fijada','none']};
const lamp=state=>{const [label,kind]=STATES[state]||STATES['sin-meta'];return `<span class="lt lt-${kind}"><i aria-hidden="true"></i>${esc(label)}</span>`};

function teamTable(data){
  const rows=asList(data.team);
  if(!rows.length)return empty('Todavía no hay equipo importado en esta cuenta.');
  const word=data.settings?.closingWord||'cierres';
  const heading=word[0].toUpperCase()+word.slice(1);
  const cell=value=>value===null||value===undefined?'—':esc(money(value));
  const diff=value=>value===null||value===undefined?'—':`<span class="${Number(value)<0?'down':'up'}">${Number(value)>=0?'+':'−'}${esc(money(Math.abs(value)))}</span>`;
  const kindOf=progress=>progress===null||progress===undefined?'':progress>=data.settings.green?'ok':progress>=data.settings.amber?'warn':'bad';
  // Los leads del mes por ejecutivo, tal como la cuenta los asignó, y la tasa de
  // conversión que sale sola de ellos: cierres entre leads asignados. Si la cuenta
  // todavía no informa los leads, las dos columnas quedan con una raya.
  const leadsDe=row=>row.leads===null||row.leads===undefined?null:Number(row.leads);
  const tasa=(cierres,leads)=>leads?Math.round(((Number(cierres)||0)/leads)*1000)/10:null;
  const tasaCell=v=>v===null?'<span class="muted">—</span>':`${number(v)} %`;
  const leadsEquipo=rows.reduce((suma,row)=>leadsDe(row)===null?suma:suma+leadsDe(row),0);
  const body=rows.map(row=>{
    const width=Math.max(0,Math.min(100,Number(row.progress)||0));
    // Cada celda lleva su rótulo: en un teléfono la fila se lee como tarjeta.
    return `<tr><th scope="row">${esc(row.name)}</th><td class="n" data-label="Leads">${leadsDe(row)===null?'<span class="muted">—</span>':number(leadsDe(row))}</td><td class="n" data-label="${esc(heading)}">${number(row.closings)}</td><td class="n" data-label="Conversión">${tasaCell(tasa(row.closings,leadsDe(row)))}</td><td class="n" data-label="Meta">${cell(row.goal)}</td><td class="n" data-label="Vendido">${cell(row.sold)}</td>
      <td class="n" data-label="Diferencia">${diff(row.difference)}</td>
      <td data-label="Avance"><span class="cell-bar"><span class="track">${row.progress===null||row.progress===undefined?'':`<span class="fill ${kindOf(row.progress)}" style="width:${width}%"></span>`}</span><b>${row.progress===null?'—':number(Math.round(row.progress))+' %'}</b></span></td>
      <td data-label="Estado">${lamp(row.state)}</td></tr>`;
  }).join('');
  const goal=data.goal||{},sales=data.sales||{};
  const total=goal.target!==null&&goal.target!==undefined&&sales.total!==null&&sales.total!==undefined
    ?`<tfoot><tr><td>Total del equipo</td><td class="n" data-label="Leads">${leadsEquipo?number(leadsEquipo):'—'}</td><td class="n" data-label="${esc(heading)}">${number(sales.closings??0)}</td><td class="n" data-label="Conversión"><b>${tasaCell(tasa(sales.closings,leadsEquipo))}</b></td><td class="n" data-label="Meta">${cell(goal.target)}</td><td class="n" data-label="Vendido">${cell(sales.total)}</td><td class="n" data-label="Diferencia">${diff(Number(sales.total)-Number(goal.target))}</td><td data-label="Avance">${goal.progress===null||goal.progress===undefined?'—':`<b>${number(Math.round(goal.progress))} %</b>`}</td><td></td></tr></tfoot>`:'';
  return `<div class="tw stack"><table><thead><tr>
    <th scope="col">Asesora</th><th scope="col" class="n" title="Leads que se le asignaron en el mes">Leads</th><th scope="col" class="n">${esc(heading)}</th><th scope="col" class="n" title="Cierres entre leads asignados">Conversión</th><th scope="col" class="n">Meta</th><th scope="col" class="n">Vendido</th><th scope="col" class="n">Diferencia</th><th scope="col">Avance</th><th scope="col">Estado</th>
  </tr></thead><tbody>${body}</tbody>${total}</table></div>`;
}

export async function renderDashboard(container){
  const instance=Symbol();container.agoraViewInstance=instance;
  const active=()=>container.agoraViewInstance===instance&&container.dataset.view==='dashboard';
  const connection=workspace.current();
  if(!connection){container.innerHTML=`<div class="tv3"><p class="empty">${esc(workspace.noAccountText('el tablero'))}</p></div>`;return}
  let sel={kind:'today'};
  try{const saved=JSON.parse(localStorage.getItem('agora-board-period')||'null');if(saved&&PRESETS.some(p=>p[0]===saved.kind))sel=saved}catch{}
  container.innerHTML=`<div class="tv3 enter">
    <header class="mod-h"><div><p class="t-label">Tablero</p><h1 class="t-module">Así va tu cuenta.</h1><p id="dashboard-feedback" class="lede" role="status" hidden></p></div><div id="period-bar" class="acts"></div></header>
    <div id="dashboard-body">${skeleton('tiles',4)}</div></div>`;
  const $=s=>container.querySelector(s);
  let csrf='',month=null,period=periodOf(sel).month,range=periodOf(sel);
  const today=ymd(new Date());
  const CHEVRON='<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  const QUICK=[['today','Hoy'],['yesterday','Ayer'],['week','7 días'],['d30','30 días'],['month','Este mes'],['prev','Mes anterior']];
  const nowLabel=()=>{const r=periodOf(sel);
    if(sel.kind==='today')return `Hoy · ${dayLabel(r.from)}`;
    if(sel.kind==='yesterday')return `Ayer · ${dayLabel(r.from)}`;
    if(sel.kind==='week')return 'Últimos 7 días';if(sel.kind==='d30')return 'Últimos 30 días';
    if(sel.kind==='month'||sel.kind==='prev'||sel.kind==='monthpick')return r.month?monthName(r.month):r.label;
    return r.label};

  /* ----- Guía flotante de los gráficos y barras (se cuelga de <body>) ----- */
  const tipEl=document.createElement('div');tipEl.className='tv3-tip';tipEl.setAttribute('role','tooltip');document.body.appendChild(tipEl);
  let tipTarget=null,tipTimer=0;
  const hideTip=()=>{tipTarget=null;tipEl.classList.remove('on')};
  const moveTip=e=>{
    const node=e.target.closest?.('[data-tip]');
    if(!node||!container.contains(node)){hideTip();return}
    if(node!==tipTarget){tipTarget=node;tipEl.innerHTML=node.dataset.tip}
    tipEl.classList.add('on');
    const w=tipEl.offsetWidth,h=tipEl.offsetHeight;let left=e.clientX+14,top=e.clientY+16;
    if(left+w>innerWidth-8)left=e.clientX-w-14;if(top+h>innerHeight-8)top=e.clientY-h-14;
    tipEl.style.left=Math.max(8,left)+'px';tipEl.style.top=Math.max(8,top)+'px';
  };
  const touchTip=e=>{if(e.pointerType==='mouse')return;moveTip(e);clearTimeout(tipTimer);tipTimer=setTimeout(hideTip,2600)};
  container.addEventListener('pointermove',e=>{if(e.pointerType==='mouse')moveTip(e)});
  container.addEventListener('pointerleave',hideTip);
  container.addEventListener('pointerdown',touchTip);
  window.addEventListener('scroll',hideTip,true);

  /* ----- La pieza del control segmentado se desliza hasta la opción elegida ----- */
  function placeThumbs(animate=false){
    container.querySelectorAll('.seg').forEach(seg=>{
      const on=seg.querySelector('.seg-b.is-on'),thumb=seg.querySelector('.seg-thumb');if(!thumb)return;
      if(!on||!on.offsetWidth){thumb.style.opacity=0;return}
      if(!animate)thumb.style.transition='none';
      thumb.style.opacity=1;thumb.style.width=on.offsetWidth+'px';thumb.style.transform=`translateX(${on.offsetLeft}px)`;
      if(!animate){void thumb.offsetWidth;thumb.style.transition=''}
    });
  }
  const onResize=()=>placeThumbs(false);
  window.addEventListener('resize',onResize);

  // Quien administra Ágora elige quién es entre los usuarios de la subcuenta; los demás se reconocen por su correo.
  const unlinkedNote=()=>{
    const isOwner=workspace.me?.user?.role==='administrator'&&workspace.me?.user?.identity_type==='native';
    return isOwner?{html:'<button type="button" class="lnk" data-self>Elegir quién soy</button>'}:'Usa en Ágora el mismo correo que en la cuenta';
  };
  let restricted=false;

  let menuOpen=false;
  const closeMenu=()=>{if(!menuOpen)return;menuOpen=false;const m=$('#period-menu'),b=$('#period-btn');if(m){m.hidden=true;b?.setAttribute('aria-expanded','false')}};
  function paintBar(animate=false){
    const bar=$('#period-bar');
    const before=bar.querySelector('.seg-thumb');
    const from=before&&before.style.opacity==='1'?{width:before.style.width,transform:before.style.transform}:null;
    const other=['monthpick','custom'].includes(sel.kind);
    bar.innerHTML=`<div class="period">
      <div class="seg" role="radiogroup" aria-label="Periodo"><span class="seg-thumb"></span>${QUICK.map(([k,l])=>`<button type="button" role="radio" aria-checked="${sel.kind===k}" class="seg-b${sel.kind===k?' is-on':''}" data-period="${k}">${l}</button>`).join('')}</div>
      <button type="button" id="period-btn" class="btn${other?' btn-tint':''}" aria-haspopup="true" aria-expanded="${menuOpen}">${other?esc(sel.kind==='monthpick'?cap(monthNameShort(periodOf(sel).month)):periodOf(sel).label):'Otro periodo'}${CHEVRON}</button>
      <div id="period-menu" class="pop" role="dialog" aria-label="Otro periodo"${menuOpen?'':' hidden'}>
        <label class="fld">Otro mes<select id="period-month"><option value="">Elegir mes…</option>${monthOptions(sel.kind==='monthpick'?sel.month:'')}</select></label>
        <div class="rng"><label class="fld">Desde<input type="date" id="period-from" value="${esc(sel.kind==='custom'?sel.from:'')}" max="${today}"></label><label class="fld">Hasta<input type="date" id="period-to" value="${esc(sel.kind==='custom'?sel.to:'')}" max="${today}"></label></div>
        <button type="button" id="period-apply" class="btn btn-cta" disabled>Aplicar rango</button>
      </div></div>`;
    $('#period-btn').onclick=e=>{e.stopPropagation();menuOpen=!menuOpen;$('#period-menu').hidden=!menuOpen;$('#period-btn').setAttribute('aria-expanded',String(menuOpen))};
    bar.querySelectorAll('[data-period]').forEach(b=>{
      b.onclick=()=>{menuOpen=false;choose({kind:b.dataset.period})};
      // Flechas para pasar de una opción a otra, como en cualquier grupo de opciones.
      b.onkeydown=e=>{
        if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;
        const all=[...bar.querySelectorAll('[data-period]')],next=all[(all.indexOf(b)+(e.key==='ArrowRight'?1:-1)+all.length)%all.length];
        e.preventDefault();next.focus();next.click();
      };
    });
    const m=$('#period-month'),f=$('#period-from'),t=$('#period-to'),apply=$('#period-apply');
    m.onchange=()=>{if(/^\d{4}-\d{2}$/.test(m.value)){menuOpen=false;choose({kind:'monthpick',month:m.value})}};
    const ready=()=>{apply.disabled=!(f.value&&t.value&&f.value<=t.value)};
    // Un periodo se elige o con los botones o con el mes/rango, nunca los dos a la vez: al tocar uno, el otro se apaga.
    const clearPresets=()=>bar.querySelectorAll('.seg-b').forEach(b=>{b.classList.remove('is-on');b.setAttribute('aria-checked','false');placeThumbs(true)});
    m.oninput=()=>{f.value='';t.value='';ready();clearPresets()};
    f.oninput=t.oninput=()=>{m.value='';ready();clearPresets()};
    f.onchange=t.onchange=ready;ready();
    apply.onclick=()=>{if(!apply.disabled){menuOpen=false;choose({kind:'custom',from:f.value,to:t.value})}};
    const thumb=bar.querySelector('.seg-thumb');
    if(from&&animate&&thumb){thumb.style.transition='none';thumb.style.opacity=1;thumb.style.width=from.width;thumb.style.transform=from.transform;void thumb.offsetWidth;thumb.style.transition=''}
    requestAnimationFrame(()=>placeThumbs(animate&&!!from));
  }
  // Se cierra al pulsar fuera o con Escape.
  const outside=e=>{if(menuOpen&&!e.target.closest('.period'))closeMenu()};
  const escape=e=>{if(e.key==='Escape'&&menuOpen){closeMenu();$('#period-btn')?.focus()}};
  document.addEventListener('click',outside);
  document.addEventListener('keydown',escape);
  function choose(next){
    const before=sel.kind;
    sel=next;try{localStorage.setItem('agora-board-period',JSON.stringify(sel))}catch{}
    range=periodOf(sel);period=range.month;
    // Si sólo cambia entre las opciones rápidas, la pieza se desliza; si no, se vuelve a dibujar.
    paintBar(QUICK.some(q=>q[0]===before)&&QUICK.some(q=>q[0]===next.kind));
    // «Otro mes» y «Rango» esperan a que se elija la fecha; el resto carga de inmediato.
    if((sel.kind==='monthpick'&&!sel.month)||(sel.kind==='custom'&&!(sel.from&&sel.to)))return;
    $('#dashboard-body').innerHTML=skeleton('tiles',4);load();
  }
  window.addEventListener('agora:won-alert',onWon);
  container.agoraLiveDispose=()=>{
    container.agoraViewInstance=null;
    document.removeEventListener('click',outside);document.removeEventListener('keydown',escape);
    window.removeEventListener('resize',onResize);window.removeEventListener('scroll',hideTip,true);
    window.removeEventListener('agora:won-alert',onWon);
    clearTimeout(tipTimer);tipEl.remove();
  };
  paintBar();
  try{csrf=(await request('me')).csrf||''}catch{}

  async function load(){
    if(!$('#dashboard-body').children.length||$('#dashboard-body .sk-wrap'))$('#dashboard-body').innerHTML=skeleton('tiles',4);
    try{
      const zone=(()=>{try{return Intl.DateTimeFormat().resolvedOptions().timeZone||''}catch{return ''}})();
      const now=await request(`workspace/dashboard?connectionId=${encodeURIComponent(connection)}${zone?'&tz='+encodeURIComponent(zone):''}&from=${range.from}&to=${range.to}`);
      if(!active())return;
      paint(now,null);
      try{month=await request(`workspace/board-month?connectionId=${encodeURIComponent(connection)}&period=${period}`)}
      catch(error){month={error:friendly(error)}}
      if(!active())return;
      paint(now,month);
      // La operación del día, los anuncios y la eficacia de ventas se piden aparte,
      // para que una cuenta publicitaria lenta no retrase el resto del tablero.
      pintarExtras(container,{connection,period,request,active});
    }catch(error){
      if(!active())return;
      const feedback=$('#dashboard-feedback');feedback.hidden=false;feedback.textContent=friendly(error);
      $('#dashboard-body').innerHTML='';
      if(error.status===401)window.dispatchEvent(new Event('agora:logout'));
    }
  }

  function paint(data,month){
    const read=data.readAt?new Date(data.readAt).toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'}):'';
    const feedback=$('#dashboard-feedback');feedback.hidden=false;feedback.textContent=`${data.restricted?'Tus cifras':'Cifras de la cuenta'} · ${nowLabel()}${read?` · actualizado a las ${read}`:''}`;
    const unread=data.conversations?.unread??0;
    const unlinked=unlinkedNote();
    restricted=data.restricted===true;
    const leads=data.leads||null;
    const noData='La cuenta no devolvió este dato';

    // Lo del día: la cifra grande son los leads del periodo (o las conversaciones, si la cuenta no da leads).
    const leadsValue=leads?(leads.today===null||leads.today===undefined?null:number(leads.today)):null;
    const heroLabel=leads?(sel.kind==='today'?'Leads de hoy':sel.kind==='yesterday'?'Leads de ayer':'Leads nuevos'):'Conversaciones';
    const heroValue=leads?leadsValue:number(data.conversations?.total??0);
    const heroNote=leads?(leadsValue===null?noData:nowLabel()):'En esta cuenta';
    const mineValue=leads?(leads.mine===null||leads.mine===undefined?null:number(leads.mine)):number(unread);
    const heroPair=leads
      ?`<div class="pair"><span>Leads asignados a mí</span><b>${mineValue===null?'—':esc(mineValue)}</b></div><p class="f">${leads.linked?(mineValue===null?esc(noData):'Los que tienes a tu nombre en la cuenta'):(typeof unlinked==='object'?unlinked.html:esc(unlinked))}</p>`
      :`<div class="pair"><span>Sin leer</span><b>${esc(mineValue)}</b></div>`;
    const tiles=[
      ...(leads?[metric('Conversaciones',number(data.conversations?.total??0))]:[]),
      ...(leads?[metric('Sin leer',number(unread))]:[]),
      ...(data.conversations?.waiting!==undefined?[metric('Esperando respuesta',number(data.conversations.waiting),{html:'<button type="button" class="lnk" data-go-waiting>Ver la lista</button>'})]:[]),
      ...(data.contacts!==null&&data.contacts!==undefined?[metric('Contactos',number(data.contacts))]:[]),
      ...(data.opportunities?[metric('Oportunidades abiertas',number(data.opportunities.count),`${money(data.opportunities.value)} en juego`)]:[]),
    ];

    const stages=data.opportunities?asList(data.opportunities.stages):[];
    let funnel;
    if(!stages.length)funnel=empty('Todavía no hay oportunidades abiertas en esta cuenta.');
    else{
      const byValue=stages.some(s=>Number(s.value)>0);
      funnel=bars(stages.map(stage=>({
        l:stage.name,v:byValue?Number(stage.value)||0:Number(stage.count)||0,
        label:byValue?(money(stage.value)??'—'):`${number(stage.count)}`,
        small:`${number(stage.count)} oportunidad${stage.count===1?'':'es'}`,
        tip:`<b>${esc(stage.name)}</b><br>${number(stage.count)} oportunidad${stage.count===1?'':'es'}<br>${esc(money(stage.value)??'—')}`,
      })),{});
    }
    const heading=sel.kind==='today'?'Tu día':cap(nowLabel());
    $('#dashboard-body').innerHTML=`${sec(esc(heading),'Conversaciones, leads y oportunidades abiertas de la cuenta.')}
      <div class="grid g-hero">
        <section class="hero"><div><p class="t-label">${esc(heroLabel)}</p><p class="t-hero" style="margin-top:10px">${heroValue===null?'—':esc(heroValue)}</p><p class="f">${esc(heroNote)}</p></div><div class="goal">${heroPair}</div></section>
        ${metricGrid(tiles)}
      </div>
      <section id="won-team" hidden></section>
      ${slotsDia()}
      ${sec('Embudo por etapa','Cuánto hay en juego en cada etapa de tus embudos.')}
      ${panel('Oportunidades abiertas','Ordenadas por monto, de la etapa con más dinero a la que menos.',funnel+(data.opportunities?.sampled?'<p class="src">Se resumen las oportunidades abiertas más recientes.</p>':''))}
      <div id="board-month">${monthBlock(month)}</div>
      ${slotEficacia()}`;
    paintWonTeam();
    bindMonth();
    container.querySelectorAll('[data-self]').forEach(b=>b.onclick=selfDialog);
    container.querySelectorAll('[data-go-waiting]').forEach(b=>b.onclick=()=>window.dispatchEvent(new CustomEvent('agora:goto',{detail:{view:'inbox',filter:'waiting'}})));
  }

  function monthBlock(month){
    if(!month)return sec('Rentabilidad del mes')+skeleton('lines',3);
    if(month.error)return sec('Rentabilidad del mes')+panel('No se pudo leer el mes','',empty(month.error));
    // Un resumen con otra forma no puede llevarse por delante el resto del tablero.
    if(!month.profitability||!month.settings||!month.goal)return sec('Rentabilidad del mes')+panel('El resumen del mes no llegó completo','',empty('Vuelve a entrar en un momento.'));
    const p=month.profitability,word=month.settings?.closingWord||'cierres',one=word.replace(/s$/,'');
    const missing=asList(month.missing);
    const NAMES={ads:'lo invertido en publicidad',fixedCosts:'los costos fijos',teamGoal:'la meta del equipo'};
    // De dónde sale la publicidad, o por qué la cuenta no la ha dado.
    const WHY={permission:'La clave de la cuenta no tiene permiso para leer los anuncios. Pídele a quien administra Ágora que lo añada.',
      not_connected:'La cuenta no tiene una cuenta publicitaria de Meta conectada.',
      no_spend:'La cuenta publicitaria no informa gasto para este mes.',
      unreadable:'La cuenta publicitaria respondió con un formato que no se pudo leer.'};
    const adsLine=p.adsFromAccount!==null&&p.adsFromAccount!==undefined
      ? `<p class="src">Publicidad: ${esc(money(p.adsFromAccount))} según la cuenta publicitaria de Meta conectada${p.adsOther?` + ${esc(money(p.adsOther))} de otros gastos indicados aparte`:''}.</p>`
      : (p.adsReason&&p.adsReason!=='restricted'?`<div class="note-gold warn">${esc(WHY[p.adsReason]||'La cuenta no ha informado lo invertido en publicidad.')}${p.adsOther?` Se usan ${esc(money(p.adsOther))} indicados aparte.`:''}</div>`:'');
    const warn=missing.length
      ? `<div class="note-gold">Faltan por indicar ${esc(missing.map(k=>NAMES[k]||k).join(', '))}. ${month.canEdit?'Pulsa «Cifras del mes» para completarlos.':'Pídeselo a quien administra Ágora.'}</div>`
      : '';
    const actions=`<div class="acts"><label class="fld">Mes<select id="board-period">${monthOptions(month.period)}</select></label>${month.canEdit?'<button type="button" data-board-settings class="btn btn-cta">Cifras del mes</button>':''}</div>`;
    const sales=month.sales||{};
    const tiles=[
      ...(!restricted?[metric('Ventas ganadas del mes',number(sales.closings??0),`${money(sales.total??0)} en total`)]:[]),
      metric('Mis ventas del mes',month.mine?number(month.mine.closings):null,month.mine?`${money(month.mine.sold)} ganados`:unlinkedNote()),
      metric('Ganancia real del mes',money(p.net),p.net===null?'Falta indicar los costos fijos':`Después de ${money(p.fixedCosts)} en costos fijos`),
      metric(`Costo por ${one}`,money(p.costPerClosing),p.costPerClosing===null?'Falta lo invertido en publicidad':`${money(p.ads)} entre ${number(sales.closings)} ${word}`),
      metric('Ventas por cada 100 invertido',money(p.returnPerHundred)),
      metric('Costos de mercadeo y ventas',money(p.marketingCost),p.marketingCost===null?'Faltan datos':`Fijos ${money(p.fixedCosts??0)} · variables ${money(p.ads??0)}`),
      metric(`Comisiones del equipo (${commissionText(month.commission,word)})`,money(p.commissions),month.commission?.kind==='per_closing'?`${number(sales.closings)} ${word}`:`Sobre ${money(p.sales)} vendidos`),
    ];
    const goal=month.goal;
    const progress=Math.max(0,Math.min(100,Number(goal.progress)||0));
    const counts=asList(month.team).reduce((acc,row)=>{acc[row.state]=(acc[row.state]||0)+1;return acc},{});
    const goalKind=goal.progress===null||goal.progress===undefined?'':goal.progress>=month.settings.green?'ok':goal.progress>=month.settings.amber?'warn':'bad';
    const goalText=goal.target===null?'Indica la meta del mes para ver el avance.':goal.missing>0?`Faltan ${money(goal.missing)} para la meta de ${money(goal.target)}.`:`Meta de ${money(goal.target)} superada.`;
    const lead=p.profit===null?'Indica lo invertido para ver la ganancia.':(p.marginPerUnit!==null?`De cada 1,00 vendido quedan ${money(p.marginPerUnit)}.`:'');
    return `${sec(`Rentabilidad de ${esc(monthName(month.period))}`,'Lo vendido, lo que se va en publicidad y comisiones, y lo que queda.',actions)}
      ${adsLine}${warn}
      <div class="grid g-hero mt">
        <section class="hero"><div><p class="t-label">Ganancia después de publicidad y comisiones</p><p class="t-hero" style="margin-top:10px">${p.profit===null?'—':esc(money(p.profit))}</p>${lead?`<p class="f">${esc(lead)}</p>`:''}</div><div class="goal">${waterfall(p)}</div></section>
        ${metricGrid(tiles)}
      </div>
      ${origin(month,word)}
      ${sec('Desempeño del equipo de ventas',`Verde desde ${number(month.settings.green)} %, ámbar desde ${number(month.settings.amber)} %, rojo por debajo.`)}
      ${panel('Avance frente a la meta','',
        `<div class="goal flat"><div class="pair"><span>Avance del equipo frente a su meta</span><b>${goal.progress===null?'—':number(Math.round(goal.progress))+' %'}</b></div>
          <div class="track" role="img" aria-label="Avance del equipo: ${goal.progress===null?'sin dato':number(Math.round(goal.progress))+' %'}"><span class="fill ${goalKind}" style="width:${progress}%"></span></div>
          <p class="f">${esc(goalText)}</p>
          <div class="lts"><span class="lt lt-ok"><i aria-hidden="true"></i>${number(counts.lograda||0)} con la meta lograda</span><span class="lt lt-warn"><i aria-hidden="true"></i>${number(counts.cerca||0)} cerca de la meta</span><span class="lt lt-bad"><i aria-hidden="true"></i>${number(counts.apoyo||0)} necesitan apoyo</span></div></div>
         ${teamTable(month)}
         <p class="src">${month.sales.partial?'Se resumen los primeros cierres del mes. ':''}${month.sales.counted!==null&&month.sales.counted!==undefined?`${number(month.sales.counted)} ${esc(word)} en el mes.`:''}</p>`)}`;
  }

  // Para quien ve todo: cuántas ventas ganadas siguen sin monto y de quién son. Sale de la misma consulta de la alerta.
  function paintWonTeam(){
    const slot=container.querySelector('#won-team');if(!slot)return;
    const team=wonAlertState()?.team;
    if(!team||!team.missing){slot.hidden=true;slot.innerHTML='';return}
    slot.hidden=false;
    const sellers=asList(team.bySeller);
    slot.innerHTML=`${sec('Ventas ganadas sin monto','Completa el monto para que cuenten en la rentabilidad del mes.')}
      ${panel(`${number(team.missing)} ${team.missing===1?'venta sin monto este mes':'ventas sin monto este mes'}`,'Por quién las cerró.',
        bars(sellers.map(b=>({l:b.name,v:Number(b.missing)||0,label:number(b.missing),kind:'warn',tip:`<b>${esc(b.name)}</b><br>${number(b.missing)} sin monto`})))
        ,'<button type="button" class="btn btn-sm btn-tint" data-go-won>Ver y completar en Ganadas</button>')}`;
    slot.querySelector('[data-go-won]').onclick=()=>{workspace.pendingOppTab='won';window.dispatchEvent(new CustomEvent('agora:goto',{detail:{view:'board'}}))};
  }
  function onWon(){if(!container.isConnected||container.dataset.view!=='dashboard'){window.removeEventListener('agora:won-alert',onWon);return}paintWonTeam()}
  async function selfDialog(){
    const dialog=document.querySelector('#action-dialog'),content=document.querySelector('#dialog-content');
    const wrap=inner=>`<div class="tv3 tv3-dialog"><h2>¿Quién eres en esta subcuenta?</h2>${inner}</div>`;
    content.innerHTML=wrap('<p class="lede">Leyendo los usuarios…</p>');
    if(!dialog.open)dialog.showModal();
    try{
      const data=await request(`workspace/self?connectionId=${encodeURIComponent(connection)}`);
      const rows=Array.isArray(data.options)?data.options:[];
      content.innerHTML=wrap(`<p class="lede">Con esto, «Leads asignados a mí» y «Mis ventas del mes» cuentan lo que tiene asignado ese usuario. Se guarda sólo para ti en esta subcuenta.</p>
       <form id="self-form" class="form"><label class="fld">Soy<select name="who"><option value="">Ninguno (no mostrar mis cifras)</option>${rows.map(r=>`<option value="${esc(r.id)}"${r.id===(data.linked||data.detected)?' selected':''}>${esc(r.name)}${r.email?` · ${esc(r.email)}`:''}</option>`).join('')}</select></label>
       <div class="form-ft"><button class="btn btn-cta">Guardar</button><button type="button" class="btn" data-close-dialog>Cerrar</button><p id="self-result" role="status" class="form-msg"></p></div></form>`);
      content.querySelector('[data-close-dialog]').onclick=()=>dialog.close();
      content.querySelector('#self-form').onsubmit=async e=>{
        e.preventDefault();const result=content.querySelector('#self-result');result.textContent='Guardando…';
        try{await request(`workspace/self?connectionId=${encodeURIComponent(connection)}`,'PUT',csrf,{externalUserId:e.target.elements.who.value||null});dialog.close();$('#dashboard-body').innerHTML=skeleton('tiles',4);load()}
        catch(error){result.textContent=friendly(error)}
      };
    }catch(error){content.innerHTML=wrap(`<p class="lede">${esc(friendly(error))}</p>`)}
  }
  function bindMonth(){
    const pick=$('#board-period');
    if(pick)pick.onchange=()=>{if(/^\d{4}-\d{2}$/.test(pick.value))choose({kind:'monthpick',month:pick.value})};
    const settings=$('[data-board-settings]');
    if(settings)settings.onclick=()=>openSettings();
  }

  /** Las cifras que la cuenta no conoce las escribe el propietario, por mes. */
  function openSettings(){
    const dialog=document.querySelector('#action-dialog');
    const s=month.settings||{};
    const rows=asList(month.team).filter(row=>row.id).map(row=>
      `<label class="fld">${esc(row.name)}<input type="number" min="0" step="0.01" data-goal="${esc(row.id)}" value="${row.goal??''}" placeholder="Meta del mes"></label>`).join('');
    document.querySelector('#dialog-content').innerHTML=`<div class="tv3 tv3-dialog"><p class="t-label">${esc(monthName(month.period))}</p>
      <h2>Cifras del mes</h2>
      <p class="lede">Lo que la cuenta no sabe: lo que invertiste, lo que cuesta mantener la operación y las metas. Se guarda sólo para este mes y esta subcuenta.</p>
      <form id="board-form" class="form">
        <p class="form-msg">Lo invertido en Meta lo informa la cuenta publicitaria conectada. Aquí sólo lo que no pasa por ella.</p>
        <label class="fld">Otros gastos de publicidad (fuera de Meta)<input type="number" min="0" step="0.01" name="otherAds" value="${s.otherAds??''}"></label>
        <label class="fld">Costos fijos del mes<input type="number" min="0" step="0.01" name="fixedCosts" value="${s.fixedCosts??''}"></label>
        <label class="fld">Meta de ventas del equipo<input type="number" min="0" step="0.01" name="teamGoal" value="${s.teamGoal??''}"></label>
        <label class="fld">¿Cómo llamas a cada cierre?<input name="closingWord" maxlength="24" value="${esc(s.closingWord||'cierres')}" placeholder="estudiantes, clientes, pólizas…"></label>
        <p class="form-sec">Umbrales del semáforo</p>
        <div class="grid g2 g-keep"><label class="fld">Verde desde (%)<input type="number" min="0" max="100" step="1" name="green" value="${s.green??100}"></label>
        <label class="fld">Ámbar desde (%)<input type="number" min="0" max="100" step="1" name="amber" value="${s.amber??70}"></label></div>
        ${rows?`<p class="form-sec">Metas por asesora</p><div class="grid g2 g-keep">${rows}</div>`:''}
        <div class="form-ft"><button class="btn btn-cta">Guardar cifras</button><p id="board-form-status" class="form-msg" role="status"></p></div>
      </form></div>`;
    dialog.showModal();
    const form=document.querySelector('#board-form');
    form.onsubmit=async event=>{
      event.preventDefault();
      const status=form.querySelector('#board-form-status'),button=form.querySelector('button.btn-cta');
      button.disabled=true;status.textContent='Guardando…';
      const payload=Object.fromEntries(['otherAds','fixedCosts','teamGoal','closingWord','green','amber'].map(k=>[k,form.elements[k].value]));
      payload.goals=Object.fromEntries([...form.querySelectorAll('[data-goal]')].map(input=>[input.dataset.goal,input.value]));
      try{
        await request(`workspace/board-month?connectionId=${encodeURIComponent(connection)}&period=${period}`,'POST',csrf,payload);
        month=await request(`workspace/board-month?connectionId=${encodeURIComponent(connection)}&period=${period}`);
        if(!active())return;
        dialog.close();
        $('#board-month').innerHTML=monthBlock(month);bindMonth();
      }catch(error){status.textContent=friendly(error);button.disabled=false}
    };
  }

  await load();
}
