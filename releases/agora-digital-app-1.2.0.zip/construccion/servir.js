/* Sirve public_html y finge las dos APIs con los datos de prueba, para comprobar el
   paquete tal como quedará en el servidor (archivos separados, rutas limpias). */
const http=require('http'),fs=require('fs'),path=require('path');
const RAIZ=path.resolve(__dirname,'../public_html');
const TIPOS={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.webmanifest':'application/manifest+json'};
const RUTAS=/^\/(tablero|bandeja|contactos|oportunidades|conexiones|ayuda|contratos|con-convenio|usuarios|personas|registro|entrar)(\/.*)?$/;
http.createServer((req,res)=>{
  const u=new URL(req.url,'http://x');let p=u.pathname;
  if(p.startsWith('/api/')){res.writeHead(401,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'Sin sesión'}))}
  if(p==='/'||RUTAS.test(p)||/^\/conversations\//.test(p))p='/index.html';
  const f=path.join(RAIZ,p);
  if(!f.startsWith(RAIZ)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('no')}
  res.writeHead(200,{'Content-Type':TIPOS[path.extname(f)]||'application/octet-stream'});
  fs.createReadStream(f).pipe(res);
}).listen(8099,()=>console.log('servidor en 8099'));
