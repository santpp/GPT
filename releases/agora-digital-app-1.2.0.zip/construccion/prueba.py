#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Arma prueba.html: un solo archivo, con todo dentro y con datos de prueba.

Se hace así para que se pueda abrir con doble clic, sin servidor: los módulos de ES no
se cargan desde file://, pero un archivo con todo embebido sí funciona. Las rutas se
llevan en el hash (#/tablero), que es lo que el propio panel ya hace en file://.
"""
import pathlib
import sys

A = pathlib.Path('/home/claude/uni/public_html/assets')
OUT = pathlib.Path('/home/claude/uni/prueba.html')

piezas = {n: (A / n).read_text(encoding='utf-8') for n in
          ['sistema.css', 'modulos.css', 'demo.js', 'agora-modulos.js', 'agora-app.js']}

for nombre, texto in piezas.items():
    for peligro in ('</script', '</style'):
        if peligro in texto.lower():
            sys.exit(f'{nombre} contiene «{peligro}»: habría que escaparlo antes de embeberlo.')

CONFIG = """
/* Configuración del archivo de pruebas: las dos APIs las atiende demo.js, aquí mismo. */
window.AGORA_API = '/api/';
window.CONTRATOS_API = '/api/';
window.AGORA_ASSETS = 'assets/';
window.AGORA_MANUAL_PDF = 'assets/manual-vendedores.pdf';
window.AGORA_MAINTENANCE = false;   /* en el archivo de pruebas no hay servidor que vigilar */
"""

AVISO = """
<div class="demo-flag" id="demo-flag">
  <b>Archivo de pruebas</b>
  <span>Todos los módulos con datos inventados. Nada sale a la red y lo que escribas se olvida al recargar.</span>
  <button type="button" onclick="document.getElementById('demo-flag').remove()" aria-label="Ocultar este aviso">Ocultar</button>
</div>
<style>
.demo-flag { position: fixed; left: 50%; bottom: 16px; transform: translateX(-50%); z-index: 120; display: flex; align-items: center; gap: 12px;
  max-width: min(680px, calc(100vw - 24px)); padding: 11px 14px 11px 18px; border-radius: 99px; background: var(--deep); color: #fff;
  font: 500 12.5px/1.4 var(--font-text); box-shadow: 0 18px 40px -18px rgba(0,0,0,.6); }
.demo-flag b { font-weight: 700; white-space: nowrap; }
.demo-flag span { color: rgba(255,255,255,.8); }
.demo-flag button { border: 0; border-radius: 99px; background: rgba(255,255,255,.18); color: #fff; padding: 6px 12px; font: 600 12px/1 var(--font-text); cursor: pointer; }
@media (max-width: 700px) { .demo-flag { border-radius: var(--r-md); } .demo-flag span { display: none; } }
@media print { .demo-flag { display: none !important; } }
</style>
"""

html = f"""<!doctype html>
<html lang="es-VE" data-theme="light" data-accent="vino">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex">
<meta name="theme-color" content="#F5F5F7">
<meta name="color-scheme" content="light dark">
<title>Agora Digital App · archivo de pruebas</title>
<script>
/* El tema, antes de pintar, para que no parpadee. */
(function(){{try{{var t=JSON.parse(localStorage.getItem('agora_uni_tema')||'"auto"');var d=t==='dark'||(t==='auto'&&matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.setAttribute('data-theme',d?'dark':'light')}}catch(e){{}}if(/Mac|iPhone|iPad|iPod/.test(navigator.platform||navigator.userAgent))document.documentElement.classList.add('is-apple')}})();
</script>
<style>
/* ---------- sistema.css · el sistema de diseño del panel de Contratos ---------- */
{piezas['sistema.css']}
/* ---------- modulos.css · los módulos de Ágora en ese mismo sistema ---------- */
{piezas['modulos.css']}
</style>
</head>
<body>
<a class="skip" href="#app">Saltar al contenido</a>

<header class="tb" id="tb"></header>
<main id="app" class="ct" tabindex="-1"></main>
<footer class="ft"><span><b>Agora Digital App</b><span id="app-version" hidden>AGORA · v1.0.0</span></span><span id="foot"></span></footer>
<nav class="tabbar" id="tabbar" aria-label="Módulos"></nav>

<div id="tip" role="tooltip"></div>
<div id="toast" role="status" aria-live="polite"></div>
<div id="layer"></div>

<div id="won-banner" class="won-banner" role="alert" hidden></div>
<dialog id="action-dialog"><form method="dialog"><button class="dialog-close" aria-label="Cerrar">×</button></form><div id="dialog-content"></div></dialog>
{AVISO}
<script>{CONFIG}</script>
<script>
/* ---------- demo.js · datos de prueba ---------- */
{piezas['demo.js']}
</script>
<script>
/* ---------- agora-modulos.js · los módulos de Ágora, tal como vienen ---------- */
{piezas['agora-modulos.js']}
</script>
<script>
/* ---------- agora-app.js · el armazón y los módulos ---------- */
{piezas['agora-app.js']}
</script>
</body>
</html>
"""

OUT.write_text(html, encoding='utf-8')
print(f'prueba.html escrito: {len(html.encode()) / 1024:.0f} KB')
