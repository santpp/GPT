/* Recorre los diez módulos del archivo de pruebas en un navegador de verdad:
   apunta los errores de consola y guarda una captura de cada uno. */
const {chromium} = require('playwright');
const path = require('path');
const fs = require('fs');

const ARCHIVO = 'file://' + path.resolve(__dirname, '../prueba.html');
const SALIDA = path.resolve(__dirname, 'capturas');
const RUTAS = [
  ['inicio', '#/inicio'],
  ['comercial', '#/comercial'],
  ['bandeja', '#/bandeja'],
  ['contactos', '#/contactos'],
  ['oportunidades', '#/oportunidades'],
  ['tareas', '#/tareas'],
  ['contratos', '#/contratos'],
  ['con-convenio', '#/con-convenio'],
  ['registro', '#/registro'],
  ['auditoria', '#/auditoria'],
  ['usuarios', '#/usuarios'],
  ['ajustes', '#/ajustes'],
  ['ayuda', '#/ayuda'],
];

(async () => {
  fs.mkdirSync(SALIDA, {recursive: true});
  const browser = await chromium.launch();
  const page = await browser.newPage({viewport: {width: 1440, height: 980}, deviceScaleFactor: 1});
  const problemas = [];
  page.on('console', m => { if (m.type() === 'error') problemas.push(`[consola] ${m.text()}`); });
  page.on('pageerror', e => problemas.push(`[página] ${e.message}`));

  await page.goto(ARCHIVO, {waitUntil: 'load'});
  await page.waitForTimeout(1400);

  for (const [nombre, hash] of RUTAS) {
    await page.evaluate(h => { location.hash = h; }, hash);
    await page.waitForTimeout(1700);
    const vacio = await page.evaluate(() => {
      const app = document.querySelector('#app');
      return {
        texto: (app?.innerText || '').trim().length,
        titulo: document.title,
        modulo: document.querySelector('#b-crumb span:not([class])')?.textContent.trim() || '',
        periodo: document.querySelector('.per-b.is-on')?.textContent.trim() || '—',
      };
    });
    await page.screenshot({path: path.join(SALIDA, nombre + '.png'), fullPage: false});
    console.log(`${nombre.padEnd(14)} texto:${String(vacio.texto).padStart(5)}  módulo: ${vacio.modulo.padEnd(28)} periodo: ${vacio.periodo}`);
  }

  /* Un par de cosas más del armazón: la paleta y el menú de la cuenta. */
  await page.evaluate(() => { location.hash = '#/contratos'; });
  await page.waitForTimeout(900);
  await page.keyboard.press('Control+k');
  await page.waitForTimeout(600);
  await page.screenshot({path: path.join(SALIDA, 'paleta.png')});
  await page.keyboard.press('Escape');
  await page.click('#b-acct');
  await page.waitForTimeout(500);
  await page.screenshot({path: path.join(SALIDA, 'cuenta.png')});
  await page.keyboard.press('Escape');

  /* El menú de módulos y Athena. */
  await page.click('#b-crumb');
  await page.waitForTimeout(600);
  await page.screenshot({path: path.join(SALIDA, 'menu-modulos.png')});
  await page.keyboard.press('Escape');
  await page.click('#b-ath');
  await page.waitForTimeout(500);
  await page.click('[data-ath-sug]');
  await page.waitForTimeout(900);
  await page.screenshot({path: path.join(SALIDA, 'athena.png')});
  await page.keyboard.press('Escape');
  await page.click('[data-ath-close]').catch(() => {});

  /* Tema oscuro, en el Resumen. */
  await page.evaluate(() => { location.hash = '#/inicio'; });
  await page.waitForTimeout(1500);
  await page.click('#b-theme');
  await page.waitForTimeout(700);
  await page.screenshot({path: path.join(SALIDA, 'resumen-oscuro.png')});
  await page.click('#b-theme');

  /* El celular: pestañas abajo y una conversación abierta. */
  const movil = await browser.newPage({viewport: {width: 414, height: 900}});
  await movil.goto(ARCHIVO, {waitUntil: 'load'});
  await movil.waitForTimeout(1500);
  await movil.evaluate(() => { location.hash = '#/inicio'; });
  await movil.waitForTimeout(1800);
  await movil.screenshot({path: path.join(SALIDA, 'movil-inicio.png')});

  console.log('\n' + (problemas.length ? `PROBLEMAS (${problemas.length}):\n` + [...new Set(problemas)].join('\n') : 'Sin errores de consola.'));
  await browser.close();
})();
