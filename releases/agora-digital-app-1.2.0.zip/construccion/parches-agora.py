#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Los dos cambios que se le piden a los módulos de Ágora.

1. El tablero (dashboard.js) enseña además la operación del día, la inversión en
   anuncios y la eficacia de ventas. El dibujo vive aparte, en arp-extra.js.
2. La bandeja (live-inbox.js) deja poner un recordatorio de seguimiento en un chat:
   se elige el día y la hora, queda tarea, y la conversación se va de primera en la
   lista hasta que se escribe.

Se aplica sobre la copia de construccion/agora/, nunca sobre el paquete original.
El script falla si el texto de partida no es el esperado, así nunca deja un archivo
a medio parchear.
"""
import pathlib
import sys

BASE = pathlib.Path('/home/claude/uni/build/agora')


def parchear(archivo, cambios, marca):
    f = BASE / archivo
    s = f.read_text(encoding='utf-8')
    if marca in s:
        print(f'{archivo}: ya estaba parcheado')
        return
    for viejo, nuevo in cambios:
        if s.count(viejo) != 1:
            sys.exit(f'{archivo}: el texto a sustituir aparece {s.count(viejo)} veces, debía aparecer una:\n  {viejo[:110]}')
        s = s.replace(viejo, nuevo, 1)
    f.write_text(s, encoding='utf-8')
    print(f'{archivo}: {len(cambios)} cambios')


# =======================================================================================
#  1 · El tablero comercial
# =======================================================================================
parchear('dashboard.js', [
    ("import {wonAlertState} from './won-alert.js';",
     "import {wonAlertState} from './won-alert.js';\nimport {slotsDia,slotEficacia,pintarExtras} from './arp-extra.js';"),

    ('<section id="won-team" hidden></section>',
     '<section id="won-team" hidden></section>\n      ${slotsDia()}'),

    ('<div id="board-month">${monthBlock(month)}</div>`;',
     '<div id="board-month">${monthBlock(month)}</div>\n      ${slotEficacia()}`;'),

    ("      if(!active())return;\n      paint(now,month);",
     "      if(!active())return;\n      paint(now,month);\n      // La operación del día, los anuncios y la eficacia de ventas se piden aparte,\n      // para que una cuenta publicitaria lenta no retrase el resto del tablero.\n      pintarExtras(container,{connection,period,request,active});"),
], marca='arp-extra.js')


# =======================================================================================
#  2 · Recordatorios de seguimiento en la bandeja
# =======================================================================================
RECORDATORIOS_JS = r"""
  /* ---- Recordatorios de seguimiento --------------------------------------------------
     Se elige el día y la hora en que hay que volver a escribirle al contacto. Queda una
     tarea a nombre de quien lo puso y la conversación se va de primera en la lista, con
     su aviso, hasta que se manda un mensaje. ------------------------------------------ */
  const recordatorios=new Map();
  const recordatorioDe=id=>recordatorios.get(id)||null;
  function cuandoTexto(iso){
   const d=new Date(iso);if(Number.isNaN(d.getTime()))return '';
   const hoy=new Date();hoy.setHours(0,0,0,0);
   const dia=new Date(d);dia.setHours(0,0,0,0);
   const faltan=Math.round((dia-hoy)/86400000);
   const hora=new Intl.DateTimeFormat('es-VE',{hour:'2-digit',minute:'2-digit'}).format(d);
   if(faltan===0)return `hoy ${hora}`;
   if(faltan===1)return `mañana ${hora}`;
   if(faltan===-1)return `ayer ${hora}`;
   if(faltan<0)return `vencido · ${new Intl.DateTimeFormat('es-VE',{day:'numeric',month:'short'}).format(d)}`;
   return `${new Intl.DateTimeFormat('es-VE',{day:'numeric',month:'short'}).format(d)} ${hora}`;
  }
  function recordatorioDialog(c){
   const dialog=document.querySelector('#action-dialog'),content=document.querySelector('#dialog-content');
   const previo=recordatorioDe(c.id);
   const base=previo?new Date(previo.at):new Date(Date.now()+864e5);
   const ymd=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
   const hm=d=>`${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
   const atajo=(etiqueta,dias,hora)=>`<button type="button" class="secondary" data-rec-atajo="${dias}|${hora}">${etiqueta}</button>`;
   content.innerHTML=`<h2>Recordatorio de seguimiento</h2>
    <p class="dialog-copy">Elige cuándo le vuelves a escribir a <b>${esc(name(c))}</b>. Ese día te queda la tarea y esta conversación se pone de primera en la bandeja hasta que mandes el mensaje.</p>
    <form id="rec-form" class="dialog-form">
     <div class="rec-atajos">${atajo('Esta tarde',0,'16:00')}${atajo('Mañana',1,'09:00')}${atajo('En 3 días',3,'09:00')}${atajo('La semana que viene',7,'09:00')}</div>
     <div class="announce-grid">
      <label>Día<input type="date" name="dia" required value="${esc(ymd(base))}" min="${esc(ymd(new Date()))}"></label>
      <label>Hora<input type="time" name="hora" required value="${esc(hm(base))}"></label>
     </div>
     <label>Nota para ti (opcional)<input name="nota" maxlength="140" value="${esc(previo?.nota||'')}" placeholder="Quedó en confirmar con su esposo"></label>
     <div class="dialog-actions"><button class="primary">${previo?'Guardar el recordatorio':'Poner el recordatorio'}</button>${previo?'<button type="button" class="danger" id="rec-quitar">Quitar</button>':''}</div>
     <p id="rec-result" class="dialog-copy" role="status"></p>
    </form>`;
   if(!dialog.open)dialog.showModal();
   const form=content.querySelector('#rec-form');
   content.querySelectorAll('[data-rec-atajo]').forEach(b=>b.onclick=()=>{
    const [dias,hora]=b.dataset.recAtajo.split('|');
    const d=new Date();d.setDate(d.getDate()+Number(dias));
    form.elements.dia.value=ymd(d);form.elements.hora.value=hora;
   });
   const quitar=content.querySelector('#rec-quitar');
   if(quitar)quitar.onclick=async()=>{
    quitar.disabled=true;
    try{
     await request(`workspace/reminders?connectionId=${encodeURIComponent(select.value)}&conversationId=${encodeURIComponent(c.id)}`,'DELETE',me?.csrf||'');
     recordatorios.delete(c.id);dialog.close();list();pintarRecordatorio(c);
     window.dispatchEvent(new CustomEvent('agora:toast',{detail:'Recordatorio quitado.'}));
    }catch(error){quitar.disabled=false;content.querySelector('#rec-result').textContent=friendly(error)}
   };
   form.onsubmit=async event=>{
    event.preventDefault();
    const boton=form.querySelector('button.primary'),salida=content.querySelector('#rec-result');
    const at=`${form.elements.dia.value}T${form.elements.hora.value}`;
    if(new Date(at).getTime()<Date.now()-60000){salida.textContent='Elige un momento que todavía no haya pasado.';return}
    boton.disabled=true;salida.textContent='Guardando…';
    try{
     const guardado=await request(`workspace/reminders?connectionId=${encodeURIComponent(select.value)}&conversationId=${encodeURIComponent(c.id)}`,'POST',me?.csrf||'',
      {at,nota:form.elements.nota.value.trim(),contactId:c.contactId||null,contactName:name(c)});
     recordatorios.set(c.id,{at:guardado?.at||at,nota:form.elements.nota.value.trim()});
     dialog.close();list();pintarRecordatorio(c);
     window.dispatchEvent(new CustomEvent('agora:reminder',{detail:{conversationId:c.id,cuando:cuandoTexto(at),contacto:name(c)}}));
    }catch(error){boton.disabled=false;salida.textContent=friendly(error)}
   };
  }
  /** El aviso dentro del chat abierto. */
  function pintarRecordatorio(c){
   const barra=$('#live-rec');if(!barra)return;
   const r=recordatorioDe(c.id);
   const boton=$('#live-recordar');
   if(boton)boton.classList.toggle('on',!!r);
   if(!r){barra.hidden=true;barra.innerHTML='';return}
   barra.hidden=false;
   barra.innerHTML=`<span class="rec-pin" aria-hidden="true"></span><span>Recordatorio para <b>${esc(cuandoTexto(r.at))}</b>${r.nota?` · ${esc(r.nota)}`:''}</span><button type="button" id="rec-editar" class="link-button">Cambiar</button>`;
   barra.querySelector('#rec-editar').onclick=()=>recordatorioDialog(c);
  }
"""

parchear('live-inbox.js', [
    # El estado de los recordatorios y su ventana, dentro del cierre de la bandeja.
    ("  // ---- Asignar la conversación: responsable del contacto y de sus oportunidades abiertas ----",
     RECORDATORIOS_JS + "\n  // ---- Asignar la conversación: responsable del contacto y de sus oportunidades abiertas ----"),

    # El botón en el encabezado del chat y la barra del aviso.
    ("""<button id="live-assign" class="assign-button" hidden title="Asignar la conversación\"""",
     """<button id="live-recordar" class="rec-button" title="Recordatorio de seguimiento" aria-label="Recordatorio de seguimiento"><span aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="ui-icon"><circle cx="12" cy="13" r="8"/><path d="M12 9.5V13l2.5 1.5M9 2.5h6"/></svg></span><span class="rec-text">Recordar</span></button><button id="live-assign" class="assign-button" hidden title="Asignar la conversación\""""),

    ("""<div class="live-history-actions">""",
     """<div id="live-rec" class="live-rec" role="status" hidden></div><div class="live-history-actions">"""),

    # Al abrir la conversación se engancha el botón y se pinta el aviso.
    ("   const won=$('#live-won');if(won)won.onclick=()=>winDialog(c);",
     "   const recordar=$('#live-recordar');if(recordar)recordar.onclick=()=>recordatorioDialog(c);\n   pintarRecordatorio(c);\n   const won=$('#live-won');if(won)won.onclick=()=>winDialog(c);"),

    # La lista: primero las que tienen recordatorio, con su aviso.
    ("   const visible=filter==='waiting'?conversations.filter(c=>c.lastMessageDirection!=='outbound').sort((a,b)=>stamp(a)-stamp(b)):conversations;",
     "   const conRec=c=>recordatorios.has(c.id)?0:1;\n   // Lo que tiene recordatorio va de primero, sea cual sea el filtro: para eso se puso.\n   const base=filter==='waiting'?conversations.filter(c=>c.lastMessageDirection!=='outbound').sort((a,b)=>stamp(a)-stamp(b)):conversations;\n   const visible=[...base].sort((a,b)=>conRec(a)-conRec(b));"),

    ("""<footer><span class="channel">${channel(c.lastMessageType)}</span>""",
     """<footer><span class="channel">${channel(c.lastMessageType)}</span>${recordatorioDe(c.id)?`<span class="rec-chip" title="Recordatorio de seguimiento">${esc(cuandoTexto(recordatorioDe(c.id).at))}</span>`:''}"""),

    ("""<button class="conversation-item live-conversation ${selected?.id===c.id?'selected':''}\"""",
     """<button class="conversation-item live-conversation ${selected?.id===c.id?'selected':''}${recordatorios.has(c.id)?' con-rec':''}\""""),

    # La bandeja trae los recordatorios vigentes junto con las conversaciones.
    ("    conversations=data.items;limit.value=String(data.limit||20);",
     "    conversations=data.items;limit.value=String(data.limit||20);\n    if(data.reminders&&typeof data.reminders==='object'){recordatorios.clear();for(const [id,r] of Object.entries(data.reminders))recordatorios.set(id,r)}"),

    # Al mandar un mensaje, el recordatorio se cumple y la conversación vuelve a su sitio.
    ("     window.dispatchEvent(new CustomEvent('agora:toast',{detail:`Venta ganada:",
     "     if(recordatorios.has(c.id)){recordatorios.delete(c.id);pintarRecordatorio(c);list()}\n     window.dispatchEvent(new CustomEvent('agora:toast',{detail:`Venta ganada:"),
], marca='recordatorioDialog')

# =======================================================================================
#  3 · Los leads del mes y la tasa de conversión, en el desempeño del equipo
# =======================================================================================
parchear('dashboard.js', [
    # Dos ayudas: los leads que trae cada fila y la conversión que sale de ellos.
    ("  const kindOf=progress=>progress===null||progress===undefined?'':progress>=data.settings.green?'ok':progress>=data.settings.amber?'warn':'bad';",
     "  const kindOf=progress=>progress===null||progress===undefined?'':progress>=data.settings.green?'ok':progress>=data.settings.amber?'warn':'bad';\n"
     "  // Los leads del mes por ejecutivo, tal como la cuenta los asignó, y la tasa de\n"
     "  // conversión que sale sola de ellos: cierres entre leads asignados. Si la cuenta\n"
     "  // todavía no informa los leads, las dos columnas quedan con una raya.\n"
     "  const leadsDe=row=>row.leads===null||row.leads===undefined?null:Number(row.leads);\n"
     "  const tasa=(cierres,leads)=>leads?Math.round(((Number(cierres)||0)/leads)*1000)/10:null;\n"
     "  const tasaCell=v=>v===null?'<span class=\"muted\">—</span>':`${number(v)} %`;\n"
     "  const leadsEquipo=rows.reduce((suma,row)=>leadsDe(row)===null?suma:suma+leadsDe(row),0);"),

    # Las dos celdas nuevas en cada fila.
    ('return `<tr><th scope="row">${esc(row.name)}</th><td class="n" data-label="${esc(heading)}">${number(row.closings)}</td>',
     'return `<tr><th scope="row">${esc(row.name)}</th><td class="n" data-label="Leads">${leadsDe(row)===null?\'<span class="muted">—</span>\':number(leadsDe(row))}</td><td class="n" data-label="${esc(heading)}">${number(row.closings)}</td><td class="n" data-label="Conversión">${tasaCell(tasa(row.closings,leadsDe(row)))}</td>'),

    # Y en el total del equipo, con la conversión de todos juntos.
    ('?`<tfoot><tr><td>Total del equipo</td><td class="n">${number(sales.closings??0)}</td>',
     '?`<tfoot><tr><td>Total del equipo</td><td class="n">${leadsEquipo?number(leadsEquipo):\'—\'}</td><td class="n">${number(sales.closings??0)}</td><td class="n"><b>${tasaCell(tasa(sales.closings,leadsEquipo))}</b></td>'),

    # Los encabezados, en el mismo orden.
    ('<th scope="col">Asesora</th><th scope="col" class="n">${esc(heading)}</th>',
     '<th scope="col">Asesora</th><th scope="col" class="n" title="Leads que se le asignaron en el mes">Leads</th><th scope="col" class="n">${esc(heading)}</th><th scope="col" class="n" title="Cierres entre leads asignados">Conversión</th>'),

    # Y se dice de dónde salen, como con el resto de las cifras.
    ("    ${row('Publicidad: ',",
     "    ${row('Leads: ','los que la cuenta le asignó a cada quien dentro del mes. Un lead cuenta en el mes en que se asignó, no en el que entró.')}\n"
     "    ${row('Conversión: ','los '+word+' de cada quien entre sus leads asignados del mes, por cien. El total del equipo usa la suma de los dos, no el promedio de los porcentajes.')}\n"
     "    ${row('Publicidad: ',"),
], marca='const tasa=(cierres,leads)')

# =======================================================================================
#  4 · El total del equipo también se lee como tarjeta en el celular
# =======================================================================================
parchear('dashboard.js', [
    ('<td class="n">${leadsEquipo?number(leadsEquipo):\'—\'}</td><td class="n">${number(sales.closings??0)}</td><td class="n"><b>${tasaCell(tasa(sales.closings,leadsEquipo))}</b></td><td class="n">${cell(goal.target)}</td><td class="n">${cell(sales.total)}</td><td class="n">${diff(Number(sales.total)-Number(goal.target))}</td><td>${goal.progress===null||goal.progress===undefined?\'—\':`<b>${number(Math.round(goal.progress))} %</b>`}</td><td></td>',
     '<td class="n" data-label="Leads">${leadsEquipo?number(leadsEquipo):\'—\'}</td><td class="n" data-label="${esc(heading)}">${number(sales.closings??0)}</td><td class="n" data-label="Conversión"><b>${tasaCell(tasa(sales.closings,leadsEquipo))}</b></td><td class="n" data-label="Meta">${cell(goal.target)}</td><td class="n" data-label="Vendido">${cell(sales.total)}</td><td class="n" data-label="Diferencia">${diff(Number(sales.total)-Number(goal.target))}</td><td data-label="Avance">${goal.progress===null||goal.progress===undefined?\'—\':`<b>${number(Math.round(goal.progress))} %</b>`}</td><td></td>'),
], marca='data-label="Conversión"><b>')

print('listo')
