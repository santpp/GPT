# Arnés: las pantallas contra el servidor real de Ágora

Prueba que las pantallas de este paquete hablan bien con las rutas de Ágora 1.11.0 (no con datos inventados).

```
export AGORA_ROOT=/ruta/a/Agora          # el repositorio de Ágora, con su base de pruebas ya levantada (DB_DSN, etc.)
php construccion/arnes/sembrar.php       # crea un espacio, una cuenta propietaria y tres conversaciones de prueba
export PKG_ROOT=$PWD/public_html APP_ORIGIN=http://127.0.0.1:8082
php -S 127.0.0.1:8082 -t "$PKG_ROOT" construccion/arnes/harness.php
# entra con owner@harness.test / clave-de-prueba-123
php construccion/arnes/sembrar.php clean # lo borra todo
```

Sin una cuenta de verdad detrás, las pantallas que leen la cuenta de origen (tablero, bandeja en vivo) avisan de que no pueden leerla; las
nuevas (Resumen, Tareas, Auditoría, Usuarios, recordatorios, identidad) funcionan completas.
