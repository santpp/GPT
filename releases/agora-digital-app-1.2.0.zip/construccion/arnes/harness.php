<?php
// Arnés de prueba: las pantallas del paquete 1.1.1 sobre la API real de Ágora.
$root=getenv('PKG_ROOT');
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if(str_starts_with($path,'/api/')){require getenv('AGORA_ROOT').'/public/router.php';return true;}
$file=realpath($root.$path);
if($file&&is_file($file)&&str_starts_with($file,$root.'/'))return false;
if(preg_match('~\.(css|js|png|svg|ico|json|webmanifest|woff2?|pdf)$~',$path)){http_response_code(404);exit;}
header('Content-Type: text/html; charset=utf-8');readfile($root.'/index.html');
