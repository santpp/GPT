/* =====================================================================================
   Punto de entrada del paquete de módulos de Ágora para el sistema unificado.
   Los módulos de Ágora no se tocan: se empaquetan tal cual y se publican en
   window.Agora para que la cáscara del panel los monte donde haga falta.
   La única diferencia con el paquete original es la base de la API, que ahora
   se lee de window.AGORA_API (ver assets/config.js).
   ===================================================================================== */
import {workspace, friendly} from './agora/workspace.js';
import {skeleton} from './agora/skeleton.js';
import {number, money, symbol, currencyCode} from './agora/format.js';
import {renderDashboard, periodOf} from './agora/dashboard.js';
import {renderLiveInbox} from './agora/live-inbox.js';
import {renderContacts} from './agora/contacts.js';
import {renderBoard} from './agora/board.js';
import {renderWon} from './agora/won.js';
import {renderIntegrations} from './agora/integrations.js';
import {renderHelp, MANUAL_PDF} from './agora/help.js';
import {startWonAlert, wonAlertState} from './agora/won-alert.js';
import {windowMarkup} from './agora/announce.js';
import {installMaintenance, maintenanceShown} from './agora/maintenance.js';

window.Agora = {
  workspace, friendly, skeleton,
  number, money, symbol, currencyCode,
  renderDashboard, periodOf,
  renderLiveInbox, renderContacts, renderBoard, renderWon,
  renderIntegrations, renderHelp, MANUAL_PDF,
  startWonAlert, wonAlertState, windowMarkup,
  installMaintenance, maintenanceShown,
};
