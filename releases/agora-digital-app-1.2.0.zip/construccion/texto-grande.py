#!/usr/bin/env python3
"""Genera public_html/assets/identidad-texto.css: todas las letras en px de sistema.css y modulos.css
multiplicadas por FACTOR (con un suelo), con !important para ganar sobre los atajos `font:`.
Uso: python3 construccion/texto-grande.py   (se vuelve a correr si cambian esos dos archivos)"""
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent/'public_html/assets'
FACTOR=1.15
FLOOR=12.5
# La barra de arriba ya va justa de espacio: se queda con sus tamaños.
SKIP=re.compile(r'^(?:\.tb|\.per|\.crumb|\.tabbar|\.mdm-gt)')
SIZE=re.compile(r'(?<![\w.#-])(\d+(?:\.\d+)?)px')
def split_rules(css):
    out=[];i=0;n=len(css)
    while i<n:
        j=css.find('{',i)
        if j<0:break
        prelude=css[i:j].strip();depth=1;k=j+1
        while k<n and depth:
            depth+= (css[k]=='{')-(css[k]=='}');k+=1
        out.append((prelude,css[j+1:k-1]));i=k
    return out
def size_of(prop,value):
    prop=prop.strip().lower();value=value.strip()
    if prop=='font-size':
        m=re.fullmatch(r'(\d+(?:\.\d+)?)px',value)
        return float(m.group(1)) if m else None
    if prop=='font':
        m=re.search(r'(?:^|\s)(\d+(?:\.\d+)?)px(?=\s|/|$)',value)
        return float(m.group(1)) if m else None
    return None
def rules(css):
    css=re.sub(r'/\*.*?\*/','',css,flags=re.S);out=[]
    for prelude,body in split_rules(css):
        if prelude.startswith('@media') or prelude.startswith('@supports'):
            inner=rules(body)
            if inner:out.append(prelude+'{'+''.join(inner)+'}')
            continue
        if prelude.startswith('@'):continue
        if all(SKIP.match(x.strip()) for x in prelude.split(',')):continue
        for decl in body.split(';'):
            if ':' not in decl:continue
            prop,value=decl.split(':',1);px=size_of(prop,value)
            if px:
                out.append(prelude+'{font-size:%spx!important}'%(('%.2f'%max(px*FACTOR,FLOOR)).rstrip('0').rstrip('.')))
                break
    return out
def main():
    parts=['/* Generado por construccion/texto-grande.py: no editar a mano. */\n']
    for name in ('sistema.css','modulos.css'):
        parts.extend(r+'\n' for r in rules((ROOT/name).read_text()))
    (ROOT/'identidad-texto.css').write_text(''.join(parts));print('identidad-texto.css',sum(map(len,parts)),'bytes')
main()
