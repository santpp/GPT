/* =====================================================================================
   Módulos propios de Agora Digital App
   -------------------------------------------------------------------------------------
   Resumen (el pulso del negocio), Tareas, Auditoría y Usuarios y roles. Escritos con las
   piezas del sistema de diseño: .hero, .micro, .panel, .bars, .tw, .seg, .lt, svg.chart.

   Cada uno lee su propia ruta del servidor. Las formas de respuesta están documentadas
   en construccion/API.md; mientras el servidor no las tenga, el archivo de pruebas las
   responde con datos inventados.
   ===================================================================================== */

var DATOS = {resumen: null, dia: null, ads: null, eficacia: null, tareas: null, auditoria: null, usuarios: null};

/* ---------- Dinero del negocio: «US$ 285», «−US$ 783» ---------- */
const usd = v => {
  if (v === null || v === undefined || v === '' || !isFinite(Number(v))) return '—';
  const n = Number(v), abs = Math.abs(n);
  const cifra = Math.abs(abs % 1) > 0.004 ? NF.format(abs) : NI.format(Math.round(abs));
  return (n < 0 ? '−' : '') + 'US$ ' + cifra;
};
const firmado = v => (Number(v) > 0 ? '+' : '') + usd(v);

/* ---------- Paleta de los gráficos de reparto ---------- */
const PAL = ['var(--brand)', 'var(--gold)', 'var(--teal)', 'var(--violet)', 'var(--info)', 'var(--deep)', 'var(--muted-2)'];

/**
 * Rueda de reparto con su leyenda al lado. `items`: [{l, n}].
 * Se usa para las conversaciones sin leer por asesor, la fuente de los leads
 * y los leads asignados por usuario.
 */
function donut(items, {centro = '', rotulo = ''} = {}) {
  const lista = (items || []).filter(x => Number(x.n) > 0);
  const suma = lista.reduce((a, b) => a + Number(b.n), 0);
  if (!suma) return `<p class="empty"><b>Sin datos todavía</b>${esc(rotulo || 'No hay nada que repartir en este periodo.')}</p>`;
  const R = 52, C = 2 * Math.PI * R;
  let corrido = 0;
  const arcos = lista.map((it, i) => {
    const largo = (Number(it.n) / suma) * C;
    const arco = `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${PAL[i % PAL.length]}" stroke-width="17" stroke-dasharray="${largo.toFixed(2)} ${(C - largo).toFixed(2)}" stroke-dashoffset="${(-corrido).toFixed(2)}" transform="rotate(-90 70 70)"><title>${esc(it.l)}: ${int(it.n)}</title></circle>`;
    corrido += largo;
    return arco;
  }).join('');
  return `<div class="dn">
    <svg class="dn-svg" viewBox="0 0 140 140" role="img" aria-label="${esc(rotulo || 'Reparto')}: ${lista.map(x => `${x.l}, ${x.n}`).join('; ')}">
      <circle cx="70" cy="70" r="${R}" fill="none" stroke="var(--fill-3)" stroke-width="17"></circle>${arcos}
      <text x="70" y="70" class="dn-c" text-anchor="middle" dominant-baseline="central">${esc(centro || int(suma))}</text>
    </svg>
    <ul class="dn-lg">${lista.map((it, i) => `<li><i style="background:${PAL[i % PAL.length]}" aria-hidden="true"></i><span>${esc(it.l)}</span><b>${int(it.n)}</b></li>`).join('')}</ul>
  </div>`;
}

/** Línea con área, para la evolución del ingreso recurrente. `serie`: [{ym, v}]. */
function lineaArea(serie, {formato = usd} = {}) {
  const pts = (serie || []).filter(p => p && isFinite(Number(p.v)));
  if (pts.length < 2) return `<p class="empty"><b>Hace falta más historia</b>Con un solo mes todavía no hay línea que dibujar.</p>`;
  const W = 620, H = 260, L = 64, Rm = 14, T = 18, B = 34;
  const w = W - L - Rm, h = H - T - B;
  const vals = pts.map(p => Number(p.v));
  const tope = Math.max(...vals), piso = Math.min(0, ...vals);
  const esc10 = v => { const p = 10 ** Math.floor(Math.log10(v || 1)); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; };
  const alto = esc10(tope || 1);
  const x = i => L + (pts.length === 1 ? w / 2 : (i * w) / (pts.length - 1));
  const y = v => T + h - ((v - piso) / ((alto - piso) || 1)) * h;
  let rejilla = '';
  for (let k = 0; k <= 3; k++) {
    const v = piso + ((alto - piso) * k) / 3;
    rejilla += `<line class="gl" x1="${L}" x2="${W - Rm}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke-dasharray="3 5"/><text x="${L - 10}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end">${esc(formato(v))}</text>`;
  }
  const linea = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(Number(p.v)).toFixed(1)}`).join(' ');
  const area = `${linea} L${x(pts.length - 1).toFixed(1)} ${y(piso).toFixed(1)} L${x(0).toFixed(1)} ${y(piso).toFixed(1)} Z`;
  const puntos = pts.map((p, i) => `<circle class="ln-p" cx="${x(i).toFixed(1)}" cy="${y(Number(p.v)).toFixed(1)}" r="5"><title>${esc(mesNombre(p.ym))}: ${esc(formato(Number(p.v)))}</title></circle>`).join('');
  const rotulos = pts.map((p, i) => `<text x="${x(i).toFixed(1)}" y="${H - 10}" text-anchor="middle">${esc(mesCorto(p.ym))}</text>`).join('');
  return `<svg class="chart ln" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución del ingreso recurrente: ${pts.map(p => `${mesCorto(p.ym)}, ${formato(Number(p.v))}`).join('; ')}">
    ${rejilla}<path class="ln-a" d="${area}"/><path class="ln-l" d="${linea}"/>${puntos}${rotulos}</svg>`;
}

/** Barras horizontales con la primitiva del sistema. `items`: [{l, v, texto}]. */
function barras(items) {
  const lista = items || [];
  if (!lista.length) return `<p class="empty"><b>Sin movimiento</b>No hay nada que mostrar en este periodo.</p>`;
  const tope = Math.max(1, ...lista.map(i => Number(i.v) || 0));
  return `<div class="bars">${lista.map(i => `<div class="bar-row"><span class="lab" title="${esc(i.l)}">${esc(i.l)}</span><span class="track"><span class="fill" style="width:${Math.min(100, (100 * (Number(i.v) || 0)) / tope).toFixed(1)}%"></span></span><span class="val">${esc(i.texto)}</span></div>`).join('')}</div>`;
}

/* =====================================================================================
   Resumen · el pulso del negocio
   ===================================================================================== */
const cargarResumen = async (forzar) => {
  if (!forzar && DATOS.resumen && DATOS.resumen.period === PERIODO) return DATOS.resumen;
  const d = await agoraApi(`workspace/resumen?period=${encodeURIComponent(PERIODO)}`);
  DATOS.resumen = {...d, period: PERIODO};
  return DATOS.resumen;
};

V.inicio = {
  need: () => cargarResumen(),
  render() {
    const estado = mesEstado(PERIODO);
    const sello = estado === 'curso' ? '<span class="sc sc-ok">en curso</span>' : estado === 'proximo' ? '<span class="sc sc-info">por delante</span>' : '<span class="sc sc-gray">cerrado</span>';
    const eyebrow = `<span class="mes-sello">${icon('home')}${esc(mesNombre(PERIODO))} · ${sello}</span>`;
    const acts = `<button class="btn btn-tint" type="button" data-informe>${icon('download')}Descargar informe</button>`;
    const cabeza = `<div class="mod-h"><div><p class="t-label">${eyebrow}</p><h1 class="t-module">Resumen</h1><p class="lede">El pulso del negocio: ingreso recurrente, resultado, salud financiera y lo que viene.</p></div><div class="acts">${acts}</div></div>`;
    if (this.error) return cabeza + failed(this.error);
    const d = DATOS.resumen;
    if (!d || d.period !== PERIODO) return cabeza + loading();

    const delta = Number(d.mrr) - Number(d.mrrAnterior || 0);
    const prom = d.clientesActivos ? Number(d.mrr) / Number(d.clientesActivos) : 0;
    const tiles = [
      ['Recaudado en el mes', usd(d.recaudado), 'Pagos recibidos, con IVA'],
      ['Recurrente anual (ARR)', usd(d.arr), 'Ingreso fijo al cierre × 12'],
      [`Saldo de caja ${icon('lock', 'tile-ic')}`, usd(d.caja), 'Automático: cobros − egresos', Number(d.caja) < 0 ? 'bad' : ''],
      ['Clientes activos', int(d.clientesActivos), d.enPausa ? `${int(d.enPausa)} en pausa` : 'Ninguno en pausa'],
      ['Clientes en baja (churn)', int(d.churn), `${esc(pct(d.churnPct))} de la cartera del inicio`],
      ['Egresos del mes', usd(d.egresos), `Incluye ${usd(d.inversion || 0)} de inversión`],
    ];

    const hero = `<section class="hero hero-resumen">
      <div class="hero-split">
        <div class="hero-cifra">
          <p class="t-label">Ingreso recurrente mensual (MRR) al cierre de ${esc(mesNombre(PERIODO).toLowerCase())}</p>
          <p class="t-hero">${esc(usd(d.mrr))}</p>
          <p class="f"><b class="${delta >= 0 ? 'up' : 'down'}">${esc(firmado(delta))}</b> frente al mes anterior. ${int(d.clientesActivos)} cliente${d.clientesActivos === 1 ? '' : 's'} activo${d.clientesActivos === 1 ? '' : 's'}, con un ingreso promedio de ${esc(usd(prom))} por cliente.</p>
        </div>
        <div class="hero-graf">${lineaArea(d.serie)}</div>
      </div>
      <div class="hero-tiles">${tiles.map(([l, v, f, cls]) => `<div class="htile ${cls || ''}"><h3>${l}</h3><p class="v">${esc(v)}</p><span class="f">${f}</span></div>`).join('')}</div>
    </section>`;

    const espacios = (d.espacios || []).length
      ? panel('Espacios atendidos', 'Cada empresa con su identidad, su plan y lo que aporta al mes.',
        `<div class="esp-grid">${d.espacios.map(e => `<article class="esp-card">
            <span class="esp-mark">${e.logo ? `<img src="${esc(e.logo)}" alt="">` : esc(initials(e.nombre))}</span>
            <div class="tx"><b>${esc(e.nombre)}</b><small>${esc(e.plan || 'Sin plan')} · ${esc(usd(e.mrr))} al mes</small></div>
            <span class="lt ${e.estado === 'activo' ? 'lt-ok' : e.estado === 'pausa' ? 'lt-warn' : 'lt-bad'}"><i aria-hidden="true"></i>${esc(e.estado === 'activo' ? 'Activo' : e.estado === 'pausa' ? 'En pausa' : 'De baja')}</span>
          </article>`).join('')}</div>`,
        esSuperAdmin() ? `<a class="btn btn-sm" href="${href('/usuarios')}">${icon('palette')}Identidad y logos</a>` : '')
      : '';

    const responsables = panel('Responsables del espacio', 'Quiénes tienen el control total del sistema.',
      `<ul class="mini-list">${(d.superadmins || []).map(u => `<li><span class="who-cell"><b>${esc(u.nombre)}</b><small>${esc(u.correo)}</small></span><span class="sc sc-info">SuperAdmin</span></li>`).join('') || '<li><span class="muted">Todavía no hay nadie asignado.</span></li>'}</ul>`,
      esSuperAdmin() ? `<a class="btn btn-sm btn-tint" href="${href('/usuarios')}">${icon('plus')}Agregar</a>` : '');

    const porVencer = panel('Lo que viene', 'Cobros por vencer en los próximos treinta días.',
      table([
        {k: 'cliente', l: 'Cliente', f: v => `<b class="strong">${esc(v)}</b>`},
        {k: 'monto', l: 'Monto', n: 1, f: v => esc(usd(v))},
        {k: 'vence', l: 'Vence', f: v => `<span title="${esc(v)}">${esc(fday(v))}</span>`},
        {k: 'estado', l: 'Estado', f: v => v === 'vencido' ? '<span class="sc sc-bad">Vencido</span>' : '<span class="sc sc-gray">Por vencer</span>'},
      ], d.porVencer || [], {empty: '<b>Nada por vencer</b>No hay cobros pendientes en los próximos treinta días.'}));

    return cabeza + hero + `<div class="grid g2 mt">${responsables}${espacios || porVencer}</div>` + (espacios ? `<div class="mt">${porVencer}</div>` : '');
  },
};

/* =====================================================================================
   Tareas · lo que cada ejecutivo tiene pendiente
   ===================================================================================== */
const cargarTareas = async forzar => {
  if (!forzar && DATOS.tareas) return DATOS.tareas;
  const d = await agoraApi(`workspace/tareas?period=${encodeURIComponent(PERIODO)}`);
  DATOS.tareas = Array.isArray(d.items) ? d.items : [];
  DATOS.tareasResumen = d.resumen || null;
  return DATOS.tareas;
};
const tareasPendientes = () => (DATOS.tareas || []).filter(t => t.estado !== 'hecha').length || null;
const hoyYMD = () => new Date().toISOString().slice(0, 10);
const ORIGEN = {recordatorio: 'Recordatorio de chat', manual: 'Creada a mano', sistema: 'Del sistema', convenio: 'Convenio'};

V.tareas = {
  need: () => cargarTareas(),
  render() {
    const st = state.tareas;
    const lede = 'Lo que cada ejecutivo tiene por delante. Los recordatorios que pones en un chat caen aquí solos.';
    const acts = `<button class="btn btn-cta" type="button" data-tarea-nueva>${icon('plus')}Nueva tarea</button>`;
    const cabeza = head('Seguimiento', 'Tareas', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.tareas) return cabeza + loading();

    const todas = DATOS.tareas, hoy = hoyYMD();
    const abiertas = todas.filter(t => t.estado !== 'hecha');
    const vencidas = abiertas.filter(t => t.vence && t.vence < hoy);
    const deHoy = abiertas.filter(t => t.vence === hoy);
    const hechas = todas.filter(t => t.estado === 'hecha');
    const responsables = [...new Set(todas.map(t => t.responsable).filter(Boolean))];

    const q = norm(st.q);
    let filas = todas.filter(t => {
      if (st.estado === 'abiertas' && t.estado === 'hecha') return false;
      if (st.estado === 'vencidas' && !(t.estado !== 'hecha' && t.vence && t.vence < hoy)) return false;
      if (st.estado === 'hoy' && t.vence !== hoy) return false;
      if (st.estado === 'hechas' && t.estado !== 'hecha') return false;
      if (st.resp && t.responsable !== st.resp) return false;
      return !q || norm(`${t.titulo} ${t.contacto || ''} ${t.responsable || ''}`).includes(q);
    });
    filas = sortRows(filas, st);

    const cols = [
      {k: 'titulo', l: 'Tarea', sort: 1, f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(ORIGEN[r.origen] || 'Tarea')}${r.detalle ? ' · ' + esc(r.detalle) : ''}</small></span>`},
      {k: 'contacto', l: 'Contacto', f: (v, r) => v ? `<button class="lnk-btn" type="button" data-tarea-chat="${esc(r.conversationId || '')}" data-contacto="${esc(r.contactId || '')}">${esc(v)}</button>` : '<span class="muted">—</span>'},
      {k: 'responsable', l: 'Responsable', sort: 1, f: v => esc(v || 'Sin asignar')},
      {k: 'vence', l: 'Vence', sort: 1, f: (v, r) => {
        if (!v) return '<span class="muted">Sin fecha</span>';
        const tarde = r.estado !== 'hecha' && v < hoy;
        return `<span class="${tarde ? 'down' : ''}" title="${esc(v)}">${esc(fday(v))}${r.hora ? ' · ' + esc(r.hora) : ''}</span>`;
      }},
      {k: 'estado', l: 'Estado', f: v => v === 'hecha' ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Hecha</span>' : '<span class="lt lt-warn"><i aria-hidden="true"></i>Pendiente</span>'},
      {k: 'id', l: '', cls: 'act', f: (v, r) => r.estado === 'hecha'
        ? `<button class="btn btn-sm" type="button" data-tarea-abrir="${esc(v)}">Reabrir</button>`
        : `<button class="btn btn-sm btn-tint" type="button" data-tarea-hecha="${esc(v)}">${icon('check')}<span>Marcar hecha</span></button>`},
    ];

    return cabeza
      + `<div class="grid g4">
        ${metric('Para hoy', int(deHoy.length), deHoy.length ? 'Escribe o llama hoy mismo' : 'Nada vence hoy', {filter: 'hoy', on: st.estado === 'hoy'})}
        ${metric('Vencidas', int(vencidas.length), vencidas.length ? 'Pasó la fecha y siguen abiertas' : 'Ninguna atrasada', {filter: 'vencidas', on: st.estado === 'vencidas'})}
        ${metric('Abiertas', int(abiertas.length), `${int(todas.length)} en total`, {filter: 'abiertas', on: st.estado === 'abiertas'})}
        ${metric('Hechas', int(hechas.length), 'En este periodo', {filter: 'hechas', on: st.estado === 'hechas'})}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Tarea, contacto o responsable')}
          <label class="fld">Responsable<select data-f="resp"><option value="">Todos</option>${responsables.map(r => `<option value="${esc(r)}" ${st.resp === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
          ${st.q || st.resp || st.estado ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, filas, {sortKey: st.sk, sortDir: st.sd, empty: '<b>No hay tareas con estos filtros</b>Prueba con otro responsable o quita los filtros.'})}
        <p class="src">Los recordatorios que pones desde un chat aparecen aquí y dejan la conversación de primera en la bandeja hasta que escribes.</p></section>`;
  },
};

function tareaModal(previa) {
  const hoy = hoyYMD();
  const s = openModal(modalHead(previa?.titulo ? 'Editar tarea' : 'Nueva tarea', 'Queda a nombre de quien la tiene que hacer, con su fecha.') + `<form class="form" novalidate>
    <label class="fld">¿Qué hay que hacer?<input name="titulo" value="${esc(previa?.titulo || '')}" autofocus placeholder="Llamar para confirmar la inscripción"></label>
    <label class="fld">Detalle (opcional)<input name="detalle" value="${esc(previa?.detalle || '')}" placeholder="Quedó en responder después de hablar con su esposo"></label>
    <div class="grid g2">
      <label class="fld">Fecha<input name="vence" type="date" value="${esc(previa?.vence || hoy)}" min="${hoy}"></label>
      <label class="fld">Hora<input name="hora" type="time" value="${esc(previa?.hora || '09:00')}"></label>
    </div>
    <label class="fld">Responsable<input name="responsable" value="${esc(previa?.responsable || quienSoy())}"></label>
    <p class="fld-err" role="alert"></p>
    <div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">Guardar tarea</button></div></form>`);
  const f = s.querySelector('form');
  f.onsubmit = async ev => {
    ev.preventDefault();
    const fd = Object.fromEntries(new FormData(f)), err = f.querySelector('.fld-err');
    if (!fd.titulo.trim()) { err.textContent = 'Escribe qué hay que hacer.'; return; }
    const b = f.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try {
      await agoraApi('workspace/tareas', {method: 'POST', body: {...fd, origen: previa?.origen || 'manual', contactId: previa?.contactId || null, conversationId: previa?.conversationId || null}});
      closeModal(); await cargarTareas(true); repaint(); toast('Tarea guardada.');
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
async function cambiarTarea(id, estado) {
  try { await agoraApi(`workspace/tareas/${encodeURIComponent(id)}/estado`, {method: 'POST', body: {estado}}); await cargarTareas(true); repaint(); toast(estado === 'hecha' ? 'Tarea marcada como hecha.' : 'Tarea reabierta.'); }
  catch (x) { toast(x.message); }
}

/* =====================================================================================
   Auditoría · la trazabilidad
   ===================================================================================== */
const MODULOS_AUD = {contacto: 'Contactos', conversacion: 'Conversaciones', oportunidad: 'Oportunidades', convenio: 'Contratos', usuario: 'Usuarios', ajuste: 'Ajustes', sesion: 'Acceso'};
const ACCION_TONO = {creo: 'ok', edito: 'info', elimino: 'bad', envio: 'info', firmo: 'ok', entro: 'gray', salio: 'gray', asigno: 'info', exporto: 'warn', bloqueo: 'bad'};
const cargarAuditoria = async forzar => {
  if (!forzar && DATOS.auditoria) return DATOS.auditoria;
  const st = state.auditoria;
  const d = await agoraApi(`workspace/auditoria?period=${encodeURIComponent(PERIODO)}${st.modulo ? '&modulo=' + encodeURIComponent(st.modulo) : ''}`);
  DATOS.auditoria = Array.isArray(d.items) ? d.items : [];
  DATOS.auditoriaResumen = d.resumen || null;
  return DATOS.auditoria;
};

V.auditoria = {
  need: () => cargarAuditoria(),
  render() {
    const st = state.auditoria;
    const lede = 'Quién tocó cada contacto, qué cambió, cuándo y desde dónde. Nada se borra de aquí.';
    const acts = `<button class="btn" type="button" data-aud-exportar>${icon('download')}Exportar</button><button class="btn" type="button" data-aud-recargar>${icon('refresh')}Actualizar</button>`;
    const cabeza = head('Trazabilidad', 'Auditoría', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.auditoria) return cabeza + loading();

    const todos = DATOS.auditoria, hoy = new Date().toDateString();
    const deHoy = todos.filter(e => utc(e.at)?.toDateString() === hoy);
    const contactos = new Set(todos.filter(e => e.contactId).map(e => e.contactId));
    const actores = [...new Set(todos.map(e => e.actor).filter(Boolean))];
    const sensibles = todos.filter(e => ['elimino', 'exporto', 'bloqueo'].includes(e.accion));

    const q = norm(st.q);
    const filas = todos.filter(e => (!st.modulo || e.modulo === st.modulo) && (!st.actor || e.actor === st.actor)
      && (!q || norm(`${e.actor} ${e.objeto || ''} ${e.contacto || ''} ${e.detalle || ''}`).includes(q)));
    const pagina = filas.slice(st.p * 50, st.p * 50 + 50);

    const cols = [
      {k: 'at', l: 'Cuándo', f: v => `<span class="who-cell"><b>${esc(when(v))}</b><small>${esc(fstamp(v))}</small></span>`},
      {k: 'actor', l: 'Quién', f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(r.rol || '')}</small></span>`},
      {k: 'accion', l: 'Qué hizo', f: (v, r) => `<span class="sc sc-${ACCION_TONO[v] || 'gray'}">${esc(r.accionTexto || v)}</span>`},
      {k: 'modulo', l: 'Módulo', f: v => esc(MODULOS_AUD[v] || v)},
      {k: 'objeto', l: 'Sobre qué', f: (v, r) => r.contacto
        ? `<span class="who-cell"><b>${esc(r.contacto)}</b><small>${esc(v || '')}</small></span>`
        : `<span>${esc(v || '—')}</span>`},
      {k: 'id', l: '', cls: 'act', f: (v, r) => `<button class="btn btn-sm" type="button" data-aud="${esc(v)}">Ver</button>`},
    ];

    return cabeza
      + `<div class="grid g4">
        ${metric('Movimientos hoy', int(deHoy.length), `${int(todos.length)} en ${esc(mesNombre(PERIODO).toLowerCase())}`)}
        ${metric('Contactos tocados', int(contactos.size), 'Fichas con algún cambio')}
        ${metric('Personas activas', int(actores.length), 'Dejaron rastro en el periodo')}
        ${metric('Acciones delicadas', int(sensibles.length), 'Borrados, exportaciones y bloqueos')}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Persona, contacto o detalle')}
          <label class="fld">Módulo<select data-f="modulo"><option value="">Todos</option>${Object.keys(MODULOS_AUD).map(m => `<option value="${m}" ${st.modulo === m ? 'selected' : ''}>${esc(MODULOS_AUD[m])}</option>`).join('')}</select></label>
          <label class="fld">Persona<select data-f="actor"><option value="">Todas</option>${actores.map(a => `<option value="${esc(a)}" ${st.actor === a ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
          ${st.q || st.modulo || st.actor ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, pagina, {empty: '<b>No hay movimientos con estos filtros</b>Prueba con otro módulo o con otra persona.'})}${pager(st, filas.length, 50)}
        <p class="src">El registro se guarda completo en el servidor; aquí se muestran los del periodo elegido.</p></section>`;
  },
};

function auditoriaDetalle(id) {
  const e = (DATOS.auditoria || []).find(x => String(x.id) === String(id));
  if (!e) return;
  const cambios = e.antes || e.despues
    ? `<h4 class="h4">Qué cambió</h4><div class="tw"><table><thead><tr><th>Campo</th><th>Antes</th><th>Después</th></tr></thead><tbody>${
      Object.keys({...(e.antes || {}), ...(e.despues || {})}).map(k => `<tr><td>${esc(k)}</td><td class="muted">${esc(String((e.antes || {})[k] ?? '—'))}</td><td><b class="strong">${esc(String((e.despues || {})[k] ?? '—'))}</b></td></tr>`).join('')
    }</tbody></table></div>` : '';
  openModal(modalHead(esc(e.accionTexto || e.accion), esc(fstamp(e.at)))
    + kv([
      ['Persona', `${esc(e.actor)}${e.rol ? ' · ' + esc(e.rol) : ''}`],
      ['Módulo', esc(MODULOS_AUD[e.modulo] || e.modulo)],
      ['Sobre qué', esc(e.objeto || '—')],
      ['Contacto', e.contacto ? esc(e.contacto) : '—'],
      ['Desde dónde', `${esc(e.dispositivo || 'Desconocido')}${e.ip ? ' · ' + esc(e.ip) : ''}`],
      ['Origen', esc(e.origen === 'ghl' ? 'Go High Level' : e.origen || 'Sistema')],
    ])
    + cambios
    + `<div class="form-ft">${e.contactId ? `<button class="btn btn-tint" type="button" data-aud-contacto="${esc(e.contactId)}">${icon('user')}Abrir la ficha</button>` : ''}<button class="btn" type="button" data-close>Cerrar</button></div>`);
}

/* =====================================================================================
   Usuarios y roles
   ===================================================================================== */
const ROLES_SISTEMA = {
  SUPERADMIN: {l: 'SuperAdmin', d: 'Todo el sistema: espacios, identidad, usuarios y cifras del negocio.', c: 'var(--mod-seguridad)'},
  ADMIN: {l: 'Administración', d: 'Todo lo de su espacio: conexiones, equipo, convenios y tablero.', c: 'var(--brand)'},
  SUPERVISOR: {l: 'Supervisión', d: 'Ve a todo el equipo, reasigna conversaciones y revisa la auditoría.', c: 'var(--mod-azul)'},
  EJECUTIVO: {l: 'Ejecutivo', d: 'Atiende sus conversaciones, sus contactos y sus convenios.', c: 'var(--mod-oro)'},
  CONSULTA: {l: 'Consulta', d: 'Solo mira lo que tiene asignado. No cambia nada.', c: 'var(--muted-2)'},
};
const PERMISOS_MATRIZ = [
  ['Ver el Resumen del negocio', ['SUPERADMIN']],
  ['Agregar espacios y subir su logo', ['SUPERADMIN']],
  ['Crear usuarios y cambiar roles', ['SUPERADMIN', 'ADMIN']],
  ['Conectar cuentas y editar ajustes', ['SUPERADMIN', 'ADMIN']],
  ['Ver la auditoría', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Ver las cifras de todo el equipo', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Reasignar conversaciones', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Atender conversaciones y contactos', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR', 'EJECUTIVO']],
  ['Crear y enviar convenios', ['SUPERADMIN', 'ADMIN', 'EJECUTIVO']],
  ['Solo consultar', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR', 'EJECUTIVO', 'CONSULTA']],
];
const cargarUsuarios = async forzar => {
  if (!forzar && DATOS.usuarios) return DATOS.usuarios;
  const d = await agoraApi('workspace/usuarios');
  DATOS.usuarios = Array.isArray(d.items) ? d.items : [];
  return DATOS.usuarios;
};

V.usuarios = {
  need: () => Promise.all([cargarUsuarios(), ESPACIO ? Promise.resolve() : bootEspacio()]),
  render() {
    const st = state.usuarios;
    const lede = 'Quién entra al sistema, con qué rol y qué puede hacer. Aquí también vive la identidad del espacio.';
    const acts = esAdmin() ? `<button class="btn btn-cta" type="button" data-usuario-nuevo>${icon('plus')}Agregar persona</button>` : '';
    const cabeza = head('Acceso', 'Usuarios y roles', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.usuarios) return cabeza + loading();

    const todos = DATOS.usuarios, activos = todos.filter(u => u.estado !== 'inactivo');
    const q = norm(st.q);
    const filas = todos.filter(u => (!st.rol || u.rol === st.rol) && (!q || norm(`${u.nombre} ${u.correo}`).includes(q)));

    const cols = [
      {k: 'nombre', l: 'Persona', f: (v, r) => `<span class="who-cell"><b>${esc(v)}${r.yo ? ' <span class="sc sc-gray">Tú</span>' : ''}</b><small>${esc(r.correo)}</small></span>`},
      {k: 'rol', l: 'Rol', f: v => `<span class="rol-chip" style="--c:${ROLES_SISTEMA[v]?.c || 'var(--muted)'}">${esc(ROLES_SISTEMA[v]?.l || v)}</span>`},
      {k: 'origen', l: 'De dónde', f: v => esc(v === 'ghl' ? 'Equipo de Go High Level' : v === 'contratos' ? 'Panel de Contratos' : 'Del sistema')},
      {k: 'ultimoAcceso', l: 'Último acceso', f: v => v ? `<span title="${esc(fstamp(v))}">${esc(when(v))}</span>` : '<span class="muted">Nunca</span>'},
      {k: 'estado', l: 'Estado', f: v => v === 'inactivo' ? '<span class="lt lt-bad"><i aria-hidden="true"></i>Desactivada</span>' : '<span class="lt lt-ok"><i aria-hidden="true"></i>Activa</span>'},
      {k: 'id', l: '', cls: 'act', f: (v, r) => esAdmin() && r.origen !== 'ghl' ? `<button class="btn btn-sm" type="button" data-usuario="${esc(v)}" aria-haspopup="true">${icon('more')}<span>Opciones</span></button>` : ''},
    ];

    const identidad = esSuperAdmin() ? panel('Identidad del espacio', 'El logo que verá el cliente en su pantalla de inicio y en la barra.',
      `<div class="ident">
        <div class="ident-prev">${ESPACIO?.logo ? `<img src="${esc(ESPACIO.logo)}" alt="Logo de ${esc(ESPACIO?.nombre || 'la empresa')}">` : `<span class="ident-vacio">${icon('upload')}Sin logo</span>`}</div>
        <form class="form ident-f" novalidate>
          <label class="fld">Nombre de la empresa<input name="nombre" value="${esc(ESPACIO?.nombre || '')}" placeholder="ASOCIM"></label>
          <label class="fld">Logo<input name="logo" type="file" accept="image/png,image/jpeg,image/webp"><small class="hint">PNG, JPG o WebP. Se ve mejor con el fondo transparente y al menos 240 px de ancho.</small></label>
          <p class="fld-err" role="alert"></p>
          <div class="form-ft" style="justify-content:flex-start"><button class="btn btn-cta" type="submit">Guardar identidad</button>${ESPACIO?.logo ? '<button class="btn" type="button" data-logo-quitar>Quitar el logo</button>' : ''}</div>
        </form>
      </div>`) : '';

    const matriz = panel('Qué puede hacer cada rol', 'La misma regla vale en todos los módulos.',
      `<div class="tw full"><table class="matriz"><thead><tr><th>Puede</th>${Object.keys(ROLES_SISTEMA).map(r => `<th class="n">${esc(ROLES_SISTEMA[r].l)}</th>`).join('')}</tr></thead>
        <tbody>${PERMISOS_MATRIZ.map(([q2, roles]) => `<tr><td>${esc(q2)}</td>${Object.keys(ROLES_SISTEMA).map(r => `<td class="n">${roles.includes(r) ? `<span class="si" title="Sí">${icon('check')}</span>` : '<span class="no" aria-label="No">·</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);

    return cabeza
      + `<div class="grid g4">
        ${metric('Personas activas', int(activos.length), `${int(todos.length - activos.length)} desactivada${todos.length - activos.length === 1 ? '' : 's'}`)}
        ${['SUPERADMIN', 'ADMIN', 'EJECUTIVO'].map(r => metric(ROLES_SISTEMA[r].l, int(activos.filter(u => u.rol === r).length), ROLES_SISTEMA[r].d, {filter: r, on: st.rol === r})).join('')}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Nombre o correo')}${st.q || st.rol ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, filas, {empty: '<b>Nadie coincide</b>Prueba con otro nombre o quita los filtros.'})}</section>`
      + (identidad ? `<div class="mt">${identidad}</div>` : '')
      + `<div class="mt">${matriz}</div>`;
  },
};

function usuarioModal(previo) {
  const roles = Object.keys(ROLES_SISTEMA).filter(r => r !== 'SUPERADMIN' || esSuperAdmin());
  const s = openModal(modalHead(previo ? 'Cambiar rol' : 'Agregar persona', previo ? esc(previo.nombre) : 'Entra con su correo y la clave temporal que le compartas.')
    + `<form class="form" novalidate>
      ${previo ? '' : `<label class="fld">Nombre completo<input name="nombre" autofocus></label><label class="fld">Correo<input name="correo" type="email"></label>
      <label class="fld">Clave temporal (mínimo 12 caracteres)<span class="pw-in"><input name="clave" value="${claveAzar()}" autocomplete="off"><button class="pw-eye" type="button" data-regen>Otra</button></span></label>`}
      <div class="seg-fld">Rol${seg('rol-sys', roles.map(r => [r, ROLES_SISTEMA[r].l]), previo?.rol || 'EJECUTIVO', 'Rol')}</div>
      <ul class="role-help">${roles.map(r => `<li><span class="rol-punto" style="--c:${ROLES_SISTEMA[r].c}"></span><span><b class="strong">${esc(ROLES_SISTEMA[r].l)}:</b> ${esc(ROLES_SISTEMA[r].d)}</span></li>`).join('')}</ul>
      <p class="fld-err" role="alert"></p>
      <div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">${previo ? 'Guardar rol' : 'Agregar persona'}</button></div></form>`);
  const f = s.querySelector('form');
  s.querySelector('[data-regen]')?.addEventListener('click', () => { f.clave.value = claveAzar(); });
  f.onsubmit = async ev => {
    ev.preventDefault();
    const fd = Object.fromEntries(new FormData(f)), err = f.querySelector('.fld-err');
    fd.rol = f.querySelector('[data-seg="rol-sys"] .is-on')?.dataset.v || 'EJECUTIVO';
    if (!previo) {
      if (!String(fd.nombre || '').trim() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(fd.correo || '').trim())) { err.textContent = 'Escribe el nombre y un correo válido.'; return; }
      if (String(fd.clave || '').length < 12) { err.textContent = 'La clave temporal debe tener al menos 12 caracteres.'; return; }
    }
    const b = f.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try {
      if (previo) await agoraApi('workspace/usuarios/rol', {method: 'POST', body: {id: previo.id, rol: fd.rol}});
      else await agoraApi('workspace/usuarios', {method: 'POST', body: fd});
      closeModal(); await cargarUsuarios(true); repaint();
      if (previo) toast('Rol actualizado.');
      else openModal(modalHead('Persona agregada', `Comparte la clave con ${esc(fd.nombre)} por un canal seguro. Se le pedirá cambiarla.`) + `<div class="secret"><code>${esc(fd.clave)}</code><button class="btn btn-sm btn-cta" type="button" data-copy="${esc(fd.clave)}">Copiar</button></div><p class="src">Correo para entrar: ${esc(fd.correo)}</p><div class="form-ft"><button class="btn" type="button" data-close>Listo</button></div>`);
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function usuarioMenu(id, ancla) {
  const u = (DATOS.usuarios || []).find(x => String(x.id) === String(id));
  if (!u) return;
  const el = openPop(ancla, `<button type="button" data-u="rol">${icon('shield')}Cambiar rol</button>${u.estado === 'inactivo' ? `<button type="button" data-u="on">${icon('check')}Reactivar</button>` : `<button type="button" data-u="off">${icon('pause')}Desactivar</button>`}`, 'ctx', {align: 'right'});
  if (!el) return;
  el.setAttribute('role', 'menu');
  el.onclick = async e => {
    const a = e.target.closest('[data-u]')?.dataset.u; if (!a) return; closePop();
    if (a === 'rol') return usuarioModal(u);
    const estado = a === 'off' ? 'inactivo' : 'activo';
    confirmModal(a === 'off' ? 'Desactivar persona' : 'Reactivar persona',
      a === 'off' ? `${esc(u.nombre)} dejará de entrar al sistema. Puedes reactivarla cuando quieras.` : `${esc(u.nombre)} podrá entrar otra vez.`,
      a === 'off' ? 'Desactivar' : 'Reactivar',
      async () => { await agoraApi('workspace/usuarios/estado', {method: 'POST', body: {id: u.id, estado}}); await cargarUsuarios(true); repaint(); toast(a === 'off' ? 'Persona desactivada.' : 'Persona reactivada.'); },
      a === 'off');
  };
}
/** El logo del cliente: se lee en el navegador y se manda al servidor junto al nombre. */
async function guardarIdentidad(form) {
  const err = form.querySelector('.fld-err'), b = form.querySelector('[type=submit]');
  const archivo = form.logo.files?.[0];
  let logo = ESPACIO?.logo || null;
  if (archivo) {
    if (archivo.size > 400 * 1024) { err.textContent = 'El logo debe pesar menos de 400 KB.'; return; }
    logo = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(archivo); });
  }
  busy(b, true, 'Guardando…'); err.textContent = '';
  try {
    const d = await agoraApi('workspace/branding', {method: 'POST', body: {nombre: form.nombre.value.trim(), logo}});
    ESPACIO = {...(ESPACIO || {}), ...d, nombre: form.nombre.value.trim(), logo};
    topbar(); repaint(); toast('Identidad guardada.');
  } catch (x) { busy(b, false); err.textContent = x.message; }
}

/* =====================================================================================
   Lo que el tablero comercial necesita del armazón
   -------------------------------------------------------------------------------------
   Los módulos de Ágora van en otro paquete, así que las piezas de dibujo y el formato
   del dinero se les prestan por aquí. También guardan lo que leen, para que Athena pueda
   responder sobre ello sin volver a preguntarle al servidor.
   ===================================================================================== */
window.AgoraUI = {
  donut, barras, lineaArea, usd, firmado, mesNombre, mesCorto,
  guardarDia: d => { DATOS.dia = d; },
  guardarAds: a => { DATOS.ads = a; },
  guardarEficacia: e => { DATOS.eficacia = e; },
};

/* =====================================================================================
   Eventos de los módulos nuevos
   ===================================================================================== */
document.addEventListener('click', e => {
  const t = e.target, c = s => t.closest?.(s);
  let el;
  if (c('[data-tarea-nueva]')) { tareaModal(); return; }
  if ((el = c('[data-tarea-hecha]'))) { cambiarTarea(el.dataset.tareaHecha, 'hecha'); return; }
  if ((el = c('[data-tarea-abrir]'))) { cambiarTarea(el.dataset.tareaAbrir, 'pendiente'); return; }
  if ((el = c('[data-tarea-chat]'))) {
    const id = el.dataset.tareaChat;
    if (id && ws) { ws.pendingConversation = {id, explicit: true}; go('/bandeja'); }
    else go('/contactos');
    return;
  }
  if ((el = c('[data-aud]'))) { auditoriaDetalle(el.dataset.aud); return; }
  if (c('[data-aud-recargar]')) { DATOS.auditoria = null; render(); return; }
  if (c('[data-aud-exportar]')) { exportarAuditoria(); return; }
  if ((el = c('[data-aud-contacto]'))) { closeModal(); go('/contactos'); return; }
  if (c('[data-usuario-nuevo]')) { usuarioModal(); return; }
  if ((el = c('[data-usuario]'))) { usuarioMenu(el.dataset.usuario, el); return; }
  if (c('[data-logo-quitar]')) {
    confirmModal('Quitar el logo', 'El espacio volverá a mostrar solo el nombre.', 'Quitar', async () => {
      await agoraApi('workspace/branding', {method: 'POST', body: {nombre: ESPACIO?.nombre || '', logo: null}});
      ESPACIO = {...(ESPACIO || {}), logo: null}; topbar(); repaint(); toast('Logo quitado.');
    }, true);
    return;
  }
  if (c('[data-informe]')) { descargarInforme(); return; }
});
document.addEventListener('submit', e => {
  const f = e.target.closest('.ident-f');
  if (!f) return;
  e.preventDefault();
  guardarIdentidad(f);
});

/** El informe del mes, en un archivo que se abre en cualquier hoja de cálculo. */
function descargarInforme() {
  const d = DATOS.resumen;
  if (!d) { toast('Todavía no hay cifras que llevar al informe.'); return; }
  const filas = [
    ['Periodo', mesNombre(PERIODO)],
    ['Ingreso recurrente mensual (MRR)', d.mrr],
    ['Mes anterior', d.mrrAnterior],
    ['Recurrente anual (ARR)', d.arr],
    ['Recaudado en el mes', d.recaudado],
    ['Egresos del mes', d.egresos],
    ['Saldo de caja', d.caja],
    ['Clientes activos', d.clientesActivos],
    ['Clientes en baja', d.churn],
  ];
  bajarCsv(`resumen-${PERIODO}.csv`, [['Concepto', 'Valor'], ...filas]);
}
function exportarAuditoria() {
  const items = DATOS.auditoria || [];
  if (!items.length) { toast('No hay movimientos que exportar.'); return; }
  bajarCsv(`auditoria-${PERIODO}.csv`, [
    ['Fecha', 'Persona', 'Rol', 'Acción', 'Módulo', 'Sobre qué', 'Contacto', 'Desde dónde'],
    ...items.map(e => [fstamp(e.at), e.actor, e.rol || '', e.accionTexto || e.accion, MODULOS_AUD[e.modulo] || e.modulo, e.objeto || '', e.contacto || '', `${e.dispositivo || ''} ${e.ip || ''}`.trim()]),
  ]);
}
function bajarCsv(nombre, filas) {
  const texto = filas.map(f => f.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['﻿' + texto], {type: 'text/csv;charset=utf-8'}));
  a.download = nombre;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast('Archivo descargado.');
}
