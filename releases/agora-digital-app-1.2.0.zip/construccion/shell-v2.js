/* =====================================================================================
   Armazón de Agora Digital App
   -------------------------------------------------------------------------------------
   La barra de arriba, el menú de módulos, el periodo, los accesos de Inicio, Ajustes y
   Auditoría, el estado del espacio, el historial y Athena. Todo con las piezas que ya
   trae el sistema de diseño: .tb con el vidrio esmerilado, .crumb, .mdm, .ath.

   Aquí vive también el puente con los módulos de Ágora: se montan tal como vienen, en un
   <section id="view" data-view="…">, que es el nodo que su propio código espera.
   ===================================================================================== */

var AG = (window.Agora || {});
var AG_READY = typeof AG.renderDashboard === 'function';
var ws = AG.workspace || null;

/* Se declaran con var a propósito: la primera ruta se calcula antes de que este bloque
   corra, y al preguntar «¿hay sesión?» tiene que responder «todavía no», no fallar. */
var AGORA_ME = null;          // sesión de Ágora
var AGORA_CONN = [];          // subcuentas a las que llega esta persona
var AGORA_REASON = null;
var unread = 0;               // conversaciones sin leer
var wonPendientes = 0;        // ventas ganadas sin monto
var ESPACIO = null;           // identidad del espacio: nombre y logo del cliente

function agoraReady() { return AG_READY && !!AGORA_ME; }
function agoraAdmin() { return agoraReady() && AGORA_ME.user?.role === 'administrator'; }
/** Quien manda en el sistema: el propietario de Ágora o la administración del panel. */
function esAdmin() { return agoraAdmin() || (!!ME && ME.rol === 'ADMIN'); }
function esSuperAdmin() { return agoraAdmin() || (!!ME && ME.rol === 'ADMIN'); }
function puedeAuditar() { return esAdmin(); }

/* ---------- API de Ágora (su propia base; ver assets/config.js) ---------- */
async function agoraApi(path, {method = 'GET', body} = {}) {
  let r;
  try {
    r = await fetch(AGORA_API + path, {
      method, credentials: 'same-origin', cache: 'no-store',
      headers: {...(body !== undefined ? {'Content-Type': 'application/json'} : {}), ...(method !== 'GET' && AGORA_ME?.csrf ? {'X-CSRF-Token': AGORA_ME.csrf} : {})},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error(navigator.onLine ? 'No se pudo conectar con el servidor. Inténtalo de nuevo.' : 'Sin conexión. Revisa tu internet.');
  }
  let d = {}; try { d = await r.json(); } catch { /* respuesta vacía */ }
  if (!r.ok) throw Object.assign(new Error(d.error || `No se pudo completar (código ${r.status}).`), {status: r.status, code: d.code});
  return d;
}

/* =====================================================================================
   El periodo: un mes, el mismo para el Resumen y para ARP Comercial
   ===================================================================================== */
var PERIODO = (() => {
  const guardado = store.get('periodo', '');
  if (/^\d{4}-\d{2}$/.test(guardado)) return guardado;
  const h = new Date();
  return `${h.getFullYear()}-${String(h.getMonth() + 1).padStart(2, '0')}`;
})();
const mesActualYM = () => { const h = new Date(); return `${h.getFullYear()}-${String(h.getMonth() + 1).padStart(2, '0')}`; };
const mesNombre = ym => { const [y, m] = String(ym).split('-'); return `${cap(MESES[Number(m) - 1] || '')} ${y}`; };
const mesCorto = ym => { const [, m] = String(ym).split('-'); return cap((MESES[Number(m) - 1] || '').slice(0, 3)); };
const mesSuma = (ym, n) => { const [y, m] = ym.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
/** En curso el mes corriente; por delante, el que todavía no empieza. */
const mesEstado = ym => ym === mesActualYM() ? 'curso' : (ym > mesActualYM() ? 'proximo' : 'cerrado');
function ponerPeriodo(ym) {
  if (ym === PERIODO) return;
  PERIODO = ym; store.set('periodo', ym);
  render();
}

/* =====================================================================================
   Montaje de un módulo de Ágora dentro del lienzo
   ===================================================================================== */
var agHost = null;
function disposeAgora() {
  if (!agHost) return;
  try { agHost.agoraLiveDispose?.(); } catch { /* soltar nunca debe trabar la vista */ }
  agHost = null;
}
const agoraGate = what => `<section class="panel"><p class="empty"><b>Entra en Ágora para ver ${esc(what)}</b>Este módulo lee los datos de tu cuenta de Ágora. Tu sesión de Contratos sigue abierta.<br><button class="btn btn-cta" type="button" data-agora-login>${icon('lock')}Entrar en Ágora</button></p></section>`;
const AG_RENDER = {dashboard: 'renderDashboard', inbox: 'renderLiveInbox', contacts: 'renderContacts', board: 'renderBoard', settings: 'renderIntegrations', help: 'renderHelp'};

function agoraView(id, {eyebrow, title, lede, what, own = false, acts = () => ''}) {
  V['ag_' + id] = {
    render() {
      if (!AG_READY) return head(eyebrow, title, lede) + `<section class="panel"><p class="empty"><b>Falta el paquete de módulos</b>No se cargó <code>assets/agora-modulos.js</code>. Revisa que esté junto a esta página.</p></section>`;
      if (!AGORA_ME) return head(eyebrow, title, lede) + agoraGate(what);
      return (own ? '' : head(eyebrow, title, lede, acts())) + `<section id="view" class="ag" data-view="${esc(id)}"></section>`;
    },
    mounted(app) {
      if (!agoraReady()) return;
      const host = app.querySelector('#view');
      if (!host) return;
      agHost = host;
      host.dataset.periodo = PERIODO;
      try { AG[AG_RENDER[id]](host); }
      catch (x) { host.innerHTML = `<p class="empty"><b>No se pudo abrir el módulo</b>${esc(x.message || 'Error inesperado')}</p>`; }
    },
  };
}

agoraView('dashboard', {eyebrow: 'Operación', title: 'ARP Comercial', lede: 'Las cifras del día, la inversión en anuncios y la rentabilidad del mes.', what: 'el tablero comercial', own: true});
agoraView('inbox', {eyebrow: 'Atención', title: 'Bandeja de conversaciones', lede: 'Todos los canales en una sola lista, con recordatorios de seguimiento.', what: 'las conversaciones'});
agoraView('contacts', {eyebrow: 'Cartera', title: 'Contactos', lede: 'Las fichas de la subcuenta, con su historial y sus etiquetas.', what: 'los contactos'});
agoraView('board', {eyebrow: 'Embudo', title: 'Oportunidades', lede: 'De la conexión al cierre: cada oportunidad abierta, a la vista.', what: 'las oportunidades'});
agoraView('settings', {eyebrow: 'Administración', title: 'Ajustes', lede: 'Las cuentas conectadas, el equipo importado y los avisos.', what: 'los ajustes'});
agoraView('help', {
  eyebrow: 'Manual', title: 'Ayuda', lede: 'Lo básico para trabajar en el sistema.', what: 'el manual',
  acts: () => `<a class="btn btn-tint" href="${esc(AG.MANUAL_PDF || '/assets/manual-vendedores.pdf')}" download>${icon('download')}Descargar el PDF</a>`,
});

/* =====================================================================================
   La barra de arriba
   ===================================================================================== */
const LOGO_ESPACIO = () => ESPACIO?.logo
  ? `<img class="esp-logo" src="${esc(ESPACIO.logo)}" alt="${esc(ESPACIO.nombre || 'Logo del cliente')}">`
  : '';

/** La migaja: marca, separador y el módulo en uso con su contador. */
function crumb() {
  const m = MODS[R.mod];
  if (!m) return '';
  const n = m.n ? m.n() : null;
  return `<button class="crumb" id="b-crumb" type="button" aria-haspopup="menu" aria-expanded="false" title="Cambiar de módulo">
    <span class="mdm-ic" style="--c:${m.c || 'var(--brand)'}">${icon(m.icon)}</span>
    <span>${esc(m.name)}</span>
    ${n ? `<b class="nav-b">${int(n)}</b>` : ''}
    ${icon('chev', 'chev')}</button>`;
}

/** Los meses: el anterior, el de ahora y el que viene, con su estado. */
function periodBar() {
  if (!MODS[R.mod]?.periodo) return '';
  const meses = [mesSuma(PERIODO, -1), PERIODO, mesSuma(PERIODO, 1)];
  const punto = ym => mesEstado(ym) === 'curso' ? '<i class="pt pt-curso" aria-hidden="true"></i>' : mesEstado(ym) === 'proximo' ? '<i class="pt pt-prox" aria-hidden="true"></i>' : '';
  return `<nav class="per" aria-label="Periodo">
    <button class="per-b" type="button" data-mes="${mesSuma(PERIODO, -12)}" title="Un año atrás" aria-label="Un año atrás">${icon('chevL')}</button>
    ${meses.map(ym => `<button class="per-b ${ym === PERIODO ? 'is-on' : ''}" type="button" data-mes="${ym}" aria-current="${ym === PERIODO}">${mesCorto(ym)}${punto(ym)}</button>`).join('')}
    <button class="per-b" type="button" data-mes="${mesActualYM()}" title="Volver al mes en curso" aria-label="Mes en curso">${icon('home')}</button>
  </nav>`;
}

/** Los accesos fijos de la derecha, como en el ecosistema. */
function rightCluster() {
  const atajo = (id, ico, rotulo, titulo) => `<a class="tb-sc" href="${href(MODS[id].path)}" ${R.mod === id ? 'aria-current="page"' : ''} title="${esc(titulo)}">${icon(ico)}<span>${esc(rotulo)}</span></a>`;
  const bloqueada = ESPACIO?.bloqueado === true;
  return `
    <button class="tb-ic" id="b-hist" type="button" aria-haspopup="true" aria-expanded="false" title="Historial de lo que has visto">${icon('history')}</button>
    <button class="tb-search" id="b-search" type="button" title="Buscar o ir a… (${MODK} K)" aria-label="Buscar o ir a">${icon('search')}<span class="tb-search-t">Buscar</span><kbd>${IS_MAC ? '⌘K' : '⌘K'}</kbd></button>
    <button class="tb-ath" id="b-ath" type="button" aria-haspopup="dialog" aria-expanded="false" title="Athena, tu agente">${icon('athena', 'ath-ic')}<span>Athena</span></button>
    ${MODS.inicio.ok() ? atajo('inicio', 'home', 'Inicio', 'Resumen del negocio') : ''}
    ${MODS.conexiones.ok() ? atajo('conexiones', 'gear', 'Ajustes', 'Cuentas conectadas y equipo') : ''}
    ${MODS.auditoria.ok() ? atajo('auditoria', 'shield', 'Auditoría', 'Trazabilidad de contactos y cambios') : ''}
    <button class="tb-sc tb-estado ${bloqueada ? 'is-off' : ''}" id="b-estado" type="button" aria-haspopup="true" aria-expanded="false" title="Estado del espacio">${icon(bloqueada ? 'lock' : 'unlock')}<span>${bloqueada ? 'Bloqueada' : 'Activa'}</span></button>
    <button class="tb-ic" id="b-theme" type="button" title="Cambiar tema (D)" aria-label="Cambiar tema">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon')}</button>
    <button class="avatar" id="b-acct" type="button" aria-haspopup="true" aria-expanded="false" title="Tu cuenta">${esc(initials(quienSoy() || '?'))}</button>`;
}

const quienSoy = () => ME ? ME.nombre : (AGORA_ME?.user?.email || '');

function topbar() {
  $('#tb').innerHTML = `<a class="brand" href="${href(homePath())}" aria-label="Agora Digital App, ir al inicio">${LOGO}<small>Digital App</small></a>
    <span class="crumb-sep" aria-hidden="true">/</span>
    ${crumb()}
    ${LOGO_ESPACIO()}
    ${accountSwitch()}
    <div class="tb-mid">${periodBar()}</div>
    <div class="tb-r">${rightCluster()}</div>`;
  const tabs = ALL().slice(0, 5);
  $('#tabbar').style.setProperty('--tabs', tabs.length);
  $('#tabbar').innerHTML = tabs.map(id => `<a href="${href(MODS[id].path)}" ${id === R.mod ? 'aria-current="page"' : ''}>${icon(MODS[id].icon)}${esc(MODS[id].name.split(' ')[0])}</a>`).join('');
  const abiertas = [
    ME ? `Contratos · ${ROLES[ME.rol]?.l || ME.rol}` : '',
    AGORA_ME ? `Ágora · ${AGORA_ME.user?.role === 'administrator' ? 'administración' : 'equipo'}${ws && ws.name() ? ' · ' + ws.name() : ''}` : '',
  ].filter(Boolean);
  $('#foot').textContent = abiertas.join('   ·   ') || 'Sin sesión';
}

/* ---------- El menú de módulos ---------- */
function moduleMenu() {
  const grupos = Object.keys(GRUPOS).filter(g => ALL().some(k => MODS[k].g === g));
  const col = g => `<div><p class="mdm-gt">${esc(GRUPOS[g].name)}</p>${ALL().filter(k => MODS[k].g === g).map((id, i) => {
    const m = MODS[id], n = m.n ? m.n() : null;
    return `<a class="mdm-i ${id === R.mod ? 'is-on' : ''}" href="${href(m.path)}" data-mod="${id}">
      <span class="mdm-ic" style="--c:${m.c || 'var(--brand)'}">${icon(m.icon)}</span>
      <span class="tx"><b>${esc(m.name)}</b><small>${esc(m.desc || '')}</small></span>
      ${n ? `<b class="nav-b">${int(n)}</b>` : ''}</a>`;
  }).join('')}</div>`;
  const el = openPop($('#b-crumb'), `<div class="mdm-grid">${grupos.map(col).join('')}</div>
    <div class="mdm-ft"><span>Los números del teclado abren los módulos en orden</span><span><kbd>${IS_MAC ? '⌘K' : 'Ctrl K'}</kbd> para buscar</span></div>`, 'mdm');
  if (el) el.setAttribute('role', 'menu');
}

/* ---------- Historial: lo último que se ha visto ---------- */
function anotarHistorial() {
  if (!R.mod) return;
  const m = MODS[R.mod];
  const item = {p: path(), t: m.name, i: m.icon, c: m.c || 'var(--brand)', at: Date.now()};
  const prev = store.get('historial', []).filter(x => x.p !== item.p);
  store.set('historial', [item, ...prev].slice(0, 12));
}
function historialPop() {
  const items = store.get('historial', []).filter(x => x.p !== path());
  const el = openPop($('#b-hist'), items.length
    ? `<p class="mdm-gt">Lo último que has visto</p>${items.slice(0, 8).map(x => `<a class="mdm-i" href="${href(x.p)}"><span class="mdm-ic" style="--c:${x.c}">${icon(x.i)}</span><span class="tx"><b>${esc(x.t)}</b><small>${esc(when(new Date(x.at).toISOString()))}</small></span></a>`).join('')}`
    : '<p class="empty" style="padding:22px 16px"><b>Todavía no hay historial</b>Aquí queda lo último que abras.</p>', 'ctx hist', {align: 'right'});
  if (el) el.setAttribute('role', 'menu');
}

/* ---------- Estado del espacio ---------- */
function estadoPop() {
  const bloqueada = ESPACIO?.bloqueado === true;
  const puede = esSuperAdmin();
  const el = openPop($('#b-estado'), `<div class="est">
      <div class="est-h"><span class="lt ${bloqueada ? 'lt-bad' : 'lt-ok'}"><i aria-hidden="true"></i>${bloqueada ? 'Bloqueada' : 'Activa'}</span></div>
      <p>${bloqueada
        ? 'El equipo ve la pantalla de mantenimiento. Quien administra sigue entrando con normalidad.'
        : 'El equipo entra con normalidad. Al bloquearla, solo quien administra puede seguir trabajando.'}</p>
      ${puede ? `<button class="btn btn-sm ${bloqueada ? 'btn-cta' : 'btn-danger'}" type="button" data-bloqueo>${icon(bloqueada ? 'unlock' : 'lock')}${bloqueada ? 'Reabrir el espacio' : 'Bloquear el espacio'}</button>` : '<p class="src">Solo quien administra puede cambiarlo.</p>'}
    </div>`, 'ctx est', {align: 'right'});
  if (el && puede) el.querySelector('[data-bloqueo]').onclick = async e => {
    const b = e.currentTarget; busy(b, true, 'Guardando…');
    try {
      await agoraApi('admin/maintenance', {method: 'POST', body: {on: !bloqueada}});
      ESPACIO = {...(ESPACIO || {}), bloqueado: !bloqueada};
      closePop(); topbar(); toast(bloqueada ? 'El espacio quedó abierto.' : 'El espacio quedó bloqueado.');
    } catch (x) { busy(b, false); toast(x.message); }
  };
}

/* =====================================================================================
   Athena: el agente, en el panel de la derecha
   -------------------------------------------------------------------------------------
   Lee lo que el sistema ya tiene cargado y responde sobre eso. Cuando el servidor exponga
   el agente de verdad (POST {AGORA_API}athena), basta con cambiar `preguntar`.
   ===================================================================================== */
var athEl = null, athLog = [];
const ATH_SUG = ['¿Cómo vamos este mes?', '¿Quién tiene conversaciones sin leer?', '¿Cuánto llevamos gastado en anuncios?', '¿Qué convenios están por firmar?'];

function abrirAthena(pregunta) {
  if (athEl) { if (!pregunta) return cerrarAthena(); }
  if (!athEl) {
    athEl = document.createElement('div');
    athEl.className = 'ath';
    athEl.setAttribute('role', 'dialog');
    athEl.setAttribute('aria-label', 'Athena');
    athEl.innerHTML = `<div class="ath-h"><span class="mdm-ic" style="--c:var(--deep)">${icon('athena')}</span><div><b>Athena</b><small>Lee tus datos del sistema</small></div><button class="x" type="button" data-ath-close aria-label="Cerrar">${icon('plus')}</button></div>
      <div class="ath-log" id="ath-log"></div>
      <div class="ath-sug" id="ath-sug">${ATH_SUG.map(s => `<button class="btn btn-sm" type="button" data-ath-sug="${esc(s)}">${esc(s)}</button>`).join('')}</div>
      <form class="ath-f"><label class="sr-only" for="ath-in">Pregúntale a Athena</label><input id="ath-in" autocomplete="off" placeholder="Pregúntale sobre tus cifras…"><button class="btn btn-cta" type="submit" aria-label="Enviar">${icon('send')}</button></form>`;
    $('#layer').append(athEl);
    $('#b-ath')?.setAttribute('aria-expanded', 'true');
    athEl.querySelector('[data-ath-close]').onclick = cerrarAthena;
    athEl.querySelector('form').onsubmit = e => { e.preventDefault(); const i = athEl.querySelector('#ath-in'); const t = i.value.trim(); if (!t) return; i.value = ''; decir(t); };
    athEl.querySelectorAll('[data-ath-sug]').forEach(b => b.onclick = () => decir(b.dataset.athSug));
    if (!athLog.length) pintarAthena([{de: 'bot', html: `<p>Hola${ME?.nombre ? ', ' + esc(ME.nombre.split(' ')[0]) : ''}. Leo lo que el sistema tiene cargado y te lo resumo.</p><p>Pregúntame por el mes, por la bandeja, por los anuncios o por los convenios.</p>`}]);
    else pintarAthena();
  }
  if (pregunta) decir(pregunta);
  athEl.querySelector('#ath-in')?.focus({preventScroll: true});
}
function cerrarAthena() {
  if (!athEl) return;
  const e = athEl; athEl = null;
  $('#b-ath')?.setAttribute('aria-expanded', 'false');
  if (reduced()) e.remove(); else { e.classList.add('out'); setTimeout(() => e.remove(), 220); }
}
function pintarAthena(nuevos) {
  if (nuevos) athLog = athLog.concat(nuevos);
  const log = athEl?.querySelector('#ath-log'); if (!log) return;
  log.innerHTML = athLog.map(m => m.de === 'me' ? `<div class="msg me">${esc(m.texto)}</div>` : `<div class="msg bot">${m.html}</div>`).join('');
  log.scrollTop = log.scrollHeight;
}
function decir(texto) {
  pintarAthena([{de: 'me', texto}]);
  const log = athEl.querySelector('#ath-log');
  log.insertAdjacentHTML('beforeend', '<div class="msg bot typing" id="ath-typing"><i></i><i></i><i></i></div>');
  log.scrollTop = log.scrollHeight;
  setTimeout(() => {
    athEl?.querySelector('#ath-typing')?.remove();
    pintarAthena([{de: 'bot', html: responderAthena(texto)}]);
  }, 420);
}
/** La respuesta sale de lo que ya está cargado: nada se inventa ni sale a internet. */
function responderAthena(texto) {
  const q = norm(texto);
  const ir = (p, r) => `<div class="go"><a class="btn btn-sm btn-tint" href="${href(p)}" data-ath-go>${esc(r)}</a></div>`;
  if (/mes|vamos|resumen|negocio|mrr|ingreso/.test(q)) {
    const d = DATOS.resumen;
    if (!d) return `<p>Todavía no he leído el resumen del mes. Abre <b>Resumen</b> y vuelve a preguntarme.</p>${ir('/inicio', 'Abrir Resumen')}`;
    return `<p>En ${esc(mesNombre(PERIODO))} el ingreso recurrente va en <b>${esc(usd(d.mrr))}</b>, con ${int(d.clientesActivos)} cliente${d.clientesActivos === 1 ? '' : 's'} activo${d.clientesActivos === 1 ? '' : 's'}.</p>
      <ul><li>Recaudado: ${esc(usd(d.recaudado))}</li><li>Egresos: ${esc(usd(d.egresos))}</li><li>Saldo de caja: ${esc(usd(d.caja))}</li></ul>
      <p>${Number(d.caja) < 0 ? 'La caja está en negativo: los egresos van por encima de lo cobrado.' : 'La caja está en positivo.'}</p>${ir('/inicio', 'Ver el resumen')}`;
  }
  if (/sin leer|no leida|bandeja|conversacion|sla|respuesta/.test(q)) {
    const d = DATOS.dia;
    if (!d) return `<p>Abre <b>ARP Comercial</b> y vuelvo a mirar las cifras del día.</p>${ir('/comercial', 'Abrir ARP Comercial')}`;
    const peor = (d.sinLeerPorAsesor || []).slice().sort((a, b) => b.n - a.n)[0];
    return `<p>Hoy hay <b>${int(d.sinLeer)}</b> conversaciones sin leer y <b>${int(d.slaIncumplido)}</b> fuera del tiempo de respuesta.</p>
      ${peor ? `<p>Quien más acumula es ${esc(peor.nombre)}, con ${int(peor.n)}.</p>` : ''}
      <p>El tiempo de respuesta promedio va en ${esc(d.slaPromedio)}.</p>${ir('/bandeja', 'Ir a la bandeja')}`;
  }
  if (/anuncio|meta|ads|publicidad|gastado|invers/.test(q)) {
    const a = DATOS.ads;
    if (!a) return `<p>Abre <b>ARP Comercial</b> para que lea la inversión en anuncios.</p>${ir('/comercial', 'Abrir ARP Comercial')}`;
    if (a.estado !== 'ok') return `<p>La conexión con Meta está vencida, así que no puedo darte el gasto de hoy. Hay que volver a conectarla en Ajustes.</p>${ir('/ajustes', 'Ir a Ajustes')}`;
    return `<p>Hoy llevas <b>${esc(usd(a.dia))}</b> invertidos y <b>${esc(usd(a.mes))}</b> en lo que va de ${esc(mesNombre(PERIODO).toLowerCase())}.</p>
      <ul><li>Impresiones: ${int(a.impresiones)}</li><li>Coste por conversión: ${esc(usd(a.costePorConversion))}</li></ul>${ir('/comercial', 'Ver el detalle')}`;
  }
  if (/convenio|contrato|firmar|firmado/.test(q)) {
    const c = DATA.contratos;
    if (!c) return `<p>Abre <b>Contratos</b> y te digo cómo van.</p>${ir('/contratos', 'Abrir Contratos')}`;
    const porFirmar = c.filter(x => x.estado === 'ENVIADO').length, firmados = c.filter(x => x.estado === 'FIRMADO').length;
    return `<p>Hay <b>${int(porFirmar)}</b> convenios por firmar y ${int(firmados)} ya firmados, de ${int(c.length)} en total.</p>${ir('/contratos', 'Ver los convenios')}`;
  }
  if (/tarea|pendiente|recordatorio/.test(q)) {
    const t = (DATOS.tareas || []).filter(x => x.estado !== 'hecha');
    return `<p>Quedan <b>${int(t.length)}</b> tareas abiertas; ${int(t.filter(x => x.vence && x.vence < new Date().toISOString().slice(0, 10)).length)} están vencidas.</p>${ir('/tareas', 'Ver las tareas')}`;
  }
  return `<p>De eso todavía no tengo dato. Puedo con el resumen del mes, la bandeja y el tiempo de respuesta, la inversión en anuncios, los convenios y las tareas.</p>`;
}

/* =====================================================================================
   Puentes de eventos con los módulos de Ágora
   ===================================================================================== */
const AG_TO_MOD = {dashboard: 'comercial', inbox: 'bandeja', contacts: 'contactos', board: 'oportunidades', settings: 'conexiones', help: 'ayuda'};

window.addEventListener('agora:toast', e => toast(String(e.detail || '')));
window.addEventListener('agora:unread', e => { unread = Number(e.detail) || 0; const b = $('#b-crumb .nav-b'); if (b && R.mod === 'bandeja') b.textContent = int(unread); });
window.addEventListener('agora:won-alert', e => { wonPendientes = Number(e.detail?.count) || 0; });
window.addEventListener('agora:goto', e => {
  const d = e.detail || {};
  const mod = AG_TO_MOD[d.view];
  if (!mod || !MODS[mod]?.ok()) return;
  if (ws) ws.pendingFilter = d.filter || null;
  closeAll(); go(MODS[mod].path);
});
window.addEventListener('agora:open-conversation', e => {
  const c = e.detail;
  if (!c?.id || !ws) return;
  ws.pendingConversation = c;
  closeAll(); go('/bandeja');
});
window.addEventListener('agora:logout', () => { AGORA_ME = null; AGORA_CONN = []; unread = 0; if (ws) ws.reset(); });
/* Un recordatorio puesto desde un chat se convierte en tarea: la lista se refresca. */
window.addEventListener('agora:reminder', e => {
  const r = e.detail || {};
  DATOS.tareas = null;
  toast(`Recordatorio puesto para ${esc(r.cuando || 'la fecha elegida')}.`);
});

/* ---------- Controles propios del armazón ---------- */
document.addEventListener('change', e => { if (e.target?.id === 'sub-account') ws?.select(e.target.value); });
document.addEventListener('click', e => {
  const t = e.target;
  if (t?.closest?.('[data-agora-login]')) { closeAll(); agoraLoginModal(); return; }
  if (t?.closest?.('#b-crumb')) { moduleMenu(); return; }
  if (t?.closest?.('#b-hist')) { historialPop(); return; }
  if (t?.closest?.('#b-estado')) { estadoPop(); return; }
  if (t?.closest?.('#b-ath')) { closePop(); abrirAthena(); return; }
  if (t?.closest?.('[data-ath-go]')) { cerrarAthena(); return; }
  const mes = t?.closest?.('[data-mes]');
  if (mes) { ponerPeriodo(mes.dataset.mes); return; }
});

/* =====================================================================================
   Acceso a Ágora
   ===================================================================================== */
function agoraLoginForms() {
  return `<form class="form" data-form="ag-code" novalidate>
      <label class="fld">Correo del equipo<input name="email" type="email" autocomplete="username" placeholder="tu@correo.com"></label>
      <p class="hint">Te llega un código de seis cifras al correo con el que formas parte del equipo.</p>
      <p class="fld-err" role="alert"></p>
      <button class="btn btn-cta" type="submit">Recibir código</button>
    </form>
    <form class="form" data-form="ag-verify" hidden novalidate>
      <input type="hidden" name="email">
      <label class="fld">Código de 6 cifras<input name="code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6"></label>
      <p class="fld-err" role="alert"></p>
      <div class="form-ft" style="justify-content:flex-start"><button class="btn" type="button" data-ag-back>Cambiar de correo</button><button class="btn btn-cta" type="submit">Entrar</button></div>
    </form>
    <details class="ag-admin"><summary>Acceso de administración</summary>
      <form class="form" data-form="ag-admin" novalidate>
        <label class="fld">Correo<input name="email" type="email" autocomplete="username"></label>
        <label class="fld">Contraseña<input name="password" type="password" autocomplete="current-password"></label>
        <p class="fld-err" role="alert"></p>
        <button class="btn btn-cta" type="submit">Entrar como administrador</button>
      </form>
    </details>`;
}
function bindAgoraLogin(root, onDone) {
  const err = (f, m) => { const e = f.querySelector('.fld-err'); if (e) e.textContent = m; };
  const code = root.querySelector('[data-form="ag-code"]');
  const verify = root.querySelector('[data-form="ag-verify"]');
  const admin = root.querySelector('[data-form="ag-admin"]');
  if (code) code.onsubmit = async ev => {
    ev.preventDefault();
    const email = code.email.value.trim(), b = code.querySelector('[type=submit]');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return err(code, 'Escribe un correo válido.');
    busy(b, true, 'Enviando…'); err(code, '');
    try {
      await agoraApi('team-login/request', {method: 'POST', body: {email}});
      code.hidden = true; verify.hidden = false; verify.email.value = email;
      verify.querySelector('[name=code]').focus();
      toast('Código enviado. Revisa tu correo.');
    } catch (x) { err(code, x.message); } finally { busy(b, false); }
  };
  if (verify) {
    verify.onsubmit = async ev => {
      ev.preventDefault();
      const b = verify.querySelector('[type=submit]');
      busy(b, true, 'Entrando…'); err(verify, '');
      try { await agoraApi('team-login/verify', {method: 'POST', body: {email: verify.email.value, code: verify.code.value.trim()}}); await onDone(); }
      catch (x) { busy(b, false); err(verify, x.message); }
    };
    verify.querySelector('[data-ag-back]').onclick = () => { verify.hidden = true; code.hidden = false; err(verify, ''); };
  }
  if (admin) admin.onsubmit = async ev => {
    ev.preventDefault();
    const b = admin.querySelector('[type=submit]');
    busy(b, true, 'Entrando…'); err(admin, '');
    try { await agoraApi('login', {method: 'POST', body: {email: admin.email.value.trim(), password: admin.password.value}}); await onDone(); }
    catch (x) { busy(b, false); err(admin, x.message); }
  };
}
function agoraLoginModal() {
  const s = openModal(modalHead('Entrar en Ágora', 'Para ver el tablero, la bandeja, los contactos y las oportunidades.') + `<div class="ag-login">${agoraLoginForms()}</div><div class="form-ft"><button class="btn" type="button" data-close>Ahora no</button></div>`);
  bindAgoraLogin(s, async () => { closeModal(); await bootAgora(); toast('Sesión de Ágora abierta.'); render(); });
}

/* =====================================================================================
   La subcuenta en uso
   ===================================================================================== */
const agAccountViews = ['ag_dashboard', 'ag_inbox', 'ag_contacts', 'ag_board'];
function accountSwitch() {
  if (!agoraReady() || !AGORA_CONN.length || !agAccountViews.includes(R.view)) return '';
  const una = AGORA_CONN.length === 1;
  return `<label class="tb-acct ${una ? 'single' : ''}" title="Subcuenta en uso"><span>${una ? '' : 'Cuenta'}</span><select id="sub-account" aria-label="Subcuenta en uso" ${una ? 'disabled' : ''}>${AGORA_CONN.map(c => `<option value="${esc(c.id)}" ${String(c.id) === String(ws.current()) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>`;
}

/* =====================================================================================
   Arranque de la sesión de Ágora y de la identidad del espacio
   ===================================================================================== */
async function bootAgora() {
  if (!AG_READY) return;
  try { AGORA_ME = await agoraApi('me'); } catch { AGORA_ME = null; }
  if (!AGORA_ME) { AGORA_CONN = []; ws?.reset(); return; }
  ws.setProfile(AGORA_ME);
  try {
    const {items, reason} = await agoraApi('workspace/connections');
    AGORA_CONN = Array.isArray(items) ? items : [];
    AGORA_REASON = reason || null;
    ws.setConnections(AGORA_CONN, AGORA_REASON);
  } catch { AGORA_CONN = []; ws.setConnections([]); }
  try { AG.startWonAlert(); } catch { /* la alerta nunca estorba */ }
}
/** El nombre y el logo del cliente, que el SuperAdmin sube desde Usuarios y roles. */
async function bootEspacio() {
  try { ESPACIO = await agoraApi('workspace/branding'); }
  catch { ESPACIO = null; }
}
if (ws) ws.onChange(() => {
  try { AG.startWonAlert(); } catch { /* nada */ }
  if (agAccountViews.includes(R.view)) render(); else topbar();
});
