# Cómo se arma el paquete

- `agora/` — los módulos que venían de Ágora 1.10.0, con tres cambios y ninguno más:
  la base de la API sale de `window.AGORA_API`; `maintenance.js` se envuelve en
  `installMaintenance()` para poder apagarla; y los dos parches de `parches-agora.py`.
  `arp-extra.js` es nuevo: los bloques de operación del día, anuncios y eficacia.
- `parches-agora.py` — los dos cambios a los módulos heredados: el tablero suma sus
  bloques nuevos y la bandeja suma los recordatorios de seguimiento.
- `entry.js` — reúne esos módulos y los publica en `window.Agora`, para empaquetar.
- `parches.py` — toma el `panel.js` original del panel de Contratos y sustituye el
  armazón por rangos de línea (comprueba antes que el archivo de partida es el
  esperado). Al final injerta `shell-v2.js` y `modulos-nuevos.js`.
- `shell-v2.js` — la barra, el menú de módulos, el periodo, el historial, el estado del
  espacio, Athena y el puente con los módulos heredados.
- `modulos-nuevos.js` — Resumen, Tareas, Auditoría y Usuarios y roles.
- `prueba.py` — mete todo en un solo archivo con datos de prueba: `prueba.html`.
- `verificar.js` / `interactuar.js` — recorren el resultado en un navegador real.
- `servir.js` — sirve `public_html/` en el puerto 8099 para probarlo sin empotrar nada.
- `API.md` — **lo que el servidor tiene que responder.** Empieza por ahí.

`parches.py` necesita el `panel.js` del paquete original en la ruta que indica arriba.
