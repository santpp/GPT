"use strict";
/* =====================================================================================
   Agora Digital App
   -------------------------------------------------------------------------------------
   Un solo sistema para toda la operación comercial:

     Operación       Resumen · ARP Comercial · Bandeja de conversaciones · Contactos ·
                     Oportunidades · Tareas
     Contratos       Contratos · Con convenio · Registro
     Administración  Auditoría · Usuarios y roles · Ajustes · Ayuda

   La barra de arriba lleva la marca, el módulo en uso con su menú, el periodo, los
   accesos a Inicio, Ajustes y Auditoría, el estado del espacio, el historial y Athena.

   Cada módulo habla con la API de su sistema; las dos bases se configuran en
   assets/config.js. Go High Level entra por el servidor, no desde aquí.
   ===================================================================================== */
(() => {
const IC = {"home": "<path d=\"M3 11l9-7 9 7\"/><path d=\"M5 10v10h14V10\"/>", "trend": "<path d=\"M3 17l6-6 4 4 8-8\"/><path d=\"M15 7h6v6\"/>", "receipt": "<path d=\"M6 3h12v18l-3-2-3 2-3-2-3 2z\"/><path d=\"M9 8h6M9 12h6\"/>", "invoice": "<path d=\"M7 3h7l5 5v13H7z\"/><path d=\"M14 3v5h5\"/><path d=\"M10 13h6M10 17h4\"/>", "pie": "<path d=\"M12 3v9h9\"/><path d=\"M20.5 15A9 9 0 1 1 9 3.5\"/>", "wallet": "<rect x=\"3\" y=\"6\" width=\"18\" height=\"13\" rx=\"2.5\"/><path d=\"M16 12.5h2\"/><path d=\"M3 9h18\"/>", "users": "<circle cx=\"9\" cy=\"8\" r=\"3.5\"/><path d=\"M2.5 20a6.5 6.5 0 0 1 13 0\"/><path d=\"M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6\"/>", "calendar": "<rect x=\"3\" y=\"5\" width=\"18\" height=\"16\" rx=\"2.5\"/><path d=\"M3 10h18M8 3v4M16 3v4\"/>", "pause": "<rect x=\"6\" y=\"5\" width=\"4\" height=\"14\" rx=\"1\"/><rect x=\"14\" y=\"5\" width=\"4\" height=\"14\" rx=\"1\"/>", "rocket": "<path d=\"M5 15c-1.5 1.5-2 4-2 6 2 0 4.5-.5 6-2\"/><path d=\"M9 15l-3-3 9-9c2 0 4 .5 6 2 0 2-.5 4-2 6z\"/><circle cx=\"15\" cy=\"9\" r=\"1.5\"/>", "team": "<circle cx=\"12\" cy=\"7\" r=\"3\"/><path d=\"M6 21v-1a6 6 0 0 1 12 0v1\"/>", "check": "<rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"4\"/><path d=\"M8 12.5l3 3 5-6\"/>", "gear": "<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1\"/>", "info": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 11v6M12 7.5v.01\"/>", "upload": "<path d=\"M12 16V4M7 9l5-5 5 5\"/><path d=\"M4 16v4h16v-4\"/>", "lock": "<rect x=\"5\" y=\"11\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 11V8a4 4 0 0 1 8 0v3\"/>", "unlock": "<rect x=\"5\" y=\"11\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 11V8a4 4 0 0 1 7.5-2\"/>", "sync": "<path d=\"M20 11a8 8 0 0 0-14.5-4.5L4 8\"/><path d=\"M4 4v4h4\"/><path d=\"M4 13a8 8 0 0 0 14.5 4.5L20 16\"/><path d=\"M20 20v-4h-4\"/>", "edit": "<path d=\"M4 20h4L19 9l-4-4L4 16z\"/>", "download": "<path d=\"M12 4v11M7 10l5 5 5-5\"/><path d=\"M4 18v2h16v-2\"/>", "coins": "<ellipse cx=\"9\" cy=\"6.5\" rx=\"6\" ry=\"2.5\"/><path d=\"M3 6.5v4c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5v-4\"/><path d=\"M9 17c-3.3 0-6-1.1-6-2.5v-4\"/><path d=\"M15 11.5c3.3 0 6 1.1 6 2.5v4c0 1.4-2.7 2.5-6 2.5s-6-1.1-6-2.5v-4c0-1.4 2.7-2.5 6-2.5z\"/>", "shield": "<path d=\"M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z\"/><path d=\"M8.5 12l2.5 2.5 4.5-5\"/>", "chev": "<path d=\"M6 9l6 6 6-6\"/>", "plus": "<path d=\"M12 5v14M5 12h14\"/>", "split": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 3v9l6.4 6.4\"/><path d=\"M12 12H3\"/>", "spark": "<path d=\"M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z\"/><path d=\"M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z\"/>", "history": "<path d=\"M3.5 12a8.5 8.5 0 1 0 2.6-6.1\"/><path d=\"M3 4.5v4.5h4.5\"/><path d=\"M12 7.5V12l3 2\"/>", "agenda": "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"16.5\" rx=\"3.5\"/><path d=\"M3 9.5h18M8 2.5v4M16 2.5v4\"/><path d=\"M7.5 13.5h2M11 13.5h2M14.5 13.5h2M7.5 17h2M11 17h2\"/>", "pulse": "<path d=\"M3 12h4l2.2-5.5L13.5 18l2.2-6H21\"/>", "clock": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 7.5V12l3 2\"/>", "pin": "<path d=\"M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z\"/><circle cx=\"12\" cy=\"10\" r=\"2.4\"/>", "chevL": "<path d=\"M15 6l-6 6 6 6\"/>", "chevR": "<path d=\"M9 6l6 6-6 6\"/>", "chat": "<path d=\"M4 18.5V6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7a2.5 2.5 0 0 1-2.5 2.5H8z\"/><path d=\"M8.5 9.5h7M8.5 12.5h4\"/>", "mail": "<rect x=\"3\" y=\"5\" width=\"18\" height=\"14\" rx=\"2.5\"/><path d=\"M3.5 7l8.5 6 8.5-6\"/>", "phone": "<path d=\"M5 4h3.5l1.5 4.2-2.2 1.4a11 11 0 0 0 6.6 6.6l1.4-2.2L20 15.5V19a1.5 1.5 0 0 1-1.6 1.5C10.6 20 4 13.4 3.5 5.6A1.5 1.5 0 0 1 5 4z\"/>", "video": "<rect x=\"3\" y=\"6\" width=\"13\" height=\"12\" rx=\"2.5\"/><path d=\"M16 10.5l5-3v9l-5-3\"/>", "warn": "<path d=\"M12 3.5l9.5 16.5h-19z\"/><path d=\"M12 10v4.5M12 17.5v.01\"/>", "search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"M20 20l-4.2-4.2\"/>", "sidebar": "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"15\" rx=\"3\"/><path d=\"M9.5 4.5v15\"/><path d=\"M5.5 8h1.8M5.5 11h1.8\"/>", "bell": "<path d=\"M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 1.5h-15z\"/><path d=\"M10 20.5a2 2 0 0 0 4 0\"/>", "keyboard": "<rect x=\"2.5\" y=\"6\" width=\"19\" height=\"12\" rx=\"2.5\"/><path d=\"M6 9.5h.01M9 9.5h.01M12 9.5h.01M15 9.5h.01M18 9.5h.01M6.5 14.5h11\"/>", "hand": "<path d=\"M8 12V6.5a1.5 1.5 0 0 1 3 0V11\"/><path d=\"M11 10.5V5a1.5 1.5 0 0 1 3 0v6\"/><path d=\"M14 10.5V6.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-.5a6 6 0 0 1-5-2.7L3 15.5a1.6 1.6 0 0 1 2.6-1.8L8 16\"/>", "scribble": "<path d=\"M4 17c2.5-6 4.5-9 6-9 2 0-1.5 8 .5 8 1.6 0 3-4 4.5-4s.5 3 2 3 2-1 3-2\"/><path d=\"M15.5 4.5l3 3L10 16l-3.5.5.5-3.5z\" opacity=\".0\"/>", "sun": "<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4\"/>", "moon": "<path d=\"M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z\"/>", "auto": "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M12 3.5v17a8.5 8.5 0 0 0 0-17z\" fill=\"currentColor\" stroke=\"none\"/>", "mic": "<rect x=\"9\" y=\"3\" width=\"6\" height=\"11\" rx=\"3\"/><path d=\"M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21\"/>", "send": "<path d=\"M4 12l16-8-6 16-2.5-6.5z\"/><path d=\"M11.5 13.5L20 4\"/>", "more": "<circle cx=\"5.5\" cy=\"12\" r=\"1.3\"/><circle cx=\"12\" cy=\"12\" r=\"1.3\"/><circle cx=\"18.5\" cy=\"12\" r=\"1.3\"/>", "logout": "<path d=\"M15 4h4v16h-4\"/><path d=\"M10 17l5-5-5-5\"/><path d=\"M15 12H3\"/>", "user": "<circle cx=\"12\" cy=\"8\" r=\"4\"/><path d=\"M4.5 20.5a7.5 7.5 0 0 1 15 0\"/>", "refresh": "<path d=\"M20 11a8 8 0 0 0-14.5-4.5L4 8\"/><path d=\"M4 4v4h4\"/><path d=\"M4 13a8 8 0 0 0 14.5 4.5L20 16\"/><path d=\"M20 20v-4h-4\"/>", "install": "<rect x=\"6\" y=\"2.5\" width=\"12\" height=\"19\" rx=\"3\"/><path d=\"M12 8v6M9.5 11.5L12 14l2.5-2.5\"/><path d=\"M10.5 18.5h3\"/>", "palette": "<path d=\"M12 3.5a8.5 8.5 0 0 0 0 17c1.2 0 1.8-.8 1.8-1.7 0-1.2-1-1.6-1-2.6 0-1 .8-1.7 1.8-1.7H17a3.5 3.5 0 0 0 3.5-3.5c0-4.2-3.8-7.5-8.5-7.5z\"/><circle cx=\"7.5\" cy=\"11\" r=\"1.1\"/><circle cx=\"10\" cy=\"7.5\" r=\"1.1\"/><circle cx=\"14.5\" cy=\"7.5\" r=\"1.1\"/>", "rate": "<path d=\"M4 7h13l-3-3M20 17H7l3 3\"/>", "athena": "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M8.5 13.5c1 1.4 2.2 2 3.5 2s2.5-.6 3.5-2\"/><path d=\"M9 9.5v.5M15 9.5v.5\"/>"};
const LOGO = "<svg viewBox=\"443 415 2381 1004\" width=\"62\" height=\"26\" role=\"img\" aria-label=\"\u00c1gora\"><path fill=\"var(--iso)\" fill-rule=\"evenodd\" d=\"M839.0 1412.9C806.6 1411.0 767.3 1403.2 735.5 1392.5C656.8 1366.1 589.6 1318.7 537.4 1252.9C517.2 1227.4 490.2 1181.4 481.5 1157.5C480.5 1154.8 479.4 1152.0 479.0 1151.5C477.1 1148.7 467.6 1120.3 463.5 1105.5C462.6 1102.2 461.5 1098.2 461.0 1096.5C459.0 1089.3 454.4 1064.8 452.9 1053.5C452.3 1048.5 451.3 1041.6 450.8 1038.0C449.3 1028.0 448.5 830.1 450.0 811.0C451.1 794.9 453.3 776.1 455.0 767.5C457.1 756.4 459.4 746.0 461.7 737.0C463.1 731.8 464.5 725.9 464.9 724.0C465.9 719.8 474.8 693.7 477.9 686.2C479.0 683.4 481.0 678.6 482.1 675.8C489.0 658.7 511.3 617.7 519.1 607.9C520.7 605.9 522.0 604.0 522.0 603.7C522.0 603.4 524.5 599.7 527.5 595.4C559.6 550.8 603.0 510.6 650.2 482.1C663.1 474.3 694.4 457.9 700.8 455.6C705.2 454.0 722.6 447.2 725.5 445.9C731.2 443.4 763.4 433.9 772.2 432.1C774.6 431.6 781.0 430.3 786.5 429.2C812.7 423.8 836.1 421.6 867.0 421.6C892.6 421.5 913.7 422.7 927.7 425.1C944.0 427.8 956.8 430.1 960.0 431.0C961.9 431.5 967.5 432.9 972.5 434.1C991.5 438.7 1019.7 448.2 1033.5 454.5C1035.2 455.3 1039.0 457.0 1042.0 458.3C1053.8 463.5 1058.0 465.6 1072.0 473.3C1131.5 506.0 1183.7 554.4 1220.1 610.5C1234.5 632.6 1239.0 640.9 1251.3 667.1C1258.0 681.4 1269.0 711.0 1271.9 722.5C1272.5 724.7 1273.6 729.2 1274.5 732.5C1278.0 745.3 1282.4 767.1 1284.4 782.0C1287.7 806.4 1288.1 819.6 1288.0 917.5C1287.9 1028.1 1287.5 1038.0 1281.0 1074.9C1277.1 1097.4 1265.4 1136.0 1256.9 1154.8C1255.3 1158.3 1254.0 1161.4 1254.0 1161.6C1254.0 1162.5 1249.9 1171.3 1243.8 1183.5C1217.4 1236.4 1179.0 1283.8 1131.8 1321.9C1124.0 1328.1 1105.3 1341.8 1100.8 1344.5C1099.9 1345.0 1093.0 1349.3 1085.5 1353.9C1074.3 1360.7 1043.4 1377.0 1041.6 1377.0C1041.4 1377.0 1038.3 1378.3 1034.8 1379.9C1027.7 1383.1 1012.3 1389.2 1007.0 1390.9C1005.1 1391.5 1000.1 1393.1 996.0 1394.4C948.8 1409.8 893.9 1416.2 839.0 1412.9ZM916.0 1336.1C964.0 1328.4 997.2 1317.4 1035.4 1296.5C1104.9 1258.7 1161.2 1194.8 1190.3 1120.8C1198.3 1100.7 1201.0 1091.9 1205.9 1070.0C1214.2 1032.8 1214.5 1026.8 1214.5 917.5C1214.5 827.4 1213.9 805.2 1211.0 791.0C1210.5 788.5 1209.3 782.2 1208.4 777.0C1205.5 760.5 1197.4 730.6 1193.0 720.5C1192.5 719.4 1189.6 712.5 1186.5 705.1C1167.6 659.9 1136.0 616.5 1096.7 581.5C1064.0 552.4 1018.6 526.5 975.5 512.6C956.4 506.4 945.7 503.9 923.5 500.1C887.3 494.0 838.5 494.8 802.0 502.2C755.0 511.6 710.4 530.4 672.5 556.8C639.4 579.8 605.5 613.7 583.5 645.6C560.0 679.8 541.5 721.6 532.1 761.5C528.9 775.4 528.1 779.3 526.9 787.5C526.3 791.9 525.4 798.6 524.8 802.5C523.3 813.3 522.6 995.6 524.0 1017.5C526.3 1053.8 532.8 1083.7 545.7 1117.5C549.9 1128.5 549.5 1127.7 557.1 1143.5C583.3 1198.7 627.5 1249.1 679.1 1282.6C696.7 1294.1 715.5 1304.2 731.5 1311.0C737.0 1313.3 742.4 1315.6 743.5 1316.1C762.4 1324.3 800.9 1333.8 828.0 1337.0C843.1 1338.7 845.0 1338.8 875.0 1338.5C897.6 1338.2 906.1 1337.7 916.0 1336.1ZM831.7 1259.3C831.3 1259.0 831.0 1220.0 831.0 1172.8C831.0 1096.9 830.8 1087.0 829.5 1087.0C828.0 1087.0 813.9 1100.9 738.8 1175.8L706.0 1208.5L680.0 1182.5C665.7 1168.2 654.0 1156.1 654.0 1155.5C654.0 1154.9 681.2 1127.2 714.5 1094.0C749.1 1059.5 774.8 1033.0 774.6 1032.3C774.2 1031.3 756.5 1031.0 687.8 1030.8L601.5 1030.5L601.5 993.5L601.5 956.5L868.8 956.2L1136.0 956.0L1136.0 993.5L1136.0 1031.0L1049.5 1031.0C967.1 1031.0 963.0 1031.1 963.0 1032.8C963.0 1033.8 988.5 1059.9 1023.5 1094.7C1056.8 1127.8 1084.0 1155.3 1084.0 1155.7C1084.0 1156.7 1032.3 1208.0 1031.2 1208.0C1030.8 1208.0 1003.3 1180.8 970.0 1147.5C936.2 1113.7 908.7 1087.0 907.8 1087.0C906.1 1087.0 906.0 1091.9 905.8 1173.2L905.5 1259.5L868.9 1259.8C848.8 1259.9 832.1 1259.7 831.7 1259.3ZM601.2 840.8L601.5 803.5L687.0 803.3C734.0 803.1 773.1 803.0 773.8 803.0C774.4 803.0 775.0 802.4 775.0 801.6C775.0 800.9 747.8 773.1 714.5 739.9C681.2 706.7 654.0 679.1 654.0 678.5C654.0 678.0 665.7 665.8 680.0 651.5L706.0 625.5L713.2 632.7C799.1 718.0 829.5 747.8 830.2 747.4C830.6 747.1 831.0 708.1 831.0 660.7C831.1 600.0 831.4 575.0 832.1 576.3C832.9 577.7 833.5 577.9 834.6 576.9C835.3 576.3 835.7 575.4 835.4 574.9C835.1 574.3 849.4 574.1 870.2 574.2L905.5 574.5L905.8 660.5C905.9 716.6 906.4 746.8 907.0 747.4C907.7 748.1 928.1 728.4 969.4 687.1L1030.8 625.7L1033.9 628.3C1039.1 632.6 1083.0 676.4 1083.0 677.2C1083.0 677.6 1082.3 677.7 1081.5 677.4C1080.5 677.0 1080.0 677.4 1080.0 678.5C1080.0 679.6 1080.5 680.0 1081.5 679.6C1082.3 679.3 1083.0 679.2 1083.0 679.3C1083.0 679.5 1056.0 706.6 1023.0 739.5C988.8 773.7 963.0 800.2 963.0 801.2C963.0 802.2 963.6 803.0 964.2 803.0C964.9 803.0 1003.8 803.1 1050.5 803.3L1135.5 803.5L1135.7 839.5C1135.8 859.3 1135.6 874.9 1135.3 874.2C1134.7 872.6 1133.0 873.6 1133.0 875.7C1133.0 876.7 1133.6 877.0 1134.6 876.6C1135.4 876.3 1135.8 876.4 1135.5 877.0C1135.1 877.7 1042.8 878.0 867.9 878.0L601.0 878.0L601.2 840.8Z\"/><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M1801.0 1271.6L1801.0 1243.1L1864.8 1242.8L1928.5 1242.5L1932.9 1240.0C1941.6 1235.2 1941.5 1235.8 1941.8 1192.1C1942.1 1150.4 1942.1 1149.8 1936.9 1159.5C1934.0 1165.0 1927.1 1171.5 1921.3 1174.4C1919.2 1175.4 1916.8 1176.6 1915.9 1177.0C1915.0 1177.5 1911.2 1178.7 1907.4 1179.7C1901.5 1181.2 1896.6 1181.5 1875.0 1181.5C1858.4 1181.4 1846.9 1181.0 1842.0 1180.1C1812.4 1174.9 1796.6 1160.6 1789.3 1132.5C1787.6 1125.9 1787.5 1117.8 1787.5 992.5L1787.5 859.5L1789.8 851.0C1795.0 832.0 1804.4 819.5 1819.3 812.2C1833.7 805.0 1843.1 803.7 1878.3 804.3C1905.6 804.7 1906.7 804.7 1913.4 807.2C1925.2 811.7 1934.0 819.1 1937.6 827.5C1938.4 829.4 1939.7 831.0 1940.5 831.0C1941.7 831.0 1942.0 828.6 1942.2 817.8L1942.5 804.5L1979.0 804.5L2015.5 804.5L2015.5 1021.5C2015.5 1203.1 2015.3 1239.8 2014.1 1246.5C2009.4 1273.3 1995.9 1288.7 1970.0 1296.8C1961.4 1299.5 1947.1 1300.0 1875.3 1300.0L1801.0 1300.0L1801.0 1271.6ZM1444.0 1185.5C1443.5 1185.0 1443.6 1182.5 1444.1 1180.0C1444.6 1177.5 1445.4 1172.8 1445.9 1169.5C1446.4 1166.2 1447.2 1161.0 1447.8 1158.0C1448.9 1152.4 1451.4 1138.4 1452.5 1132.0C1452.8 1130.1 1454.0 1123.3 1455.1 1117.0C1456.2 1110.7 1457.8 1101.9 1458.5 1097.5C1460.2 1087.6 1462.4 1075.3 1464.5 1063.5C1467.9 1044.9 1469.2 1037.3 1470.0 1031.1C1470.5 1027.6 1471.2 1024.0 1471.5 1023.1C1471.7 1022.2 1473.3 1013.6 1475.0 1004.0C1476.6 994.4 1478.6 982.7 1479.5 978.0C1481.5 967.1 1483.9 953.1 1485.1 945.5C1485.6 942.2 1486.4 937.5 1487.0 935.0C1488.2 928.9 1492.5 905.0 1498.5 869.5C1499.4 864.5 1500.7 856.9 1501.5 852.5C1505.0 833.1 1507.8 816.9 1509.0 809.0C1509.6 805.4 1510.3 801.8 1510.6 800.8C1510.8 799.9 1511.7 795.2 1512.5 790.3C1513.2 785.5 1515.0 775.0 1516.5 767.0C1520.9 742.2 1523.1 729.7 1524.1 723.0C1524.6 719.4 1525.3 715.9 1525.5 715.1C1525.8 714.4 1526.7 709.6 1527.5 704.6C1528.3 699.6 1529.6 691.9 1530.4 687.5C1533.4 671.0 1535.1 661.3 1535.9 656.3C1536.3 653.4 1536.9 650.8 1537.1 650.5C1537.4 650.3 1562.1 650.0 1592.0 650.0C1640.0 649.9 1646.4 650.0 1647.2 651.4C1647.7 652.3 1649.2 658.9 1650.5 666.2C1651.9 673.5 1653.7 682.9 1654.5 687.0C1655.3 691.1 1657.3 701.9 1659.0 711.0C1660.6 720.1 1662.6 730.6 1663.4 734.5C1664.2 738.4 1666.2 749.1 1668.0 758.5C1669.7 767.9 1671.7 778.6 1672.5 782.5C1673.2 786.4 1674.6 793.5 1675.5 798.5C1676.4 803.5 1677.7 810.6 1678.5 814.5C1679.2 818.4 1680.6 825.5 1681.5 830.5C1682.4 835.5 1683.8 842.6 1684.5 846.5C1685.2 850.4 1686.6 857.5 1687.5 862.5C1688.4 867.5 1689.8 874.6 1690.5 878.5C1691.2 882.4 1692.6 889.5 1693.5 894.5C1694.4 899.5 1695.8 906.6 1696.5 910.5C1697.3 914.4 1699.3 924.9 1700.9 934.0C1702.6 943.1 1704.7 953.9 1705.4 958.0C1706.2 962.1 1707.6 969.5 1708.5 974.5C1709.4 979.5 1710.8 986.6 1711.5 990.5C1712.3 994.4 1713.6 1001.5 1714.5 1006.5C1715.4 1011.5 1716.8 1018.6 1717.5 1022.5C1718.3 1026.3 1719.6 1033.5 1720.5 1038.5C1721.4 1043.5 1722.6 1049.5 1723.2 1052.0C1723.7 1054.5 1724.6 1058.8 1725.0 1061.5C1726.0 1067.9 1730.5 1092.4 1732.4 1101.5C1734.0 1109.1 1736.0 1120.2 1738.6 1134.5C1739.4 1139.5 1740.8 1146.4 1741.5 1150.0C1742.3 1153.6 1743.6 1160.5 1744.5 1165.5C1745.4 1170.5 1746.6 1176.9 1747.2 1179.8C1747.8 1182.6 1748.1 1185.3 1747.8 1185.6C1747.5 1185.9 1730.5 1186.1 1710.0 1186.1C1669.5 1186.2 1671.1 1186.4 1671.0 1180.5C1671.0 1178.8 1670.5 1175.6 1670.0 1173.3C1669.4 1170.9 1668.6 1166.2 1668.0 1162.8C1667.5 1159.3 1666.4 1152.2 1665.5 1147.0C1664.6 1141.8 1663.3 1133.7 1662.5 1129.0C1661.8 1124.3 1660.9 1119.8 1660.6 1119.0C1660.3 1118.2 1659.6 1114.1 1659.0 1110.0C1658.5 1105.9 1657.1 1097.5 1656.0 1091.5C1654.9 1085.5 1653.5 1077.1 1652.9 1073.0C1651.1 1060.7 1658.1 1062.0 1593.9 1062.0C1550.0 1062.0 1537.8 1062.3 1537.5 1063.2C1537.2 1063.9 1536.3 1069.5 1535.5 1075.5C1534.6 1081.5 1533.2 1090.8 1532.4 1096.0C1531.6 1101.2 1530.7 1107.1 1530.4 1109.0C1529.9 1112.5 1528.2 1123.3 1525.5 1140.5C1524.7 1145.5 1523.4 1153.8 1522.6 1159.0C1519.2 1181.0 1518.7 1183.8 1518.1 1184.9C1517.1 1186.4 1445.2 1187.0 1444.0 1185.5ZM2399.9 1185.8C2398.0 1185.1 2398.0 1182.4 2398.2 994.8L2398.5 804.5L2435.0 804.5L2471.5 804.5L2472.0 826.3C2472.3 838.7 2472.9 848.1 2473.5 848.3C2474.0 848.4 2475.1 846.5 2476.0 844.0C2480.1 832.5 2492.0 818.3 2503.1 811.7C2513.7 805.4 2521.0 803.7 2537.9 803.6L2552.5 803.5L2552.8 834.8C2552.9 851.9 2552.7 866.0 2552.3 866.0C2508.0 866.7 2512.3 866.3 2502.7 870.0C2491.3 874.3 2483.5 881.5 2478.5 892.4C2471.7 907.3 2472.0 899.4 2472.0 1049.4C2472.0 1135.8 2471.6 1185.1 2471.0 1185.5C2469.6 1186.4 2402.2 1186.6 2399.9 1185.8ZM2667.0 1186.0C2642.2 1185.3 2641.3 1185.2 2632.5 1182.2C2627.6 1180.5 2621.5 1178.0 2619.0 1176.6C2608.8 1170.9 2598.7 1158.3 2594.6 1145.9C2590.0 1132.3 2590.0 1133.2 2590.0 995.5C2590.0 861.5 2590.1 858.6 2594.0 846.5C2598.9 830.9 2609.4 818.3 2622.4 812.0C2637.2 805.0 2640.4 804.5 2676.0 804.5C2710.0 804.5 2711.3 804.7 2722.5 810.1C2729.9 813.7 2736.2 819.6 2740.2 826.7C2741.9 829.7 2743.6 831.8 2744.1 831.3C2744.6 830.8 2745.1 824.6 2745.2 817.5L2745.5 804.5L2782.0 804.5L2818.5 804.5L2818.7 994.0C2818.9 1098.2 2818.6 1184.1 2818.1 1184.8C2817.5 1185.8 2809.8 1186.1 2782.1 1186.1C2762.8 1186.1 2746.5 1185.8 2746.0 1185.5C2745.4 1185.1 2745.0 1179.3 2745.0 1172.0C2745.0 1164.8 2744.6 1158.9 2744.0 1158.5C2743.5 1158.2 2741.9 1160.2 2740.5 1163.0C2734.3 1175.2 2721.1 1183.2 2703.2 1185.6C2697.3 1186.3 2692.5 1186.9 2692.5 1186.8C2692.5 1186.7 2681.0 1186.3 2667.0 1186.0ZM2142.5 1185.0C2116.6 1181.7 2098.7 1168.1 2091.0 1145.5C2086.2 1131.4 2086.0 1125.0 2086.0 995.5C2086.0 852.5 2085.9 853.7 2095.3 835.0C2102.3 820.9 2115.0 811.7 2134.8 806.2C2143.6 803.8 2259.5 803.2 2272.5 805.5C2294.3 809.3 2310.1 819.6 2317.7 835.0C2327.0 853.9 2327.0 853.8 2327.0 996.0C2326.9 1123.7 2326.7 1131.1 2322.0 1145.0C2314.1 1168.5 2296.8 1181.7 2269.5 1184.9C2259.3 1186.1 2152.1 1186.2 2142.5 1185.0ZM2245.7 1125.7C2254.2 1120.3 2253.5 1131.9 2253.5 995.0L2253.5 873.5L2251.1 869.3C2249.8 867.0 2248.0 864.8 2247.1 864.4C2240.4 861.7 2233.1 861.1 2205.9 861.0C2170.3 861.0 2165.8 861.9 2161.1 870.5C2159.6 873.2 2159.5 884.0 2159.5 995.0L2159.5 1116.5L2161.8 1120.3C2164.7 1124.9 2168.9 1127.2 2176.0 1128.1C2179.0 1128.5 2195.0 1128.7 2211.5 1128.6L2241.5 1128.4L2245.7 1125.7ZM2728.9 1125.4C2736.1 1123.3 2741.2 1118.5 2743.3 1111.7C2744.9 1106.8 2745.0 1097.1 2745.0 994.8C2745.0 873.5 2745.2 878.9 2739.5 871.4C2738.2 869.7 2734.9 867.1 2732.3 865.9C2727.6 863.6 2726.8 863.5 2701.5 863.5C2677.1 863.5 2675.3 863.6 2672.0 865.6C2666.3 868.9 2664.3 872.9 2663.5 882.3C2663.2 886.8 2663.0 940.7 2663.2 1002.0L2663.5 1113.5L2665.7 1117.6C2670.1 1125.9 2673.7 1126.8 2701.6 1126.9C2718.8 1127.0 2724.8 1126.7 2728.9 1125.4ZM1926.6 1120.4C1932.5 1118.0 1936.8 1114.3 1939.3 1109.7L1941.5 1105.5L1941.5 992.5L1941.5 879.5L1939.2 875.4C1936.4 870.4 1933.7 867.8 1928.5 865.4C1924.9 863.7 1921.8 863.5 1898.3 863.5L1872.2 863.5L1867.9 866.5C1864.6 868.9 1863.3 870.7 1861.8 875.0C1860.1 880.2 1860.0 885.7 1860.2 994.0L1860.5 1107.5L1863.0 1112.5C1864.9 1116.4 1866.5 1118.0 1870.0 1119.7C1874.3 1121.8 1875.8 1121.9 1898.6 1122.0C1918.5 1122.0 1923.4 1121.7 1926.6 1120.4ZM1639.4 999.1C1640.0 998.3 1637.5 979.5 1636.5 976.8C1636.2 976.1 1635.6 972.6 1635.0 969.0C1634.5 965.4 1633.4 958.2 1632.5 953.0C1631.6 947.8 1630.3 939.7 1629.5 935.0C1628.7 930.3 1627.1 921.1 1626.0 914.5C1624.8 907.9 1623.0 897.1 1621.9 890.5C1618.9 871.7 1617.0 860.9 1616.0 856.0C1615.5 853.5 1614.8 849.7 1614.5 847.5C1613.8 843.0 1611.6 829.4 1609.5 817.5C1608.7 813.1 1607.4 805.0 1606.5 799.5C1605.7 794.0 1604.5 787.5 1604.0 785.0C1603.4 782.5 1602.6 777.6 1602.0 774.0C1601.5 770.4 1600.4 763.7 1599.6 759.0C1598.8 754.3 1597.2 744.6 1596.0 737.5C1592.9 718.4 1590.8 715.1 1589.5 727.2C1589.2 730.7 1588.5 735.8 1588.0 738.5C1587.5 741.2 1586.3 748.2 1585.5 754.0C1584.6 759.8 1583.4 767.2 1582.9 770.5C1580.9 782.6 1578.9 795.7 1578.0 802.5C1577.5 806.4 1576.6 812.2 1576.0 815.5C1575.5 818.8 1574.4 825.9 1573.5 831.2C1572.7 836.6 1571.3 845.2 1570.5 850.2C1569.7 855.3 1568.5 862.6 1568.0 866.5C1567.4 870.4 1566.3 877.5 1565.4 882.5C1564.6 887.5 1563.5 895.1 1563.0 899.5C1562.4 903.9 1561.5 909.5 1561.0 912.0C1560.5 914.5 1559.4 921.5 1558.5 927.5C1557.6 933.5 1556.3 942.3 1555.5 947.0C1554.7 951.7 1553.4 960.2 1552.5 966.0C1551.7 971.8 1550.2 981.0 1549.3 986.6C1548.4 992.1 1547.9 997.4 1548.3 998.3C1548.9 999.9 1552.8 1000.0 1593.9 1000.0C1619.1 1000.0 1639.1 999.6 1639.4 999.1ZM1561.7 608.3C1561.4 607.8 1564.1 603.0 1567.5 597.5C1571.0 592.0 1577.7 581.2 1582.5 573.5C1587.2 565.8 1595.8 551.9 1601.7 542.5C1607.5 533.1 1616.0 519.3 1620.7 511.8L1629.1 498.0L1671.2 498.0C1694.3 498.0 1713.0 498.4 1712.8 498.8C1712.4 499.7 1706.3 507.5 1660.0 565.4L1625.4 608.5L1593.8 608.8C1576.4 608.9 1561.9 608.7 1561.7 608.3Z\"/></svg>";
const $ = s => document.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const norm = s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${IC[n] || ''}</svg>`;
const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get: (k, d) => { try { const v = localStorage.getItem('agora_' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem('agora_' + k, JSON.stringify(v)); } catch { /* modo privado */ } },
};
const IS_MAC = /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent);
const MODK = IS_MAC ? '⌘' : 'Ctrl';

/* ---------- Formatos ---------- */
const NF = new Intl.NumberFormat('es-VE', {minimumFractionDigits: 2, maximumFractionDigits: 2});
const NI = new Intl.NumberFormat('es-VE', {maximumFractionDigits: 0});
const num = s => { const n = Number(String(s ?? '').replace(',', '.')); return isFinite(n) ? n : 0; };
const money = s => s == null || s === '' ? '—' : '$' + NF.format(num(s));
const int = n => n == null ? '—' : NI.format(n);
const pct = x => x == null || !isFinite(x) ? '—' : NI.format(Math.round(x * 100)) + ' %';
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const cap = t => t.charAt(0).toUpperCase() + t.slice(1);
/* El servidor guarda la hora en UTC («2026-11-02 14:10:00»); se muestra en la hora del equipo. */
const utc = s => s ? new Date(String(s).replace(' ', 'T') + (/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? '' : 'Z')) : null;
const fday = ymd => { if (!ymd) return '—'; const [y, m, d] = String(ymd).slice(0, 10).split('-').map(Number); return `${d} ${MESES[m - 1].slice(0, 3)} ${y}`; };
const fstamp = s => { const d = utc(s); return d && !isNaN(d) ? d.toLocaleString('es-VE', {day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'}) : '—'; };
const fdate = s => { const d = utc(s); return d && !isNaN(d) ? d.toLocaleDateString('es-VE', {day: 'numeric', month: 'short', year: 'numeric'}) : '—'; };
const when = s => {
  const d = utc(s); if (!d || isNaN(d)) return '—';
  const sec = (Date.now() - d) / 1000;
  if (sec < 60) return 'hace un momento'; if (sec < 3600) return `hace ${Math.round(sec / 60)} min`; if (sec < 86400) return `hace ${Math.round(sec / 3600)} h`;
  if (sec < 86400 * 7) return `hace ${Math.round(sec / 86400)} d`;
  return fdate(s);
};
const initials = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(p => p[0]).join('').toUpperCase();

/* ---------- Roles (espejo de Seguridad/Roles.php) ---------- */
const PERMISOS = {ADMIN: ['ver', 'editar', 'enviar', 'revocar', 'usuarios'], REMITENTE: ['ver', 'editar', 'enviar', 'revocar'], VISOR: ['ver']};
const ROLES = {
  ADMIN: {l: 'Administración', d: 'Todo, incluidas las personas y el registro. Ve todos los convenios.'},
  REMITENTE: {l: 'Remitente', d: 'Crea, edita, envía y revoca los convenios que tiene asignados.'},
  VISOR: {l: 'Consulta', d: 'Solo consulta los convenios que tiene asignados.'},
};
let ME = null;
const can = p => !!ME && (PERMISOS[ME.rol] || []).includes(p);

const ESTADO = {
  BORRADOR: {l: 'Borrador', c: 'sc-gray', plural: 'Borradores'},
  ENVIADO: {l: 'Enviado', c: 'sc-info', plural: 'Enviados'},
  FIRMADO: {l: 'Firmado', c: 'sc-ok', plural: 'Firmados'},
  REVOCADA: {l: 'Revocado', c: 'sc-bad', plural: 'Revocados'},
};
const chip = e => { const m = ESTADO[e] || {l: e, c: 'sc-gray'}; return `<span class="sc ${m.c}">${esc(m.l)}</span>`; };
const EVENTOS = {CREADO: 'Convenio creado', ENVIADO: 'Convenio enviado', FIRMADO: 'Convenio firmado', REVOCADO: 'Enlace revocado', ENLACE_NUEVO: 'Enlace de firma nuevo', NUEVA_VERSION: 'Nueva versión', CLIENTE_EDITADO: 'Datos del cliente corregidos', ENLACES_REVOCADOS: 'Enlaces anteriores anulados'};

/* =====================================================================================
   Las dos APIs
   -------------------------------------------------------------------------------------
   Cada sistema conserva sus rutas. Las bases salen de assets/config.js, así el mismo
   paquete sirve si los dos viven en el mismo dominio o en dominios distintos.
   ===================================================================================== */
const CONTRATOS_API = (window.CONTRATOS_API || '/api/');
const AGORA_API = (window.AGORA_API || '/api/');

/* ---------- API de Contratos (las mismas rutas de siempre) ---------- */
async function api(path, {method = 'GET', body} = {}) {
  let r;
  try {
    r = await fetch(CONTRATOS_API + path, {method, credentials: 'same-origin', cache: 'no-store', headers: body !== undefined ? {'Content-Type': 'application/json'} : {}, body: body !== undefined ? JSON.stringify(body) : undefined});
  } catch {
    throw new Error(navigator.onLine ? 'No se pudo conectar con el servidor. Inténtalo de nuevo.' : 'Sin conexión. Revisa tu internet.');
  }
  let d = {}; try { d = await r.json(); } catch { /* respuesta vacía */ }
  // Si caduca la sesión de Contratos pero sigue abierta la de Ágora, no se echa a nadie.
  if (r.status === 401 && path !== 'login' && path !== 'yo') {
    ME = null; DATA.reset();
    if (AGORA_ME) { toast('Tu sesión de Contratos se cerró. Vuelve a entrar desde tu cuenta.'); go(homePath(), {replace: true}); }
    else go('/entrar', {replace: true});
  }
  if (!r.ok) throw Object.assign(new Error(d.error || `No se pudo completar (código ${r.status}).`), {status: r.status});
  return d;
}

/* ---------- Datos en memoria ---------- */
const DATA = {
  contratos: null, detalle: {}, usuarios: null, eventos: null,
  reset() { this.contratos = null; this.detalle = {}; this.usuarios = null; this.eventos = null; },
};
const loadContratos = async (force) => { if (force || !DATA.contratos) DATA.contratos = (await api('contratos')).contratos || []; return DATA.contratos; };
const loadDetalle = async (uid, force) => { if (force || !DATA.detalle[uid]) DATA.detalle[uid] = await api('contratos/' + uid); return DATA.detalle[uid]; };
const loadUsuarios = async (force) => { if (force || !DATA.usuarios) DATA.usuarios = (await api('usuarios')).usuarios || []; return DATA.usuarios; };
const loadEventos = async (force) => { if (force || !DATA.eventos) DATA.eventos = (await api('registro')).eventos || []; return DATA.eventos; };
/* Personas con convenio: los contratos agrupados por correo */
function clientes() {
  const by = new Map();
  for (const c of DATA.contratos || []) {
    const k = norm(c.correo) || norm(c.cliente);
    const g = by.get(k) || {k, nombre: c.cliente, correo: c.correo, total: 0, n: {BORRADOR: 0, ENVIADO: 0, FIRMADO: 0, REVOCADA: 0}, ultimo: '', estado: '', uid: '', lista: []};
    g.total++; g.n[c.estado] = (g.n[c.estado] || 0) + 1; g.lista.push(c);
    if (!g.ultimo || String(c.creado_en) > g.ultimo) { g.ultimo = String(c.creado_en); g.estado = c.estado; g.nombre = c.cliente; g.uid = c.uid; }
    by.set(k, g);
  }
  return [...by.values()].sort((a, b) => b.ultimo.localeCompare(a.ultimo));
}
const convPorCorreo = correo => (DATA.contratos || []).filter(c => correo && norm(c.correo) === norm(correo));

/* =====================================================================================
   Rutas: /contratos, /contratos/nuevo, /contratos/:uid, /contactos, /usuarios, /registro, /entrar
   En un archivo abierto desde el disco se usa #/ruta (no hay servidor que atienda las rutas).
   ===================================================================================== */
const HASH = location.protocol === 'file:' || window.__CONTRATOS_HASH === true;
const path = () => (HASH ? location.hash.slice(1) : location.pathname).replace(/\/+$/, '') || '/';
const href = p => (HASH ? '#' : '') + p;
function go(p, {replace} = {}) {
  if (HASH) { if (replace) history.replaceState(null, '', location.pathname + location.search + '#' + p); else location.hash = p; if (replace) render(true); return; }
  if (replace) history.replaceState(null, '', p); else history.pushState(null, '', p);
  render(true);
}
window.addEventListener(HASH ? 'hashchange' : 'popstate', () => render(true));
document.addEventListener('click', e => {
  const a = e.target.closest('a[href]');
  if (!a || a.target || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
  const h = a.getAttribute('href');
  if (HASH ? h.startsWith('#/') : (h.startsWith('/') && !h.startsWith('/api/'))) { e.preventDefault(); closeAll(); go(HASH ? h.slice(1) : h); }
});

/* =====================================================================================
   Los módulos, en tres grupos
   -------------------------------------------------------------------------------------
   Las direcciones de Ágora siguen valiendo (/bandeja, /contactos, /oportunidades,
   /conversations/{id}); /tablero y /conexiones quedan como alias de las nuevas.
   ===================================================================================== */
const GRUPOS = {
  operacion: {name: 'Operación'},
  contratos: {name: 'Contratos'},
  administracion: {name: 'Administración'},
};
const MODS = {
  inicio: {g: 'operacion', view: 'inicio', name: 'Resumen', icon: 'home', path: '/inicio', c: 'var(--brand)', periodo: true,
    desc: 'El pulso del negocio: ingreso, resultado y caja.', ok: () => esSuperAdmin()},
  comercial: {g: 'operacion', view: 'ag_dashboard', ag: 'dashboard', name: 'ARP Comercial', icon: 'pie', path: '/comercial', c: 'var(--mod-vino)',
    desc: 'Las cifras del día, los anuncios y la rentabilidad.', ok: () => agoraReady()},
  bandeja: {g: 'operacion', view: 'ag_inbox', ag: 'inbox', name: 'Bandeja de conversaciones', icon: 'chat', path: '/bandeja', c: 'var(--mod-azul)',
    desc: 'Todos los canales en una sola lista.', ok: () => agoraReady(), n: () => unread || null},
  contactos: {g: 'operacion', view: 'ag_contacts', ag: 'contacts', name: 'Contactos', icon: 'users', path: '/contactos', c: 'var(--mod-azul)',
    desc: 'Las fichas de la subcuenta y su historial.', ok: () => agoraReady()},
  oportunidades: {g: 'operacion', view: 'ag_board', ag: 'board', name: 'Oportunidades', icon: 'trend', path: '/oportunidades', c: 'var(--mod-oro)',
    desc: 'Los embudos por etapa y las ventas ganadas.', ok: () => agoraReady(), n: () => wonPendientes || null},
  tareas: {g: 'operacion', view: 'tareas', name: 'Tareas', icon: 'check', path: '/tareas', c: 'var(--ok-solid)',
    desc: 'Lo que cada ejecutivo tiene pendiente hoy.', ok: () => !!ME || agoraReady(), n: () => tareasPendientes()},
  convenios: {g: 'contratos', view: 'contratos', name: 'Contratos', icon: 'invoice', path: '/contratos', c: 'var(--mod-oro)',
    desc: 'Convenios de pago: estado, firma y documentos.', ok: () => can('ver'), n: () => DATA.contratos?.length},
  conConvenio: {g: 'contratos', view: 'contactos', name: 'Con convenio', icon: 'user', path: '/con-convenio', c: 'var(--mod-oro)',
    desc: 'Personas con convenio y búsqueda en la cartera.', ok: () => can('ver'), n: () => DATA.contratos ? clientes().length : null},
  registro: {g: 'contratos', view: 'registro', name: 'Registro', icon: 'history', path: '/registro', c: 'var(--mod-oro)',
    desc: 'Todo lo que pasa con los convenios, con su hora.', ok: () => can('usuarios')},
  auditoria: {g: 'administracion', view: 'auditoria', name: 'Auditoría', icon: 'shield', path: '/auditoria', c: 'var(--mod-seguridad)', periodo: true,
    desc: 'Quién tocó qué contacto, cuándo y desde dónde.', ok: () => puedeAuditar()},
  usuarios: {g: 'administracion', view: 'usuarios', name: 'Usuarios y roles', icon: 'team', path: '/usuarios', c: 'var(--mod-seguridad)',
    desc: 'Quién entra, con qué rol y la identidad del espacio.', ok: () => esAdmin()},
  conexiones: {g: 'administracion', view: 'ag_settings', ag: 'settings', name: 'Ajustes', icon: 'gear', path: '/ajustes', c: 'var(--mod-seguridad)',
    desc: 'Cuentas conectadas, equipo importado y avisos.', ok: () => agoraAdmin()},
  ayuda: {g: 'administracion', view: 'ag_help', ag: 'help', name: 'Ayuda', icon: 'info', path: '/ayuda', c: 'var(--mod-azul)',
    desc: 'El manual de uso del sistema.', ok: () => agoraReady() || !!ME},
};
/** Los módulos a los que llega quien entró, en el orden de los grupos. */
const ALL = () => Object.keys(MODS).filter(k => MODS[k].ok());
const homeMod = () => ALL()[0] || null;
const homePath = () => { const m = homeMod(); return m ? MODS[m].path : '/entrar'; };
const homeRoute = () => { const m = homeMod() || 'convenios'; return {view: MODS[m].view, mod: m}; };
/** La clave de filtro de cada vista, para las tarjetas que filtran al pulsarlas. */
const FKEY = {contratos: 'estado', tareas: 'estado', usuarios: 'rol'};

function route() {
  const p = path();
  if (p === '/entrar') return {view: 'entrar'};
  for (const id of Object.keys(MODS)) if (p === MODS[id].path) return {view: MODS[id].view, mod: id};
  if (p === '/tablero') return {view: 'ag_dashboard', mod: 'comercial'};
  if (p === '/conexiones') return {view: 'ag_settings', mod: 'conexiones'};
  if (p === '/contratos/nuevo') return {view: 'nuevo', mod: 'convenios'};
  let m = p.match(/^\/contratos\/([a-f0-9]{24})$/); if (m) return {view: 'detalle', mod: 'convenios', uid: m[1]};
  m = p.match(/^\/conversations\/([A-Za-z0-9_-]{1,80})$/);
  if (m) return {view: 'ag_inbox', mod: 'bandeja', conversation: m[1]};
  if (p === '/') return homeRoute();
  return {...homeRoute(), unknown: true};
}

/* =====================================================================================
   Componentes (los del v3)
   ===================================================================================== */
const head = (eyebrow, title, lede = '', acts = '') => `<div class="mod-h"><div><p class="t-label">${eyebrow}</p><h1 class="t-module">${title}</h1>${lede ? `<p class="lede">${lede}</p>` : ''}</div>${acts ? `<div class="acts">${acts}</div>` : ''}</div>`;
const panel = (title, sub, body, extra = '', cls = '') => `<section class="panel ${cls}"><div class="panel-h"><div><h2 class="t-panel">${title}</h2>${sub ? `<p>${sub}</p>` : ''}</div>${extra}</div>${body}</section>`;
const metric = (l, v, f = '', {filter, on, cls = ''} = {}) => filter !== undefined
  ? `<button type="button" class="micro ${on ? 'is-on' : ''} ${cls}" data-filter="${esc(filter)}" aria-pressed="${!!on}"><h3>${l}</h3><p class="t-metric" style="margin:0">${v}</p>${f ? `<span class="f">${f}</span>` : ''}</button>`
  : `<div class="micro ${cls}"><h3>${l}</h3><p class="t-metric" style="margin:0">${v}</p>${f ? `<span class="f">${f}</span>` : ''}</div>`;
function seg(key, options, value, label, cls = '') {
  return `<div class="seg ${cls}" role="radiogroup" aria-label="${esc(label)}" data-seg="${key}"><span class="seg-thumb"></span>${options.map(([v, l, n]) => `<button type="button" class="seg-b ${String(v) === String(value) ? 'is-on' : ''}" role="radio" aria-checked="${String(v) === String(value)}" data-v="${esc(v)}">${l}${n != null ? ` <span class="n">${int(n)}</span>` : ''}</button>`).join('')}</div>`;
}
function placeThumbs(root = document, animate = false) {
  $$('.seg', root).forEach(s => {
    const on = s.querySelector('.seg-b.is-on'), th = s.querySelector('.seg-thumb'); if (!th) return;
    if (!on || !on.offsetWidth) { th.style.opacity = 0; return; }
    if (!animate) th.style.transition = 'none';
    th.style.opacity = 1; th.style.width = on.offsetWidth + 'px'; th.style.transform = `translateX(${on.offsetLeft}px)`;
    if (!animate) { void th.offsetWidth; th.style.transition = ''; }
  });
}
function table(cols, rows, {sortKey, sortDir, rowHref, empty, foot} = {}) {
  const th = cols.map(c => `<th class="${c.n ? 'n' : ''}" ${c.sort ? `aria-sort="${sortKey === c.k ? (sortDir > 0 ? 'ascending' : 'descending') : 'none'}"` : ''}>${c.sort ? `<button type="button" data-sort="${c.k}">${esc(c.l)}${sortKey === c.k ? (sortDir > 0 ? ' ↑' : ' ↓') : ''}</button>` : esc(c.l)}</th>`).join('');
  const body = rows.length ? rows.map(r => `<tr${rowHref ? ` data-href="${esc(rowHref(r))}" tabindex="0"` : ''}>${cols.map(c => `<td class="${c.n ? 'n' : ''} ${c.cls || ''}">${c.f ? c.f(r[c.k], r) : esc(r[c.k] ?? '—')}</td>`).join('')}</tr>`).join('')
    : `<tr><td colspan="${cols.length}" class="empty">${empty || '<b>No hay registros con estos filtros</b>Prueba con otra búsqueda o quita los filtros.<br><button class="btn btn-sm" type="button" data-clear>Quitar filtros</button>'}</td></tr>`;
  return `<div class="tw full"><table><thead><tr>${th}</tr></thead><tbody>${body}</tbody>${foot || ''}</table></div>`;
}
function sortRows(rows, st) { if (!st.sk) return rows; const k = st.sk, d = st.sd; return [...rows].sort((a, b) => { const x = a[k] ?? '', y = b[k] ?? ''; return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'es')) * d; }); }
function pager(st, total, per) { const pages = Math.max(1, Math.ceil(total / per)); st.p = Math.min(st.p, pages - 1); return pages < 2 ? `<div class="pager"><span>${int(total)} registro${total === 1 ? '' : 's'}</span></div>` : `<div class="pager"><span>${int(total)} registros · página ${st.p + 1} de ${pages}</span><div><button class="btn btn-sm" data-page="-1" ${st.p ? '' : 'disabled'}>Anterior</button><button class="btn btn-sm" data-page="1" ${st.p >= pages - 1 ? 'disabled' : ''}>Siguiente</button></div></div>`; }
const searchFld = (val, ph, key = 'q') => `<label class="fld grow">Buscar<span class="search-in">${icon('search')}<input type="search" data-f="${key}" value="${esc(val)}" placeholder="${esc(ph)}" autocomplete="off" enterkeyhint="search"></span></label>`;
const loading = (title = '') => `${title ? head(title, '<span class="sk w40" style="height:30px"></span>') : ''}<div class="grid g4">${'<div class="micro"><span class="sk w60"></span><span class="sk big"></span></div>'.repeat(4)}</div><div class="panel mt"><span class="sk w40"></span><span class="sk w80"></span><span class="sk w60"></span><span class="sk w80"></span></div>`;
const failed = (msg) => `<div class="panel"><p class="empty"><b>No se pudo cargar</b>${esc(msg)}<br><button class="btn btn-sm" type="button" data-retry>Intentar de nuevo</button></p></div>`;
const noAccess = () => `<div class="panel"><p class="empty"><b>Este módulo no está a tu alcance</b>${agoraReady() || ME ? 'Pídele a quien administra que revise tu rol.' : 'Entra en el sistema que lo gobierna.'}<br><a class="btn btn-sm" href="${href(homePath())}">Ir al inicio</a></p></div>`;
const kv = pairs => `<dl class="kv">${pairs.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;

/* =====================================================================================
   Armazón: barra superior con los módulos, pestañas en celular y pie
   ===================================================================================== */
let R = route(), GEN = 0;
const V = {};
function render(focus) {
  closeTip?.();
  R = route();
  const root = document.documentElement;
  if (!ME && !AGORA_ME) { root.classList.add('is-auth'); return V.entrar.render(); }
  if (R.view === 'entrar') { go(homePath(), {replace: true}); return; }
  root.classList.remove('is-auth'); $('#lg')?.remove();
  // Un enlace a una conversación concreta: la bandeja la abre al cargar.
  if (R.conversation && ws) {
    ws.pendingConversation = {id: R.conversation, explicit: false};
    history.replaceState(null, '', HASH ? location.pathname + '#/bandeja' : '/bandeja');
    R = {view: 'ag_inbox', mod: 'bandeja'};
  }
  if (R.unknown) history.replaceState(null, '', HASH ? location.pathname + '#' + homePath() : homePath());
  topbar();
  const gen = ++GEN;
  const v = V[R.view];
  if (!v) { paint(failed('Esta pantalla no existe.')); return; }
  if (R.mod && !MODS[R.mod].ok()) { paint(noAccess()); return; }
  paint(v.render(), true);
  if (v.need) {
    v.need().then(() => { if (gen === GEN) { topbar(); paint(v.render()); } })
      .catch(err => { if (gen === GEN) { v.error = err.message; paint(v.render()); v.error = ''; } });
  }
  anotarHistorial();
  document.title = `${R.view === 'nuevo' ? 'Nuevo convenio' : MODS[R.mod]?.name || 'Inicio'} · Agora Digital App`;
  if (focus) $('#app').focus({preventScroll: true});
  if (focus) scrollTo({top: 0});
}
function paint(html, enter) {
  const app = $('#app');
  // Si lo que había era un módulo de Ágora, se suelta antes de reemplazarlo: así para
  // sus relojes, sus consultas en vivo y sus escuchas, como hacía en su propia cáscara.
  disposeAgora();
  // En la barra no cabe el periodo cuando la pantalla es estrecha: baja al lienzo.
  const per = MODS[R.mod]?.periodo ? `<div class="per-m">${periodBar()}</div>` : '';
  app.innerHTML = `${per}<div class="${enter ? 'view-enter' : ''}">${html}</div>`;
  placeThumbs(document);
  V[R.view]?.mounted?.(app);
}
const repaint = () => { if (V[R.view]) { topbar(); paint(V[R.view].render()); } };
window.addEventListener('resize', () => placeThumbs(document));

/* ---------- Capas: menús, hojas, avisos (las del v3) ---------- */
let pop = null, popAnchor = null, modal = null, lastFocus = null, toastT = 0;
function closePop() { if (!pop) return; const p = pop; pop = null; popAnchor?.setAttribute('aria-expanded', 'false'); popAnchor = null; if (reduced()) p.remove(); else { p.classList.add('out'); setTimeout(() => p.remove(), 180); } }
function openPop(anchor, html, cls, {align = 'left'} = {}) {
  const same = popAnchor && popAnchor === anchor; closePop(); if (same) return null;
  const el = document.createElement('div'); el.className = 'pop ' + cls; el.innerHTML = html; $('#layer').append(el);
  const r = anchor.getBoundingClientRect(), w = el.offsetWidth, h = el.offsetHeight;
  let left = align === 'right' ? r.right - w : r.left; left = Math.max(12, Math.min(innerWidth - w - 12, left));
  let top = r.bottom + 8; if (top + h > innerHeight - 12) top = Math.max(12, r.top - h - 8);
  el.style.left = left + 'px'; el.style.top = top + 'px'; el.style.setProperty('--ox', Math.max(16, (r.left + r.width / 2) - left) + 'px');
  pop = el; popAnchor = anchor; anchor.setAttribute('aria-expanded', 'true');
  return el;
}
function openModal(html, {cls = 'modal', wide} = {}) {
  closeModal(true); closePop(); lastFocus = document.activeElement;
  const s = document.createElement('div'); s.className = 'scrim';
  s.innerHTML = `<div class="${cls} ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  $('#layer').append(s); modal = s; placeThumbs(s);
  (s.querySelector('[autofocus]') || s.querySelector('input, select, button:not(.x), a'))?.focus({preventScroll: true});
  return s;
}
function closeModal(instant) { if (!modal) return; const m = modal; modal = null; if (instant || reduced()) m.remove(); else { m.classList.add('out'); setTimeout(() => m.remove(), 160); } if (!instant) lastFocus?.focus?.({preventScroll: true}); }
const modalHead = (t, sub = '') => `<div class="modal-h"><div><h2>${t}</h2>${sub ? `<p>${sub}</p>` : ''}</div><button class="x" type="button" data-close aria-label="Cerrar">${icon('plus')}</button></div>`;
function closeAll() { closePop(); closeModal(); }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2800); }
const busy = (btn, on, label) => { if (!btn) return; if (on) { btn.dataset.l = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin" aria-hidden="true"></span>${esc(label || 'Un momento…')}`; } else { btn.disabled = false; if (btn.dataset.l) btn.innerHTML = btn.dataset.l; } };
function confirmModal(title, text, label, fn, danger) {
  const s = openModal(modalHead(esc(title)) + `<p style="margin:0">${text}</p><p class="fld-err" role="alert"></p><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn ${danger ? 'btn-danger' : 'btn-cta'}" type="button" data-ok>${esc(label)}</button></div>`);
  s.querySelector('[data-ok]').onclick = async e => {
    const b = e.currentTarget; busy(b, true);
    try { await fn(); closeModal(); } catch (x) { busy(b, false); s.querySelector('.fld-err').textContent = x.message; }
  };
}
async function copy(text, msg = 'Copiado') {
  try { await navigator.clipboard.writeText(text); toast(msg); }
  catch { const t = document.createElement('textarea'); t.value = text; document.body.append(t); t.select(); try { document.execCommand('copy'); toast(msg); } catch { toast('Selecciona el texto y cópialo a mano.'); } t.remove(); }
}

/* ---------- Tooltip para métricas que lo usan ---------- */
const tipEl = () => $('#tip');
function closeTip() { tipEl()?.classList.remove('on'); }

/* =====================================================================================
   Vistas
   ===================================================================================== */
const state = {
  contratos: {q: '', estado: '', p: 0, sk: 'creado_en', sd: -1},
  contactos: {tab: 'clientes', q: '', p: 0, sk: 'ultimo', sd: -1, consulta: '', resultados: null, aviso: '', buscando: false, error: ''},
  nuevo: null,
  detalle: {verPdf: false},
  personas: {q: '', p: 0},
  registro: {q: '', tipo: '', p: 0},
  tareas: {q: '', estado: 'abiertas', resp: '', p: 0, sk: 'vence', sd: 1},
  auditoria: {q: '', modulo: '', actor: '', p: 0},
  usuarios: {q: '', rol: '', p: 0},
};
const PER = 25;

/* ---------- Contratos ---------- */
V.contratos = {
  need: () => DATA.contratos ? Promise.resolve() : loadContratos(),
  render() {
    if (this.error) return head('Convenios de pago', 'Contratos') + failed(this.error);
    if (!DATA.contratos) return loading('Convenios de pago');
    const st = state.contratos, all = DATA.contratos;
    const n = e => all.filter(c => c.estado === e).length;
    const enviados = n('ENVIADO') + n('FIRMADO') + n('REVOCADA');
    const mes = new Date().toISOString().slice(0, 7);
    const firmMes = all.filter(c => c.estado === 'FIRMADO' && String(c.creado_en).slice(0, 7) === mes).length;
    const q = norm(st.q);
    let rows = all.filter(c => (!st.estado || c.estado === st.estado) && (!q || norm(c.cliente + ' ' + c.correo).includes(q)));
    rows = sortRows(rows, st);
    const page = rows.slice(st.p * PER, st.p * PER + PER);
    const acts = can('editar') ? `<a class="btn btn-cta" href="${href('/contratos/nuevo')}">${icon('plus')}Nuevo convenio</a>` : '';
    const lede = ME.rol === 'ADMIN' ? 'Todos los convenios de la subcuenta, del más reciente al más antiguo.' : 'Ves solo los convenios que tienes asignados.';
    if (!all.length) return head('Convenios de pago', 'Contratos', lede, acts) + panel('Aún no hay contratos', '', `<p class="empty"><b>Todavía no hay convenios</b>${can('editar') ? 'Crea el primero con «Nuevo convenio» y elige un contacto de AGORA.' : 'Cuando te asignen uno, aparecerá aquí.'}${can('editar') ? `<br><a class="btn btn-cta" href="${href('/contratos/nuevo')}">${icon('plus')}Nuevo convenio</a>` : ''}</p>`);
    const cols = [
      {k: 'cliente', l: 'Cliente', sort: 1, f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(r.correo)}</small></span>`},
      {k: 'estado', l: 'Estado', sort: 1, f: v => chip(v)},
      {k: 'version', l: 'Versión', n: 1, sort: 1, f: v => int(v)},
      {k: 'creado_en', l: 'Creado', sort: 1, f: v => `<span title="${esc(fstamp(v))}">${esc(fdate(v))}</span>`},
      {k: 'uid', l: '', cls: 'act', f: () => icon('chevR')},
    ];
    return head('Convenios de pago', 'Contratos', lede, acts)
      + `<div class="grid g4">
        ${metric('Todos', int(all.length), `${int(clientes().length)} cliente${clientes().length === 1 ? '' : 's'}`, {filter: '', on: !st.estado})}
        ${metric('Por firmar', int(n('ENVIADO')), 'Enviados, con el enlace del cliente', {filter: 'ENVIADO', on: st.estado === 'ENVIADO'})}
        ${metric('Firmados', int(n('FIRMADO')), `${pct(enviados ? n('FIRMADO') / enviados : null)} de lo enviado · ${int(firmMes)} de este mes`, {filter: 'FIRMADO', on: st.estado === 'FIRMADO'})}
        ${metric('Borradores', int(n('BORRADOR')), n('REVOCADA') ? `${int(n('REVOCADA'))} revocado${n('REVOCADA') === 1 ? '' : 's'}` : 'Sin enviar todavía', {filter: 'BORRADOR', on: st.estado === 'BORRADOR'})}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Nombre o correo del cliente')}
          ${seg('estado', [['', 'Todos', all.length], ...Object.keys(ESTADO).map(e => [e, ESTADO[e].plural, n(e)])], st.estado, 'Filtrar por estado')}
          ${st.q || st.estado ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        <div id="region">${table(cols, page, {sortKey: st.sk, sortDir: st.sd, rowHref: r => '/contratos/' + r.uid, empty: '<b>Ningún contrato coincide con la búsqueda o el filtro</b>Prueba con otro nombre o quita los filtros.<br><button class="btn btn-sm" type="button" data-clear>Quitar filtros</button>'})}${pager(st, rows.length, PER)}</div></section>`;
  },
};

/* ---------- Contactos (nuevo) ---------- */
V.contactos = {
  need: () => DATA.contratos ? Promise.resolve() : loadContratos(),
  render() {
    const st = state.contactos, puedeBuscar = can('editar');
    if (!puedeBuscar && st.tab === 'agora') st.tab = 'clientes';
    const lede = 'Las personas con convenio y los contactos de AGORA. Desde aquí abres sus convenios o creas uno nuevo.';
    const tabs = puedeBuscar ? `<div class="mb">${seg('ctab', [['clientes', 'Con convenio'], ['agora', 'Buscar en AGORA']], st.tab, 'Vista de contactos')}</div>` : '';
    if (this.error) return head('Directorio', 'Contactos', lede) + failed(this.error);
    if (!DATA.contratos) return loading('Directorio');
    return head('Directorio', 'Contactos', lede) + tabs + (st.tab === 'agora' ? this.agora() : this.clientes());
  },
  clientes() {
    const st = state.contactos, list = clientes(), q = norm(st.q);
    const firm = list.filter(c => c.n.FIRMADO).length, pend = list.filter(c => c.n.ENVIADO).length, solo = list.filter(c => c.total === c.n.BORRADOR).length;
    let rows = list.filter(c => !q || norm(c.nombre + ' ' + c.correo).includes(q)).map(c => ({...c, firmados: c.n.FIRMADO, pendientes: c.n.ENVIADO}));
    rows = sortRows(rows, st);
    const page = rows.slice(st.p * PER, st.p * PER + PER);
    const cols = [
      {k: 'nombre', l: 'Cliente', sort: 1, f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(r.correo)}</small></span>`},
      {k: 'total', l: 'Convenios', n: 1, sort: 1, f: int},
      {k: 'firmados', l: 'Firmados', n: 1, sort: 1, f: int},
      {k: 'pendientes', l: 'Por firmar', n: 1, sort: 1, f: v => v ? `<b class="strong">${int(v)}</b>` : '0'},
      {k: 'estado', l: 'Último estado', f: v => chip(v)},
      {k: 'ultimo', l: 'Último convenio', sort: 1, f: v => `<span title="${esc(fstamp(v))}">${esc(when(v))}</span>`},
      {k: 'k', l: '', cls: 'act', f: (v, r) => `<button class="btn btn-sm" type="button" data-ficha="${esc(r.k)}">${icon('user')}<span>Ficha</span></button>${can('editar') ? `<button class="btn btn-sm btn-tint" type="button" data-nuevo-correo="${esc(r.correo)}" data-nuevo-nombre="${esc(r.nombre)}">${icon('plus')}<span>Convenio</span></button>` : ''}`},
    ];
    if (!list.length) return panel('Personas con convenio', '', `<p class="empty"><b>Todavía no hay personas con convenio</b>${can('editar') ? `Busca un contacto en AGORA y crea su primer convenio.<br><button class="btn btn-cta" type="button" data-tab="agora">${icon('search')}Buscar en AGORA</button>` : ''}</p>`);
    return `<div class="grid g4">
        ${metric('Personas con convenio', int(list.length), `${int((DATA.contratos || []).length)} convenios en total`)}
        ${metric('Con convenio firmado', int(firm), pct(list.length ? firm / list.length : null) + ' de las personas')}
        ${metric('Con firma pendiente', int(pend), 'Tienen un enlace por firmar')}
        ${metric('Solo borradores', int(solo), 'Aún no se les envía nada')}
      </div>
      <section class="panel mt"><div class="tools">${searchFld(st.q, 'Nombre o correo')}${st.q ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
      <div id="region">${table(cols, page, {sortKey: st.sk, sortDir: st.sd, empty: '<b>Nadie coincide con la búsqueda</b>Prueba con otro nombre o correo.<br><button class="btn btn-sm" type="button" data-clear>Quitar filtros</button>'})}${pager(st, rows.length, PER)}</div>
      <p class="src">Sale de tus convenios${ME.rol === 'ADMIN' ? '' : ' asignados'}, agrupados por correo. Para ver a alguien sin convenio, búscalo en AGORA.</p></section>`;
  },
  agora() {
    const st = state.contactos, res = st.resultados;
    const cols = [
      {k: 'nombre', l: 'Nombre', f: (v, r) => `<span class="who-cell"><b>${esc(v || 'Sin nombre')}</b><small>${esc(r.correo || 'Sin correo')}</small></span>`},
      {k: 'telefono', l: 'Teléfono', f: v => v ? esc(v) : '<span class="muted">—</span>'},
      {k: 'cedula', l: 'Cédula', f: v => v ? esc(v) : '<span class="muted">Sin cédula</span>'},
      {k: 'correo', l: 'Convenios', n: 1, f: v => { const n = convPorCorreo(v).length; return n ? `<button class="lnk-btn" type="button" data-ver-correo="${esc(v)}">${int(n)}</button>` : '0'; }},
      {k: 'id', l: '', cls: 'act', f: (v, r) => `<button class="btn btn-sm btn-cta" type="button" data-crear="${esc(v)}">${icon('plus')}<span>Crear convenio</span></button>`},
    ];
    let body = '';
    if (st.error) body = `<div class="note-gold">${esc(st.error)}</div>`;
    else if (st.buscando) body = `<div style="margin-top:14px"><span class="sk w80"></span><span class="sk w60"></span><span class="sk w80"></span></div>`;
    else if (res) body = (st.aviso ? `<div class="note-gold">${esc(st.aviso)}</div>` : '') + (res.length || !st.aviso ? `<div class="mt">${table(cols, res, {empty: '<b>No hay contactos con esa búsqueda</b>Revisa el nombre o agrégalo en AGORA y vuelve a buscar.'})}</div>` : '');
    else body = '<p class="src">Escribe al menos dos letras del nombre, el correo o el teléfono.</p>';
    return panel('Buscar en AGORA', ME.rol === 'ADMIN' ? 'Todos los contactos de la subcuenta.' : 'Solo los contactos que tienes asignados en AGORA.',
      `<form class="search-row" data-form="buscar-agora" novalidate><label class="fld">Contacto<span class="search-in">${icon('search')}<input type="search" name="consulta" value="${esc(st.consulta)}" placeholder="Nombre, correo o teléfono" autocomplete="off" enterkeyhint="search" autofocus></span></label><button class="btn btn-cta" type="submit">Buscar</button></form>${body}`);
  },
};
async function buscarAgora(consulta) {
  const st = state.contactos;
  st.consulta = consulta.trim();
  if (st.consulta.length < 2) { st.error = 'Escribe al menos dos letras.'; repaint(); return; }
  st.buscando = true; st.error = ''; repaint();
  try { const d = await api('ghl/contactos/buscar', {method: 'POST', body: {consulta: st.consulta}}); st.resultados = d.contactos || []; st.aviso = d.aviso || ''; }
  catch (x) { st.error = x.message; st.resultados = null; }
  st.buscando = false;
  if (R.view === 'contactos') repaint();
}
function fichaCliente(k) {
  const c = clientes().find(x => x.k === k); if (!c) return;
  const lista = [...c.lista].sort((a, b) => String(b.creado_en).localeCompare(String(a.creado_en)));
  const s = openModal(modalHead(esc(c.nombre), esc(c.correo)) + `<div class="grid g3" style="gap:10px">${metric('Convenios', int(c.total))}${metric('Firmados', int(c.n.FIRMADO))}${metric('Por firmar', int(c.n.ENVIADO))}</div>
    <h4 class="h4">Sus convenios</h4><ul class="mini-list">${lista.map(x => `<li><a href="${href('/contratos/' + x.uid)}"><span><b>Versión ${int(x.version)}</b><small>Creado ${esc(fdate(x.creado_en))}</small></span>${chip(x.estado)}</a></li>`).join('')}</ul>
    <div class="form-ft"><button class="btn" type="button" data-close>Cerrar</button>${can('editar') ? `<button class="btn btn-cta" type="button" data-nuevo-correo="${esc(c.correo)}" data-nuevo-nombre="${esc(c.nombre)}">${icon('plus')}Nuevo convenio</button>` : ''}</div>`);
  s.querySelectorAll('a').forEach(a => a.addEventListener('click', () => closeModal(true)));
}
/* Abrir Nuevo convenio con el contacto ya elegido (desde AGORA) o con la búsqueda lista (desde un cliente con convenio) */
function nuevoCon({contacto, buscar}) {
  state.nuevo = nuevoInicial();
  if (contacto) elegirContacto(contacto);
  if (buscar) { state.nuevo.consulta = buscar; state.nuevo.autoBuscar = true; }
  closeAll(); go('/contratos/nuevo');
}

/* ---------- Nuevo convenio ---------- */
function nuevoInicial() {
  const d = new Date(), next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
  return {consulta: '', resultados: null, aviso: '', buscando: false, error: '', elegido: null, autoBuscar: false,
    f: {nombre: '', cedula: '', correo: '', cuota: '', meses: '12', anio: String(next.getFullYear()), mes: String(next.getMonth() + 1), cuotasPorMes: '1'},
    calc: null, calcErr: '', guardando: false, errorForm: ''};
}
function elegirContacto(c) {
  const s = state.nuevo; s.elegido = c; s.f.nombre = c.nombre || ''; s.f.cedula = c.cedula || ''; s.f.correo = c.correo || ''; s.errorForm = '';
}
const anios = () => { const y = new Date().getFullYear(); return [y, y + 1]; };
V.nuevo = {
  render() {
    if (!can('editar')) return noAccess();
    const s = state.nuevo ||= nuevoInicial(), c = s.elegido, f = s.f;
    const back = `<a class="back" href="${href('/contratos')}">${icon('chevL')}Contratos</a>`;
    const step1 = c
      ? `<div class="chosen"><span class="ini">${esc(initials(c.nombre))}</span><span class="tx"><b>${esc(c.nombre || 'Sin nombre')}</b><small>${esc([c.correo, c.telefono, c.cedula].filter(Boolean).join(' · ') || 'Sin datos de contacto')}</small></span><button class="btn btn-sm" type="button" data-cambiar>Cambiar</button></div>`
      : `<p class="src" style="margin:0 0 12px">Busca al alumno o representante entre los contactos de AGORA. Si no aparece, agrégalo en AGORA y vuelve a buscar.</p>
        <form class="search-row" data-form="buscar-nuevo" novalidate><label class="fld">Contacto<span class="search-in">${icon('search')}<input type="search" name="consulta" value="${esc(s.consulta)}" placeholder="Nombre, correo o teléfono" autocomplete="off" enterkeyhint="search" autofocus></span></label><button class="btn btn-cta" type="submit">Buscar</button></form>
        ${s.error ? `<div class="note-gold">${esc(s.error)}</div>` : ''}${s.aviso ? `<div class="note-gold">${esc(s.aviso)}</div>` : ''}
        ${s.buscando ? '<div style="margin-top:14px"><span class="sk w80"></span><span class="sk w60"></span></div>' : s.resultados ? (s.resultados.length ? `<div class="pick" role="list">${s.resultados.map((r, i) => `<button type="button" role="listitem" data-pick="${i}"><span class="ini">${esc(initials(r.nombre))}</span><span class="tx"><b>${esc(r.nombre || 'Sin nombre')}</b><small>${esc([r.correo, r.telefono, r.cedula].filter(Boolean).join(' · ') || 'Sin datos de contacto')}</small></span>${convPorCorreo(r.correo).length ? `<span class="sc sc-gray">${int(convPorCorreo(r.correo).length)} convenio${convPorCorreo(r.correo).length === 1 ? '' : 's'}</span>` : ''}${icon('chevR')}</button>`).join('')}</div>` : (s.aviso ? '' : '<p class="empty"><b>No hay contactos con esa búsqueda</b>Revisa el nombre o agrégalo en AGORA.</p>')) : ''}`;
    const fld = (k, l, {type = 'text', hint = '', mode = '', ph = '', req} = {}) => `<label class="fld">${l}${req ? '' : ''}<input name="${k}" type="${type}" value="${esc(f[k])}" ${mode ? `inputmode="${mode}"` : ''} placeholder="${esc(ph)}" autocomplete="off">${hint ? `<small class="hint">${hint}</small>` : ''}</label>`;
    const sel = (k, l, opts) => `<label class="fld">${l}<select name="${k}">${opts.map(([v, t]) => `<option value="${v}" ${String(v) === String(f[k]) ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
    const step2 = `<form class="form" data-form="nuevo" novalidate>
        <div class="grid g2">${fld('nombre', 'Nombre completo')}${fld('cedula', 'Cédula', {ph: 'V-12345678'})}</div>
        ${fld('correo', 'Correo', {type: 'email', hint: 'Si el contacto no tiene correo, escríbelo aquí. Se guarda también en AGORA.'})}
        <p class="h4" style="margin:6px 0 0">Plan de pago</p>
        <div class="grid g2">${fld('cuota', 'Cuota mensual ($)', {mode: 'decimal', ph: '150,00'})}${fld('meses', 'Meses', {type: 'number', mode: 'numeric', ph: '12', hint: 'De 1 a 20 meses.'})}</div>
        <div class="grid g2">${sel('anio', 'Año de inicio', anios().map(y => [y, y]))}${sel('mes', 'Mes de inicio', MESES.map((m, i) => [i + 1, cap(m)]))}</div>
        <div class="seg-fld">Cuotas por mes${seg('cpm', [['1', '1 cuota'], ['2', '2 cuotas'], ['4', '4 cuotas']], f.cuotasPorMes, 'Cuotas por mes')}<small class="hint" style="font-weight:400">1 cuota vence el 30; 2 cuotas, el 15 y el 30; 4 cuotas, los viernes.</small></div>
        <p class="fld-err" role="alert">${esc(s.errorForm)}</p>
        <div class="form-ft"><a class="btn" href="${href('/contratos')}">Cancelar</a><button class="btn btn-cta" type="submit" ${s.guardando ? 'disabled' : ''}>${s.guardando ? '<span class="spin" aria-hidden="true"></span>Creando…' : 'Crear convenio'}</button></div>
      </form>`;
    return back + head('Contratos', 'Nuevo convenio', 'Elige el contacto de AGORA, completa los datos y revisa el cálculo antes de crearlo. Queda como borrador: nada se envía al cliente todavía.')
      + `<div class="grid g-side"><div class="grid">
          ${panel(`<span class="step ${c ? 'done' : ''}">${c ? '✓' : '1'}</span>Busca el contacto`, '', step1)}
          ${panel('<span class="step">2</span>Datos del convenio', c ? '' : 'Primero elige el contacto.', step2, '', c ? '' : 'is-off')}
        </div><aside class="sticky" id="nv-sum">${this.summary()}</aside></div>`;
  },
  summary() {
    const s = state.nuevo, f = s.f, k = s.calc, cuotas = num(f.cuota), meses = parseInt(f.meses, 10) || 0;
    const ini = f.mes && f.anio ? `${cap(MESES[f.mes - 1])} ${f.anio}` : '—';
    return `<section class="hero"><div><p class="t-label">Total a pagar</p><p class="t-hero" style="margin:10px 0 0">${k ? esc(money(k.total_a_pagar)) : '—'}</p>
        <p class="f">${k ? `${int(k.cuotas)} cuota${k.cuotas === 1 ? '' : 's'} desde ${esc(ini.toLowerCase())}` : s.calcErr ? esc(s.calcErr) : 'Escribe la cuota mensual y los meses para ver el cálculo.'}</p></div>
      <div class="goal">${kv([['Cuota mensual', cuotas ? esc(money(cuotas)) : '—'], ['Meses', meses ? int(meses) : '—'], ['Cuotas por mes', esc(f.cuotasPorMes)], ['Precio del curso', k ? esc(money(k.precio_curso)) : '—']])}
      <p class="f" style="margin:0">El cálculo es el mismo del convenio: precio = cuota × meses. Los cargos como la inscripción se agregan después, en el detalle.</p></div></section>`;
  },
  mounted(app) {
    const s = state.nuevo;
    if (s?.autoBuscar) { s.autoBuscar = false; buscarNuevo(s.consulta); return; }
    if (s?.elegido && !s.calc && !s.calcErr) calcular();
  },
};
async function buscarNuevo(consulta) {
  const s = state.nuevo; s.consulta = consulta.trim();
  if (s.consulta.length < 2) { s.error = 'Escribe al menos dos letras.'; repaint(); return; }
  s.buscando = true; s.error = ''; s.aviso = ''; repaint();
  try { const d = await api('ghl/contactos/buscar', {method: 'POST', body: {consulta: s.consulta}}); s.resultados = d.contactos || []; s.aviso = d.aviso || ''; }
  catch (x) { s.error = x.message; s.resultados = null; }
  s.buscando = false; if (R.view === 'nuevo') { repaint(); $('[data-pick]')?.focus({preventScroll: true}); }
}
let calcT = 0, calcSeq = 0;
function calcular() {
  clearTimeout(calcT);
  calcT = setTimeout(async () => {
    const s = state.nuevo; if (!s) return; const f = s.f, seq = ++calcSeq;
    const cuota = String(f.cuota).trim().replace(/\./g, '').replace(',', '.'), meses = parseInt(f.meses, 10);
    if (!cuota || !(num(cuota) > 0) || !meses) { s.calc = null; s.calcErr = ''; paintSum(); return; }
    try {
      const k = await api('contratos/calculo', {method: 'POST', body: {cuota, meses, anio: Number(f.anio), mes: Number(f.mes), cuotas_por_mes: Number(f.cuotasPorMes), cargos: []}});
      if (seq !== calcSeq) return; s.calc = k; s.calcErr = '';
    } catch (x) { if (seq !== calcSeq) return; s.calc = null; s.calcErr = x.message; }
    paintSum();
  }, 280);
}
const paintSum = () => { const el = $('#nv-sum'); if (el && R.view === 'nuevo') el.innerHTML = V.nuevo.summary(); };
async function crearConvenio(btn) {
  const s = state.nuevo, f = s.f, c = s.elegido; if (!c || s.guardando) return;
  const err = m => { s.errorForm = m; const e = $('[data-form="nuevo"] .fld-err'); if (e) e.textContent = m; };
  if (!f.nombre.trim() || !f.cedula.trim()) return err('El nombre y la cédula son obligatorios.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.correo.trim())) return err('Escribe un correo válido: por ahí le llega el enlace para firmar.');
  const cuota = String(f.cuota).trim().replace(/\./g, '').replace(',', '.');
  if (!/^\d+(\.\d{1,2})?$/.test(cuota) || !(num(cuota) > 0)) return err('La cuota mensual debe ser un monto mayor que cero, con hasta dos decimales.');
  const meses = parseInt(f.meses, 10); if (!(meses >= 1 && meses <= 20)) return err('Los meses deben estar entre 1 y 20.');
  s.guardando = true; busy(btn, true, 'Creando…'); err('');
  try {
    const {uid} = await api('contratos', {method: 'POST', body: {
      cliente: {contact_id: c.id, nombre: f.nombre.trim(), cedula: f.cedula.trim(), telefono: c.telefono || '', correo: f.correo.trim(), correo_agora: c.correo || ''},
      curso: {cuota_mensual: cuota, meses, mes_inicio: `${f.anio}-${String(f.mes).padStart(2, '0')}`, cuotas_por_mes: Number(f.cuotasPorMes), cargos: []},
      responsable: {nombre: ME.nombre || '', correo: ME.correo || ''},
    }});
    DATA.contratos = null; state.nuevo = null; toast('Convenio creado como borrador.');
    go('/contratos/' + uid);
  } catch (x) { s.guardando = false; busy(btn, false); err(x.message); }
}

/* ---------- Detalle del convenio ---------- */
/* Los términos no vienen en la respuesta: se reconstruyen desde las cuotas (precio = cuota × meses). */
function terminosDe(d) {
  const q = d.calculo.cuotas || [], meses = q.length ? Math.max(...q.map(x => x.mes)) : 12;
  const [y, m] = q.length ? q[0].vencimiento.split('-').map(Number) : [new Date().getFullYear(), new Date().getMonth() + 1];
  const cuota = meses ? (num(d.calculo.precio_curso) / meses) : 0;
  const ins = (d.calculo.cargos || []).find(c => /^inscripci/i.test(norm(c.concepto)));
  return {cuota: cuota ? cuota.toFixed(2).replace('.', ',') : '', meses, anio: y, mes: m, cuotas_por_mes: q.length && meses ? Math.round(q.length / meses) : 1, inscripcion: ins ? String(ins.monto).replace('.', ',') : '0', descuento: d.descuento || '0'};
}
V.detalle = {
  need: () => DATA.detalle[R.uid] ? Promise.resolve() : loadDetalle(R.uid),
  render() {
    const back = `<a class="back" href="${href('/contratos')}">${icon('chevL')}Contratos</a>`;
    if (this.error) return back + failed(this.error);
    const d = DATA.detalle[R.uid]; if (!d) return back + loading();
    const k = d.calculo, q = k.cuotas || [], t = terminosDe(d), e = d.estado;
    const meta = ESTADO[e] || {l: e};
    const acts = [];
    if (e === 'BORRADOR' && can('enviar')) acts.push(`<button class="btn btn-cta" type="button" data-act="enviar">${icon('send')}Enviar al cliente</button>`);
    if (e === 'ENVIADO' && d.enlace) acts.push(`<button class="btn btn-tint" type="button" data-copy="${esc(d.enlace)}">${icon('split')}Copiar enlace</button>`);
    if (can('editar') && e !== 'FIRMADO') acts.push(`<button class="btn" type="button" data-act="editar">${icon('edit')}Editar cálculo</button>`);
    if (e === 'BORRADOR' && d.version === 1 && can('editar')) acts.push(`<button class="btn btn-danger" type="button" data-act="eliminar">Eliminar borrador</button>`);
    const est = {
      BORRADOR: ['gray', 'edit', 'Revisa el cálculo y el convenio antes de enviar. Al enviar, el cliente recibe el enlace por correo.'],
      ENVIADO: ['info', 'clock', 'El enlace está activo y el cliente todavía no ha firmado.'],
      FIRMADO: ['ok', 'check', 'El convenio está firmado. El cliente y el personal responsable reciben la copia por correo.'],
      REVOCADA: ['bad', 'warn', 'Este enlace fue revocado. Edita el cálculo para crear una versión nueva y enviarla otra vez.'],
    }[e] || ['gray', 'info', ''];
    let enlace = `<div class="state-line ${est[0]}">${icon(est[1])}<span>${esc(est[2])}</span></div>`;
    if (e === 'ENVIADO') {
      enlace += d.enlace
        ? `<div class="secret link mt"><small>Enlace para el cliente. Puedes copiarlo cuando quieras mientras siga vigente.</small><code>${esc(d.enlace)}</code><div class="row"><button class="btn btn-sm btn-tint" type="button" data-copy="${esc(d.enlace)}">${icon('split')}Copiar enlace</button></div></div>`
        : `<p class="src">${d.enlace_guardable ? 'No hay un enlace guardado para mostrar. Genera uno nuevo para compartirlo por otra vía; el anterior dejará de servir.' : 'El servidor no puede guardar el enlace (no puede escribir en la carpeta storage/): se verá solo al generarlo.'}</p>`;
      enlace += `<div class="form-ft" style="justify-content:flex-start">${can('enviar') ? `<button class="btn btn-sm" type="button" data-act="enlace">${icon('refresh')}Generar enlace nuevo</button>` : ''}${can('revocar') ? `<button class="btn btn-sm btn-danger" type="button" data-act="revocar">Revocar enlace</button>` : ''}</div>`;
    }
    const pdfBtns = [];
    if (e === 'BORRADOR') pdfBtns.push(`<a class="btn btn-sm btn-tint" href="/api/contratos/${d.uid}/pdf/previa" target="_blank" rel="noopener">${icon('download')}Vista previa del PDF</a>`);
    if (d.pdfs?.enviado) pdfBtns.push(`<a class="btn btn-sm" href="/api/contratos/${d.uid}/pdf/enviado" target="_blank" rel="noopener">${icon('download')}PDF enviado</a>`);
    if (d.pdfs?.firmado) pdfBtns.push(`<a class="btn btn-sm btn-tint" href="/api/contratos/${d.uid}/pdf/firmado" target="_blank" rel="noopener">${icon('download')}PDF firmado</a>`);
    const pdfSrc = e === 'BORRADOR' ? 'previa' : d.pdfs?.firmado ? 'firmado' : d.pdfs?.enviado ? 'enviado' : '';
    const conv = convPorCorreo(d.cliente.correo).filter(x => x.uid !== d.uid);
    return back + head(`Convenio de pago · versión ${int(d.version)}`, esc(d.cliente.nombre), `${esc(d.cliente.correo)} · ${chip(e)}`, acts.join(''))
      + `<div class="grid g-hero">
        <section class="hero"><div><p class="t-label">Total a pagar</p><p class="t-hero" style="margin:10px 0 0">${esc(money(k.total_a_pagar))}</p>
          <p class="f">${int(q.length)} cuota${q.length === 1 ? '' : 's'} · ${esc(money(t.cuota.replace(',', '.')))} al mes durante ${int(t.meses)} mes${t.meses === 1 ? '' : 'es'}</p></div>
          <div class="goal"><dl class="kv sum"><dt>Precio del curso</dt><dd>${esc(money(k.precio_curso))}</dd>${(k.cargos || []).map(c => `<dt>${esc(c.concepto)}</dt><dd>${esc(money(c.monto))}</dd>`).join('')}<dt class="tot">Total a pagar</dt><dd class="tot">${esc(money(k.total_a_pagar))}</dd></dl></div></section>
        <div class="grid g2">
          ${metric('Estado', chip(e), esc(meta.l === 'Enviado' ? 'Esperando la firma' : meta.l === 'Firmado' ? 'Listo' : meta.l === 'Borrador' ? 'Sin enviar' : 'Necesita versión nueva'))}
          ${metric('Versión', int(d.version), d.version > 1 ? 'Las anteriores quedan en el registro' : 'Primera versión')}
          ${metric('Primera cuota', q[0] ? esc(money(q[0].monto)) : '—', q[0] ? 'Vence el ' + esc(fday(q[0].vencimiento)) : '')}
          ${metric('Última cuota', q.length ? esc(fday(q[q.length - 1].vencimiento)) : '—', `Descuento 1.ª cuota: ${esc(d.descuento || '0')} %`)}
        </div></div>
      <div class="grid g2 mt">
        ${panel('Cliente', e === 'BORRADOR' ? 'Puedes corregirlo mientras sea borrador.' : 'El PDF enviado no cambia.', kv([['Nombre', esc(d.cliente.nombre)], ['Cédula', esc(d.cliente.cedula || '—')], ['Teléfono', esc(d.cliente.telefono || '—')], ['Correo', esc(d.cliente.correo)]]) + (conv.length ? `<p class="f-note">${int(conv.length)} convenio${conv.length === 1 ? '' : 's'} más con este correo · <a href="${href('/con-convenio')}" data-ficha-correo="${esc(d.cliente.correo)}">Ver ficha</a></p>` : ''), e === 'BORRADOR' && can('editar') ? `<button class="btn btn-sm" type="button" data-act="cliente">${icon('edit')}Corregir datos</button>` : '')}
        ${panel('Enlace de firma', '', enlace)}
      </div>
      <div class="mt">${panel('Convenio', e === 'BORRADOR' ? 'Así quedará el convenio con los datos de este borrador. Se guarda como PDF oficial al enviarlo.' : 'El documento de esta versión.', (pdfBtns.length ? `<div class="acts">${pdfBtns.join('')}${pdfSrc ? `<button class="btn btn-sm" type="button" data-pdf-toggle>${state.detalle.verPdf ? 'Ocultar' : 'Verlo aquí'}</button>` : ''}</div>` : '<p class="muted" style="margin:0">Todavía no hay un PDF para este convenio.</p>') + (state.detalle.verPdf && pdfSrc ? `<iframe class="pdf-frame" title="Convenio en PDF" src="/api/contratos/${d.uid}/pdf/${pdfSrc}"></iframe>` : ''))}</div>
      <div class="mt">${panel('Cuotas', `${int(q.length)} pago${q.length === 1 ? '' : 's'} · ${t.cuotas_por_mes === 1 ? 'una al mes' : t.cuotas_por_mes + ' al mes'}`, table([{k: 'numero', l: 'Cuota', n: 1, f: int}, {k: 'vencimiento', l: 'Vence', f: v => esc(fday(v))}, {k: 'mes', l: 'Mes del curso', n: 1, f: int}, {k: 'monto', l: 'Monto', n: 1, f: v => esc(money(v))}], q, {empty: 'Sin cuotas.'}))}</div>`;
  },
};
function editarCalculo(d) {
  const t = terminosDe(d), nueva = d.estado !== 'BORRADOR';
  const s = openModal(modalHead('Editar cálculo', nueva ? 'Este convenio ya se envió: al guardar se crea una versión nueva y el enlace anterior deja de servir.' : 'Los cambios se guardan en este borrador.') + `<form class="form" data-form="editar" novalidate>
    <div class="grid g2"><label class="fld">Cuota mensual ($)<input name="cuota" inputmode="decimal" value="${esc(t.cuota)}" autofocus></label><label class="fld">Meses<input name="meses" type="number" inputmode="numeric" min="1" max="20" value="${t.meses}"></label></div>
    <div class="grid g2"><label class="fld">Año de inicio<select name="anio">${[...new Set([...anios(), t.anio])].sort().map(y => `<option ${y === t.anio ? 'selected' : ''}>${y}</option>`).join('')}</select></label><label class="fld">Mes de inicio<select name="mes">${MESES.map((m, i) => `<option value="${i + 1}" ${i + 1 === t.mes ? 'selected' : ''}>${cap(m)}</option>`).join('')}</select></label></div>
    <div class="seg-fld">Cuotas por mes${seg('cpm-e', [['1', '1 cuota'], ['2', '2 cuotas'], ['4', '4 cuotas']], String(t.cuotas_por_mes), 'Cuotas por mes')}</div>
    <div class="grid g2"><label class="fld">Valor de la inscripción ($)<input name="inscripcion" inputmode="decimal" value="${esc(t.inscripcion)}"></label><label class="fld">Descuento 1.ª cuota (%)<input name="descuento" inputmode="decimal" value="${esc(t.descuento)}"></label></div>
    <p class="fld-err" role="alert"></p>
    <div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">${nueva ? 'Crear versión nueva' : 'Guardar cálculo'}</button></div></form>`);
  const form = s.querySelector('form');
  form.onsubmit = async ev => {
    ev.preventDefault();
    const fd = new FormData(form), m = x => String(x || '').trim().replace(/\./g, '').replace(',', '.');
    const cuota = m(fd.get('cuota')), ins = m(fd.get('inscripcion')) || '0';
    const err = form.querySelector('.fld-err');
    if (!/^\d+(\.\d{1,2})?$/.test(cuota) || !(num(cuota) > 0)) { err.textContent = 'La cuota mensual debe ser un monto mayor que cero.'; return; }
    if (!/^\d+(\.\d{1,2})?$/.test(ins)) { err.textContent = 'La inscripción debe ser un monto, o 0.'; return; }
    const otros = (d.calculo.cargos || []).filter(c => !/^inscripci/i.test(norm(c.concepto))).map(c => ({concepto: c.concepto, monto: String(c.monto)}));
    const cpm = form.querySelector('[data-seg="cpm-e"] .is-on')?.dataset.v || '1';
    const b = form.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try {
      const r = await api(`contratos/${d.uid}/editar`, {method: 'POST', body: {cuota, meses: Number(fd.get('meses')), anio: Number(fd.get('anio')), mes: Number(fd.get('mes')), cuotas_por_mes: Number(cpm), cargos: [{concepto: 'Inscripción', monto: ins}, ...otros], descuento: m(fd.get('descuento')) || '0'}});
      closeModal(); DATA.contratos = null; await loadDetalle(d.uid, true); loadContratos(true).catch(() => {});
      toast(nueva ? `Versión ${r.version} creada como borrador.` : 'Cálculo guardado.'); repaint();
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function corregirCliente(d) {
  const c = d.cliente;
  const s = openModal(modalHead('Corregir datos', 'Solo mientras el convenio es borrador. Si cambias el correo, se guarda también en AGORA.') + `<form class="form" data-form="cliente" novalidate>
    <label class="fld">Nombre completo<input name="nombre" value="${esc(c.nombre)}" autofocus></label>
    <div class="grid g2"><label class="fld">Cédula<input name="cedula" value="${esc(c.cedula)}"></label><label class="fld">Teléfono<input name="telefono" value="${esc(c.telefono)}" inputmode="tel"></label></div>
    <label class="fld">Correo<input name="correo" type="email" value="${esc(c.correo)}"></label>
    <p class="fld-err" role="alert"></p><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">Guardar datos</button></div></form>`);
  const form = s.querySelector('form');
  form.onsubmit = async ev => {
    ev.preventDefault(); const fd = Object.fromEntries(new FormData(form)); const err = form.querySelector('.fld-err');
    if (!fd.nombre.trim() || !fd.cedula.trim()) { err.textContent = 'El nombre y la cédula son obligatorios.'; return; }
    const b = form.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try { await api(`contratos/${d.uid}/cliente`, {method: 'POST', body: fd}); closeModal(); DATA.contratos = null; await loadDetalle(d.uid, true); toast('Datos del cliente corregidos.'); repaint(); }
    catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function enlaceModal(titulo, enlace, vence, extra = '') {
  const s = openModal(modalHead(esc(titulo), extra) + `<div class="secret link"><small>Enlace para que el cliente firme${vence ? ` · vence el ${esc(fstamp(vence))}` : ''}.</small><code>${esc(enlace)}</code><div class="row"><button class="btn btn-sm btn-cta" type="button" data-copy="${esc(enlace)}">${icon('split')}Copiar enlace</button></div></div><div class="form-ft"><button class="btn" type="button" data-close>Listo</button></div>`);
  return s;
}
async function accion(act, d) {
  const uid = d.uid, refresh = async () => { DATA.contratos = null; await loadDetalle(uid, true); loadContratos(true).catch(() => {}); repaint(); };
  if (act === 'editar') return editarCalculo(d);
  if (act === 'cliente') return corregirCliente(d);
  if (act === 'enviar') return confirmModal('Enviar al cliente', `Se congela la versión ${int(d.version)}, se genera el PDF oficial y <b>${esc(d.cliente.nombre)}</b> recibe el enlace para firmar en <b>${esc(d.cliente.correo)}</b>. Revisa el cálculo y el convenio antes de enviar.`, 'Enviar convenio', async () => {
    const r = await api(`contratos/${uid}/enviar`, {method: 'POST'}); await refresh();
    setTimeout(() => enlaceModal('Convenio enviado', r.enlace, r.vence, 'El cliente ya lo recibió por correo. Si prefieres, compártelo también por WhatsApp.'), 200);
  });
  if (act === 'enlace') return confirmModal('Generar enlace nuevo', 'El enlace anterior dejará de servir y el cliente tendrá que usar el nuevo.', 'Generar enlace', async () => {
    const r = await api(`contratos/${uid}/enlace`, {method: 'POST'}); await refresh();
    setTimeout(() => enlaceModal('Enlace nuevo', r.enlace, r.vence), 200);
  });
  if (act === 'revocar') return confirmModal('Revocar enlace', 'El cliente no podrá firmar con el enlace actual. Para volver a enviarlo, edita el cálculo y crea una versión nueva.', 'Revocar enlace', async () => { await api(`contratos/${uid}/revocar`, {method: 'POST'}); await refresh(); toast('Enlace revocado.'); }, true);
  if (act === 'eliminar') return confirmModal('Eliminar borrador', 'Se borrará el borrador y su historial. No se puede deshacer.', 'Eliminar', async () => { await api(`contratos/${uid}`, {method: 'DELETE'}); delete DATA.detalle[uid]; DATA.contratos = null; toast('Borrador eliminado.'); go('/contratos'); }, true);
}

/* ---------- Personas ---------- */
V.personas = {
  need: () => DATA.usuarios ? Promise.resolve() : loadUsuarios(),
  render() {
    const acts = `<button class="btn btn-cta" type="button" data-act="persona">${icon('plus')}Agregar persona</button>`;
    const lede = 'Quién entra al panel y qué puede hacer. El acceso se da por invitación.';
    if (this.error) return head('Equipo', 'Personas', lede) + failed(this.error);
    if (!DATA.usuarios) return loading('Equipo');
    const st = state.personas, all = DATA.usuarios, q = norm(st.q), act = all.filter(u => u.activo);
    const rows = all.filter(u => !q || norm(u.nombre + ' ' + u.correo).includes(q));
    const cols = [
      {k: 'nombre', l: 'Persona', f: (v, r) => `<span class="who-cell"><b>${esc(v)}${r.id === ME.id ? ' <span class="sc sc-gray">Tú</span>' : ''}</b><small>${esc(r.correo)}</small></span>`},
      {k: 'rol', l: 'Rol', f: v => esc(ROLES[v]?.l || v)},
      {k: 'activo', l: 'Estado', f: v => v ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Activa</span>' : '<span class="lt lt-bad"><i aria-hidden="true"></i>Desactivada</span>'},
      {k: 'id', l: '', cls: 'act', f: v => `<button class="btn btn-sm" type="button" data-user="${v}" aria-haspopup="true">${icon('more')}<span>Opciones</span></button>`},
    ];
    return head('Equipo', 'Personas', lede, acts)
      + `<div class="grid g4">${metric('Activas', int(act.length), `${int(all.length - act.length)} desactivada${all.length - act.length === 1 ? '' : 's'}`)}${['ADMIN', 'REMITENTE', 'VISOR'].map(r => metric(ROLES[r].l, int(act.filter(u => u.rol === r).length), ROLES[r].d)).join('')}</div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Nombre o correo')}</div>${table(cols, rows)}</section>`;
  },
};
const rolPicker = (val, name = 'rol') => `<div class="seg-fld">Rol${seg(name, Object.keys(ROLES).map(r => [r, ROLES[r].l]), val, 'Rol')}</div><ul class="role-help">${Object.keys(ROLES).map(r => `<li>${icon(r === 'ADMIN' ? 'shield' : r === 'REMITENTE' ? 'send' : 'search')}<span><b class="strong">${ROLES[r].l}:</b> ${ROLES[r].d}</span></li>`).join('')}</ul>`;
const claveAzar = () => { const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789', v = new Uint32Array(12); crypto.getRandomValues(v); return [...v].map((x, i) => (i && i % 4 === 0 ? '-' : '') + a[x % a.length]).join(''); };
function personaModal() {
  const s = openModal(modalHead('Agregar persona', 'Entra con su correo y la clave temporal que le compartas.') + `<form class="form" novalidate>
    <label class="fld">Nombre completo<input name="nombre" autofocus></label><label class="fld">Correo<input name="correo" type="email"></label>
    <label class="fld">Clave temporal (mínimo 10 caracteres)<span class="pw-in"><input name="clave" value="${claveAzar()}" autocomplete="off"><button class="pw-eye" type="button" data-regen>Otra</button></span></label>
    ${rolPicker('REMITENTE')}<p class="fld-err" role="alert"></p><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">Agregar persona</button></div></form>`);
  const form = s.querySelector('form');
  s.querySelector('[data-regen]').onclick = () => { form.clave.value = claveAzar(); };
  form.onsubmit = async ev => {
    ev.preventDefault(); const fd = Object.fromEntries(new FormData(form)), err = form.querySelector('.fld-err');
    fd.rol = form.querySelector('[data-seg="rol"] .is-on')?.dataset.v || 'REMITENTE';
    if (!fd.nombre.trim() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fd.correo.trim())) { err.textContent = 'Escribe el nombre y un correo válido.'; return; }
    if (fd.clave.length < 10) { err.textContent = 'La clave temporal debe tener al menos 10 caracteres.'; return; }
    const b = form.querySelector('[type=submit]'); busy(b, true, 'Agregando…');
    try {
      await api('usuarios', {method: 'POST', body: fd}); await loadUsuarios(true); repaint();
      openModal(modalHead('Persona agregada', `Comparte la clave con ${esc(fd.nombre)} por un canal seguro. Se le pedirá cambiarla.`) + `<div class="secret"><code>${esc(fd.clave)}</code><button class="btn btn-sm btn-cta" type="button" data-copy="${esc(fd.clave)}">Copiar</button></div><p class="src">Correo para entrar: ${esc(fd.correo)}</p><div class="form-ft"><button class="btn" type="button" data-close>Listo</button></div>`);
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function userMenu(id, anchor) {
  const u = DATA.usuarios.find(x => x.id === id); if (!u) return;
  const yo = u.id === ME.id;
  const el = openPop(anchor, `<button type="button" data-u="rol">${icon('shield')}Cambiar rol</button><button type="button" data-u="clave">${icon('lock')}Restablecer clave</button>${yo ? '' : u.activo ? `<button type="button" data-u="off">${icon('pause')}Desactivar</button>` : `<button type="button" data-u="on">${icon('check')}Reactivar</button>`}`, 'ctx', {align: 'right'});
  if (!el) return;
  el.setAttribute('role', 'menu');
  el.onclick = e => {
    const a = e.target.closest('[data-u]')?.dataset.u; if (!a) return; closePop();
    if (a === 'rol') {
      const s = openModal(modalHead('Cambiar rol', esc(u.nombre)) + `<div class="form">${rolPicker(u.rol, 'rol-c')}<p class="fld-err" role="alert"></p></div><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="button" data-ok>Guardar rol</button></div>`);
      s.querySelector('[data-ok]').onclick = async ev => { const b = ev.currentTarget; busy(b, true); try { await api('usuarios/rol', {method: 'POST', body: {id: u.id, rol: s.querySelector('[data-seg="rol-c"] .is-on').dataset.v}}); closeModal(); await loadUsuarios(true); repaint(); toast('Rol actualizado.'); } catch (x) { busy(b, false); s.querySelector('.fld-err').textContent = x.message; } };
    }
    if (a === 'clave') {
      const nueva = claveAzar();
      const s = openModal(modalHead('Restablecer clave', `${esc(u.nombre)} entrará con esta clave temporal.`) + `<label class="fld">Nueva clave (mínimo 10 caracteres)<input name="clave" value="${nueva}" autocomplete="off"></label><p class="fld-err" role="alert"></p><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="button" data-ok>Cambiar clave</button></div>`);
      s.querySelector('[data-ok]').onclick = async ev => { const v = s.querySelector('input').value, b = ev.currentTarget; if (v.length < 10) { s.querySelector('.fld-err').textContent = 'Mínimo 10 caracteres.'; return; } busy(b, true); try { await api('usuarios/clave', {method: 'POST', body: {id: u.id, clave: v}}); closeModal(); copy(v, 'Clave cambiada y copiada.'); } catch (x) { busy(b, false); s.querySelector('.fld-err').textContent = x.message; } };
    }
    if (a === 'off') confirmModal('Desactivar persona', `${esc(u.nombre)} ya no podrá entrar al panel. Puedes reactivarla cuando quieras.`, 'Desactivar', async () => { await api('usuarios/desactivar', {method: 'POST', body: {id: u.id}}); await loadUsuarios(true); repaint(); toast('Persona desactivada.'); }, true);
    if (a === 'on') confirmModal('Reactivar persona', `${esc(u.nombre)} podrá entrar otra vez con su clave.`, 'Reactivar', async () => { await api('usuarios/activar', {method: 'POST', body: {id: u.id}}); await loadUsuarios(true); repaint(); toast('Persona reactivada.'); });
  };
}

/* ---------- Registro ---------- */
V.registro = {
  need: () => DATA.eventos ? Promise.resolve() : loadEventos(),
  render() {
    const lede = 'Lo último que pasó con los convenios: quién lo creó, cuándo se envió, cuándo se firmó.';
    const acts = `<button class="btn" type="button" data-reload-registro>${icon('refresh')}Actualizar</button>`;
    if (this.error) return head('Actividad', 'Registro', lede) + failed(this.error);
    if (!DATA.eventos) return loading('Actividad');
    const st = state.registro, all = DATA.eventos, q = norm(st.q);
    const tipos = [...new Set(all.map(e => e.tipo))];
    const det = e => { const x = e.detalle || {}; return [x.numero ? `versión ${x.numero}` : '', x.version ? `versión ${x.version}` : '', x.origen ? `desde ${x.origen === 'ghl' ? 'AGORA' : x.origen}` : '', x.motivo ? String(x.motivo).replace(/_/g, ' ') : '', x.vence ? `vence ${fdate(x.vence)}` : '', x.anterior ? `antes ${(ESTADO[x.anterior]?.l || x.anterior).toLowerCase()}` : ''].filter(Boolean).join(' · '); };
    const rows = all.filter(e => (!st.tipo || e.tipo === st.tipo) && (!q || norm((e.cliente || '') + ' ' + (EVENTOS[e.tipo] || e.tipo) + ' ' + det(e)).includes(q)));
    const page = rows.slice(st.p * 50, st.p * 50 + 50);
    const hoy = new Date().toDateString(), dHoy = all.filter(e => utc(e.creado_en)?.toDateString() === hoy).length;
    const cols = [
      {k: 'creado_en', l: 'Cuándo', f: v => `<span title="${esc(fstamp(v))}">${esc(when(v))}</span><small>${esc(fstamp(v))}</small>`},
      {k: 'tipo', l: 'Acción', f: v => `<b class="strong">${esc(EVENTOS[v] || v)}</b>`},
      {k: 'cliente', l: 'Cliente', f: (v, r) => r.uid ? `<a href="${href('/contratos/' + r.uid)}">${esc(v || 'Sin nombre')}</a>` : '<span class="muted">Sin contrato</span>'},
      {k: 'detalle', l: 'Detalle', f: (v, r) => esc(det(r)) || '<span class="muted">—</span>'},
    ];
    return head('Actividad', 'Registro', lede, acts)
      + `<div class="grid g4">${metric('Movimientos', int(all.length), 'Los más recientes')}${metric('Hoy', int(dHoy), 'Desde la medianoche')}${metric('Firmas', int(all.filter(e => e.tipo === 'FIRMADO').length), 'En este registro')}${metric('Envíos', int(all.filter(e => e.tipo === 'ENVIADO').length), 'En este registro')}</div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Cliente, acción o dato')}<label class="fld">Acción<select data-f="tipo"><option value="">Todas</option>${tipos.map(t => `<option value="${t}" ${st.tipo === t ? 'selected' : ''}>${esc(EVENTOS[t] || t)}</option>`).join('')}</select></label>${st.q || st.tipo ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, page, {empty: '<b>No hay movimientos que coincidan</b>Prueba con otra búsqueda.'})}${pager(st, rows.length, 50)}</section>`;
  },
};

/* ---------- Acceso ---------- */
V.entrar = {
  render() {
    document.documentElement.classList.add('is-auth');
    let s = $('#lg');
    if (!s) { s = document.createElement('div'); s.id = 'lg'; s.className = 'lg'; document.body.append(s); }
    s.innerHTML = `<div class="lg-wrap" role="main">
      <div class="lg-logo">${LOGO}<small>Digital App</small></div>
      <h1>Bienvenido de nuevo</h1>
      <p class="lg-sub">Entra con el acceso que uses hoy. Los dos pueden estar abiertos a la vez.</p>
      <div class="lg-pair">
        <section class="lg-card">
          <header><span class="lg-ic" style="--c:var(--mod-oro)">${icon('invoice')}</span><div><h2>Contratos</h2><p>Convenios de pago, firma y registro.</p></div></header>
          <form novalidate>
            <label class="fld">Correo<input id="lg-mail" type="email" autocomplete="username" autofocus></label>
            <label class="fld">Clave<span class="pw-in"><input id="lg-pw" type="password" autocomplete="current-password"><button class="pw-eye" type="button" aria-pressed="false">Mostrar</button></span></label>
            <p class="fld-err" role="alert"></p><button class="btn btn-cta lg-go" type="submit">Entrar en Contratos</button>
          </form>
          <p class="lg-help">¿No puedes entrar? Pídele a quien administra que te restablezca la clave.</p>
        </section>
        <section class="lg-card">
          <header><span class="lg-ic" style="--c:var(--mod-vino)">${icon('chat')}</span><div><h2>Operación comercial</h2><p>Resumen, bandeja, contactos y oportunidades.</p></div></header>
          <div class="ag-login">${agoraLoginForms()}</div>
          <p class="lg-help">Entras con el mismo correo con el que formas parte del equipo.</p>
        </section>
      </div>
      <p class="lg-foot">${icon('lock')}Agora Digital App · Cada conversación, una oportunidad.</p></div>`;
    const entrado = async () => { await Promise.all([bootContratos(), bootAgora()]); await bootEspacio(); const back = store.get('volver', ''); store.set('volver', ''); go(back && back !== '/entrar' ? back : homePath(), {replace: true}); };
    const card = s.querySelector('.lg-card');
    const eye = s.querySelector('.pw-eye'), pw = s.querySelector('#lg-pw');
    eye.onclick = () => { const v = pw.type === 'password'; pw.type = v ? 'text' : 'password'; eye.textContent = v ? 'Ocultar' : 'Mostrar'; eye.setAttribute('aria-pressed', String(v)); };
    s.querySelector('form').onsubmit = async e => {
      e.preventDefault();
      const correo = s.querySelector('#lg-mail').value.trim(), clave = pw.value, err = card.querySelector('.fld-err'), b = s.querySelector('.lg-go');
      const shake = () => { card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake'); };
      if (!correo || !clave) { err.textContent = 'Escribe tu correo y tu clave.'; shake(); return; }
      busy(b, true, 'Entrando…'); err.textContent = '';
      try { const d = await api('login', {method: 'POST', body: {correo, clave}}); ME = d.usuario; DATA.reset(); await entrado(); }
      catch (x) { busy(b, false); err.textContent = x.message; shake(); pw.select(); }
    };
    bindAgoraLogin(s, entrado);
    s.querySelector(document.activeElement?.id === 'lg-pw' ? '#lg-pw' : '#lg-mail')?.focus();
    return '';
  },
};
async function salir() {
  closeAll(); cerrarAthena();
  if (ME) { try { await api('logout', {method: 'POST'}); } catch { /* igual se sale */ } }
  if (AGORA_ME) { try { await agoraApi('logout', {method: 'POST'}); } catch { /* igual se sale */ } }
  window.dispatchEvent(new Event('agora:logout'));
  ME = null; DATA.reset(); state.nuevo = null;
  DATOS.resumen = DATOS.tareas = DATOS.auditoria = DATOS.usuarios = null;
  go('/entrar', {replace: true});
}

/* ---------- Cuenta, tema y clave ---------- */
function applyTheme() {
  const t = store.get('tema', 'auto'), dark = t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const b = $('#b-theme'); if (b) b.innerHTML = icon(dark ? 'sun' : 'moon');
}
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme);
function toggleTheme() { store.set('tema', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); applyTheme(); toast(document.documentElement.dataset.theme === 'dark' ? 'Tema oscuro' : 'Tema claro'); }
function openAccount() {
  const fila = (nombre, color, icono, detalle, accion) => `<div class="acct-row"><span class="lg-ic" style="--c:${color}">${icon(icono)}</span><span class="tx"><b>${nombre}</b><small>${detalle}</small></span>${accion}</div>`;
  const el = openPop($('#b-acct'), `<div class="acct-sys">
      ${fila('Contratos', 'var(--mod-oro)', 'invoice', ME ? `${esc(ME.nombre)} · ${esc(ROLES[ME.rol]?.l || ME.rol)}` : 'Sin sesión', ME ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Abierta</span>' : '')}
      ${fila('Operación comercial', 'var(--mod-vino)', 'chat', AGORA_ME ? `${esc(AGORA_ME.user?.email || '')}${ws && ws.name() ? ' · ' + esc(ws.name()) : ''}` : 'Sin sesión', AGORA_ME ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Abierta</span>' : '<button class="btn btn-sm btn-tint" type="button" data-agora-login>Entrar</button>')}
    </div>
    <div><h4>Tema</h4>${seg('tema', [['auto', 'Automático'], ['light', 'Claro'], ['dark', 'Oscuro']], store.get('tema', 'auto'), 'Tema')}</div>
    <div class="acct-ft">${ME ? `<button class="btn btn-sm" type="button" data-clave>${icon('lock')}Cambiar mi clave</button>` : ''}<button class="btn btn-sm" type="button" data-keys>${icon('keyboard')}Atajos</button><button class="btn btn-sm btn-danger" type="button" data-logout>${icon('logout')}Salir</button></div>`, 'acct', {align: 'right'});
  if (el) placeThumbs(el);
}
function claveModal() {
  const s = openModal(modalHead('Cambiar mi clave', 'Al cambiarla se cierran tus otras sesiones.') + `<form class="form" novalidate><label class="fld">Clave actual<input name="a" type="password" autocomplete="current-password" autofocus></label><label class="fld">Clave nueva (mínimo 10 caracteres)<input name="b" type="password" autocomplete="new-password"></label><label class="fld">Repite la clave nueva<input name="c" type="password" autocomplete="new-password"></label><p class="fld-err" role="alert"></p><div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">Cambiar clave</button></div></form>`);
  const f = s.querySelector('form');
  f.onsubmit = async e => {
    e.preventDefault(); const err = f.querySelector('.fld-err');
    if (f.b.value.length < 10) { err.textContent = 'La clave nueva debe tener al menos 10 caracteres.'; return; }
    if (f.b.value !== f.c.value) { err.textContent = 'Las claves nuevas no coinciden.'; return; }
    const b = f.querySelector('[type=submit]'); busy(b, true, 'Cambiando…');
    try { await api('clave', {method: 'POST', body: {clave_actual: f.a.value, clave_nueva: f.b.value}}); closeModal(); toast('Clave cambiada.'); } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function keysModal() {
  const mods = ALL().slice(0, 10);
  openModal(modalHead('Atajos de teclado', 'Funcionan cuando no estás escribiendo en un campo.') + `<div class="keys"><div><h3>Ir a</h3><dl>${mods.map((id, i) => `<dt><kbd>${(i + 1) % 10}</kbd></dt><dd>${esc(MODS[id].name)}</dd>`).join('')}</dl></div>
    <div><h3>Acciones</h3><dl><dt><kbd>${IS_MAC ? '⌘K' : 'Ctrl K'}</kbd></dt><dd>Buscar o ir a…</dd><dt><kbd>M</kbd></dt><dd>Abrir el menú de módulos</dd><dt><kbd>J</kbd></dt><dd>Preguntarle a Athena</dd>${can('editar') ? '<dt><kbd>N</kbd></dt><dd>Nuevo convenio</dd>' : ''}<dt><kbd>/</kbd></dt><dd>Buscar en la vista</dd><dt><kbd>D</kbd></dt><dd>Tema claro u oscuro</dd><dt><kbd>Esc</kbd></dt><dd>Cerrar</dd><dt><kbd>?</kbd></dt><dd>Esta ayuda</dd></dl></div></div>`);
}

/* ---------- Paleta ⌘K: módulos, acciones y convenios ---------- */
/* ---------- Paleta ⌘K: módulos, acciones y convenios ---------- */
function openCmd(initial = '') {
  const s = openModal(`<div class="cmdk-in">${icon('search')}<input type="search" placeholder="Busca un módulo, un cliente o una acción…" value="${esc(initial)}" aria-label="Buscar o ir a" autocomplete="off"></div><div class="cmdk-list" role="listbox"></div><div class="cmdk-ft"><span><kbd>↑</kbd><kbd>↓</kbd> moverte</span><span><kbd>Enter</kbd> abrir</span><span><kbd>Esc</kbd> cerrar</span></div>`, {cls: 'cmdk'});
  const inp = s.querySelector('input'), list = s.querySelector('.cmdk-list'); let sel = 0, items = [];
  const paintList = () => {
    const q = norm(inp.value.trim());
    const mods = ALL().map(id => ({g: GRUPOS[MODS[id].g].name, i: MODS[id].icon, c: MODS[id].c, t: MODS[id].name, d: MODS[id].desc, go: MODS[id].path}));
    const acc = [
      ...(can('editar') ? [{g: 'Acciones', i: 'plus', t: 'Nuevo convenio', d: 'Elige el contacto y arma el plan de pago', go: '/contratos/nuevo'},
        {g: 'Acciones', i: 'search', t: 'Buscar en la cartera', d: 'Contactos de la subcuenta, para crear un convenio', fn: () => { state.contactos.tab = 'agora'; go('/con-convenio'); }}] : []),
      ...(MODS.tareas.ok() ? [{g: 'Acciones', i: 'check', t: 'Nueva tarea', d: 'Para ti o para alguien del equipo', fn: () => { go('/tareas'); setTimeout(() => tareaModal(), 260); }}] : []),
      {g: 'Acciones', i: 'athena', t: 'Preguntarle a Athena', d: 'Resume tus cifras del sistema', fn: () => abrirAthena()},
      ...(agoraReady() ? [{g: 'Acciones', i: 'coins', t: 'Ventas ganadas', d: 'Completar las que están sin monto', fn: () => { if (ws) ws.pendingOppTab = 'won'; go('/oportunidades'); }}] : []),
      ...(!AGORA_ME ? [{g: 'Acciones', i: 'lock', t: 'Entrar en la operación comercial', d: 'Para el resumen, la bandeja y las oportunidades', fn: agoraLoginModal}] : []),
      ...(ME ? [{g: 'Acciones', i: 'lock', t: 'Cambiar mi clave', d: 'La del panel de Contratos', fn: claveModal}] : []),
      {g: 'Acciones', i: document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', t: 'Cambiar tema', fn: toggleTheme},
      {g: 'Acciones', i: 'keyboard', t: 'Atajos de teclado', fn: keysModal},
    ];
    const conv = (DATA.contratos || []).map(c => ({g: 'Convenios', i: 'invoice', c: 'var(--mod-oro)', t: c.cliente, d: `${c.correo} · ${(ESTADO[c.estado]?.l || c.estado).toLowerCase()} · v${c.version}`, go: '/contratos/' + c.uid}));
    const tar = (DATOS.tareas || []).filter(t => t.estado !== 'hecha').map(t => ({g: 'Tareas', i: 'check', c: 'var(--ok-solid)', t: t.titulo, d: `${t.responsable || 'Sin asignar'}${t.vence ? ' · vence ' + fday(t.vence) : ''}`, go: '/tareas'}));
    items = [...mods, ...acc, ...conv, ...tar].filter(x => !q || norm(x.t + ' ' + (x.d || '') + ' ' + x.g).includes(q)).slice(0, 40);
    sel = Math.min(sel, Math.max(0, items.length - 1));
    let g = '';
    list.innerHTML = items.length ? items.map((x, i) => `${x.g !== g ? `<p class="mdm-gt">${(g = x.g)}</p>` : ''}<div class="mdm-i ${i === sel ? 'is-kb' : ''}" role="option" aria-selected="${i === sel}" data-i="${i}"><span class="mdm-ic" style="--c:${x.c || 'var(--brand)'}">${icon(x.i)}</span><span class="tx"><b>${esc(x.t)}</b>${x.d ? `<small>${esc(x.d)}</small>` : ''}</span></div>`).join('')
      : `<p class="empty"><b>Nada coincide</b>${can('editar') && q.length > 1 ? `<button class="btn btn-sm" type="button" data-agora>Buscar «${esc(inp.value.trim())}» en la cartera</button>` : 'Prueba con otro nombre.'}</p>`;
    list.querySelector('.is-kb')?.scrollIntoView({block: 'nearest'});
  };
  const run = i => { const x = items[i]; if (!x) return; closeModal(true); if (x.fn) x.fn(); else go(x.go); };
  inp.oninput = () => { sel = 0; paintList(); };
  inp.onkeydown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); paintList(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); paintList(); }
    if (e.key === 'Enter') { e.preventDefault(); run(sel); }
  };
  list.onclick = e => {
    const it = e.target.closest('[data-i]'); if (it) return run(+it.dataset.i);
    if (e.target.closest('[data-agora]')) { const q = inp.value.trim(); closeModal(true); state.contactos.tab = 'agora'; go('/con-convenio'); buscarAgora(q); }
  };
  paintList(); inp.focus(); inp.select();
  if (!DATA.contratos && can('ver')) loadContratos().then(paintList).catch(() => {});
}

/* =====================================================================================
   Eventos (delegados: sirven para todas las vistas)
   ===================================================================================== */
let qT = 0;
document.addEventListener('input', e => {
  const t = e.target;
  if (t.matches('[data-form="nuevo"] input, [data-form="nuevo"] select')) {
    const s = state.nuevo; s.f[t.name] = t.value; if (['cuota', 'meses', 'anio', 'mes'].includes(t.name)) calcular(); return;
  }
  if (t.matches('#app [data-f]')) {
    const st = state[R.view]; if (!st) return;
    st[t.dataset.f] = t.value; st.p = 0;
    clearTimeout(qT); qT = setTimeout(() => { const pos = t.selectionStart; repaint(); const n = $(`#app [data-f="${t.dataset.f}"]`); if (n && n.tagName === 'INPUT') { n.focus(); try { n.setSelectionRange(pos, pos); } catch { /* tipo search */ } } }, t.tagName === 'SELECT' ? 0 : 160);
  }
});
document.addEventListener('submit', e => {
  const f = e.target.closest('[data-form]'); if (!f) return;
  e.preventDefault();
  if (f.dataset.form === 'buscar-agora') buscarAgora(f.consulta.value);
  if (f.dataset.form === 'buscar-nuevo') buscarNuevo(f.consulta.value);
  if (f.dataset.form === 'nuevo') crearConvenio(f.querySelector('[type=submit]'));
});
document.addEventListener('click', e => {
  const t = e.target, c = s => t.closest(s);
  if (c('[data-close]')) { closeModal(); return; }
  if (t.classList?.contains('scrim')) { closeModal(); return; }
  let el;
  if ((el = c('[data-copy]'))) { copy(el.dataset.copy, 'Enlace copiado'); return; }
  if ((el = c('.seg-b'))) {
    const sg = el.closest('.seg'), key = sg.dataset.seg, v = el.dataset.v;
    sg.querySelectorAll('.seg-b').forEach(b => { const on = b === el; b.classList.toggle('is-on', on); b.setAttribute('aria-checked', String(on)); });
    placeThumbs(sg.parentElement, true);
    if (key === 'rol-sys' || key === 'cpm-e') return;
    if (key === 'estado') { Object.assign(state.contratos, {estado: v, p: 0}); repaint(); return; }
    if (key === 'ctab') { state.contactos.tab = v; state.contactos.p = 0; setTimeout(repaint, 220); return; }
    if (key === 'cpm') { state.nuevo.f.cuotasPorMes = v; calcular(); paintSum(); return; }
    if (key === 'tema') { store.set('tema', v); applyTheme(); return; }
    return;
  }
  if ((el = c('[data-filter]'))) {
    const st = state[R.view], k = FKEY[R.view];
    if (st && k) { st[k] = st[k] === el.dataset.filter ? '' : el.dataset.filter; st.p = 0; repaint(); }
    return;
  }
  if (c('#b-search')) { openCmd(); return; }
  if (c('#b-theme')) { toggleTheme(); return; }
  if (c('#b-acct')) { openAccount(); return; }
  if (c('[data-logout]')) { salir(); return; }
  if (c('[data-clave]')) { closePop(); claveModal(); return; }
  if (c('[data-keys]')) { closePop(); keysModal(); return; }
  if (c('[data-retry]')) { render(); return; }
  if (c('[data-reload-registro]')) { DATA.eventos = null; render(); return; }
  if (c('[data-clear]')) { const st = state[R.view]; if (st) { st.q = ''; st.estado = ''; st.tipo = ''; st.p = 0; } repaint(); return; }
  if ((el = c('[data-page]'))) { const st = state[R.view]; st.p += +el.dataset.page; repaint(); $('#app .tools')?.scrollIntoView({block: 'nearest'}); return; }
  if ((el = c('[data-sort]'))) { const st = state[R.view], k = el.dataset.sort; st.sd = st.sk === k ? -st.sd : 1; st.sk = k; repaint(); return; }
  if ((el = c('[data-tab]'))) { state.contactos.tab = el.dataset.tab; repaint(); return; }
  if ((el = c('[data-ficha]'))) { fichaCliente(el.dataset.ficha); return; }
  if ((el = c('[data-ficha-correo]'))) { e.preventDefault(); const k = norm(el.dataset.fichaCorreo); fichaCliente(k); return; }
  if ((el = c('[data-ver-correo]'))) { Object.assign(state.contratos, {q: el.dataset.verCorreo, estado: '', p: 0}); go('/contratos'); return; }
  if ((el = c('[data-nuevo-correo]'))) { nuevoCon({buscar: el.dataset.nuevoCorreo || el.dataset.nuevoNombre}); return; }
  if ((el = c('[data-crear]'))) { const r = state.contactos.resultados?.find(x => x.id === el.dataset.crear); if (r) nuevoCon({contacto: r}); return; }
  if ((el = c('[data-pick]'))) { elegirContacto(state.nuevo.resultados[+el.dataset.pick]); repaint(); calcular(); $('[data-form="nuevo"] [name="cedula"]')?.focus({preventScroll: true}); return; }
  if (c('[data-cambiar]')) { state.nuevo.elegido = null; state.nuevo.calc = null; repaint(); return; }
  if (c('[data-pdf-toggle]')) { state.detalle.verPdf = !state.detalle.verPdf; repaint(); return; }
  if ((el = c('[data-act]'))) {
    const a = el.dataset.act;
    if (a === 'persona') return personaModal();
    const d = DATA.detalle[R.uid]; if (d) accion(a, d); return;
  }
  if ((el = c('[data-user]'))) { userMenu(+el.dataset.user, el); return; }
  if ((el = c('tr[data-href]')) && !c('a, button')) { go(el.dataset.href); return; }
  if (pop && !c('.pop')) closePop();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.matches?.('tr[data-href]')) { go(e.target.dataset.href); return; }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { if (!ME && !AGORA_ME) return; e.preventDefault(); if (modal?.querySelector('.cmdk')) closeModal(); else openCmd(); return; }
  if (e.key === 'Escape') { if (pop) closePop(); else if (modal) closeModal(); return; }
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
  if (typing || e.metaKey || e.ctrlKey || e.altKey || (!ME && !AGORA_ME) || modal) return;
  const k = e.key.toLowerCase(), mods = ALL();
  const n = k === '0' ? 9 : (/^[1-9]$/.test(k) ? +k - 1 : -1);
  if (n >= 0 && mods[n]) { closePop(); go(MODS[mods[n]].path); }
  else if (k === 'm') { closePop(); moduleMenu(); }
  else if (k === 'j') { closePop(); abrirAthena(); }
  else if (k === 'n' && can('editar')) go('/contratos/nuevo');
  else if (k === 'd') toggleTheme();
  else if (k === '/') { const f = $('#app input[type=search]'); if (f) { e.preventDefault(); f.focus(); } }
  else if (e.key === '?') keysModal();
});

/* =====================================================================================
   Armazón de Agora Digital App
   -------------------------------------------------------------------------------------
   La barra de arriba, el menú de módulos, el periodo, los accesos de Inicio, Ajustes y
   Auditoría, el estado del espacio, el historial y Athena. Todo con las piezas que ya
   trae el sistema de diseño: .tb con el vidrio esmerilado, .crumb, .mdm, .ath.

   Aquí vive también el puente con los módulos de Ágora: se montan tal como vienen, en un
   <section id="view" data-view="…">, que es el nodo que su propio código espera.
   ===================================================================================== */

var AG = (window.Agora || {});
var AG_READY = typeof AG.renderDashboard === 'function';
var ws = AG.workspace || null;

/* Se declaran con var a propósito: la primera ruta se calcula antes de que este bloque
   corra, y al preguntar «¿hay sesión?» tiene que responder «todavía no», no fallar. */
var AGORA_ME = null;          // sesión de Ágora
var AGORA_CONN = [];          // subcuentas a las que llega esta persona
var AGORA_REASON = null;
var unread = 0;               // conversaciones sin leer
var wonPendientes = 0;        // ventas ganadas sin monto
var ESPACIO = null;           // identidad del espacio: nombre y logo del cliente

function agoraReady() { return AG_READY && !!AGORA_ME; }
function agoraAdmin() { return agoraReady() && AGORA_ME.user?.role === 'administrator'; }
/** Quien manda en el sistema: el propietario de Ágora o la administración del panel. */
function esAdmin() { return agoraAdmin() || (!!ME && ME.rol === 'ADMIN'); }
function esSuperAdmin() { return agoraAdmin() || (!!ME && ME.rol === 'ADMIN'); }
function puedeAuditar() { return esAdmin(); }

/* ---------- API de Ágora (su propia base; ver assets/config.js) ---------- */
async function agoraApi(path, {method = 'GET', body} = {}) {
  let r;
  try {
    r = await fetch(AGORA_API + path, {
      method, credentials: 'same-origin', cache: 'no-store',
      headers: {...(body !== undefined ? {'Content-Type': 'application/json'} : {}), ...(method !== 'GET' && AGORA_ME?.csrf ? {'X-CSRF-Token': AGORA_ME.csrf} : {})},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error(navigator.onLine ? 'No se pudo conectar con el servidor. Inténtalo de nuevo.' : 'Sin conexión. Revisa tu internet.');
  }
  let d = {}; try { d = await r.json(); } catch { /* respuesta vacía */ }
  if (!r.ok) throw Object.assign(new Error(d.error || `No se pudo completar (código ${r.status}).`), {status: r.status, code: d.code});
  return d;
}

/* =====================================================================================
   El periodo: un mes, el mismo para el Resumen y para ARP Comercial
   ===================================================================================== */
var PERIODO = (() => {
  const guardado = store.get('periodo', '');
  if (/^\d{4}-\d{2}$/.test(guardado)) return guardado;
  const h = new Date();
  return `${h.getFullYear()}-${String(h.getMonth() + 1).padStart(2, '0')}`;
})();
const mesActualYM = () => { const h = new Date(); return `${h.getFullYear()}-${String(h.getMonth() + 1).padStart(2, '0')}`; };
const mesNombre = ym => { const [y, m] = String(ym).split('-'); return `${cap(MESES[Number(m) - 1] || '')} ${y}`; };
const mesCorto = ym => { const [, m] = String(ym).split('-'); return cap((MESES[Number(m) - 1] || '').slice(0, 3)); };
const mesSuma = (ym, n) => { const [y, m] = ym.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
/** En curso el mes corriente; por delante, el que todavía no empieza. */
const mesEstado = ym => ym === mesActualYM() ? 'curso' : (ym > mesActualYM() ? 'proximo' : 'cerrado');
function ponerPeriodo(ym) {
  if (ym === PERIODO) return;
  PERIODO = ym; store.set('periodo', ym);
  render();
}

/* =====================================================================================
   Montaje de un módulo de Ágora dentro del lienzo
   ===================================================================================== */
var agHost = null;
function disposeAgora() {
  if (!agHost) return;
  try { agHost.agoraLiveDispose?.(); } catch { /* soltar nunca debe trabar la vista */ }
  agHost = null;
}
const agoraGate = what => `<section class="panel"><p class="empty"><b>Entra en Ágora para ver ${esc(what)}</b>Este módulo lee los datos de tu cuenta de Ágora. Tu sesión de Contratos sigue abierta.<br><button class="btn btn-cta" type="button" data-agora-login>${icon('lock')}Entrar en Ágora</button></p></section>`;
const AG_RENDER = {dashboard: 'renderDashboard', inbox: 'renderLiveInbox', contacts: 'renderContacts', board: 'renderBoard', settings: 'renderIntegrations', help: 'renderHelp'};

function agoraView(id, {eyebrow, title, lede, what, own = false, acts = () => ''}) {
  V['ag_' + id] = {
    render() {
      if (!AG_READY) return head(eyebrow, title, lede) + `<section class="panel"><p class="empty"><b>Falta el paquete de módulos</b>No se cargó <code>assets/agora-modulos.js</code>. Revisa que esté junto a esta página.</p></section>`;
      if (!AGORA_ME) return head(eyebrow, title, lede) + agoraGate(what);
      return (own ? '' : head(eyebrow, title, lede, acts())) + `<section id="view" class="ag" data-view="${esc(id)}"></section>`;
    },
    mounted(app) {
      if (!agoraReady()) return;
      const host = app.querySelector('#view');
      if (!host) return;
      agHost = host;
      host.dataset.periodo = PERIODO;
      try { AG[AG_RENDER[id]](host); }
      catch (x) { host.innerHTML = `<p class="empty"><b>No se pudo abrir el módulo</b>${esc(x.message || 'Error inesperado')}</p>`; }
    },
  };
}

agoraView('dashboard', {eyebrow: 'Operación', title: 'ARP Comercial', lede: 'Las cifras del día, la inversión en anuncios y la rentabilidad del mes.', what: 'el tablero comercial', own: true});
agoraView('inbox', {eyebrow: 'Atención', title: 'Bandeja de conversaciones', lede: 'Todos los canales en una sola lista, con recordatorios de seguimiento.', what: 'las conversaciones'});
agoraView('contacts', {eyebrow: 'Cartera', title: 'Contactos', lede: 'Las fichas de la subcuenta, con su historial y sus etiquetas.', what: 'los contactos'});
agoraView('board', {eyebrow: 'Embudo', title: 'Oportunidades', lede: 'De la conexión al cierre: cada oportunidad abierta, a la vista.', what: 'las oportunidades'});
agoraView('settings', {eyebrow: 'Administración', title: 'Ajustes', lede: 'Las cuentas conectadas, el equipo importado y los avisos.', what: 'los ajustes'});
agoraView('help', {
  eyebrow: 'Manual', title: 'Ayuda', lede: 'Lo básico para trabajar en el sistema.', what: 'el manual',
  acts: () => `<a class="btn btn-tint" href="${esc(AG.MANUAL_PDF || '/assets/manual-vendedores.pdf')}" download>${icon('download')}Descargar el PDF</a>`,
});

/* =====================================================================================
   La barra de arriba
   ===================================================================================== */
const LOGO_ESPACIO = () => ESPACIO?.logo
  ? `<img class="esp-logo" src="${esc(ESPACIO.logo)}" alt="${esc(ESPACIO.nombre || 'Logo del cliente')}">`
  : '';

/** La migaja: marca, separador y el módulo en uso con su contador. */
function crumb() {
  const m = MODS[R.mod];
  if (!m) return '';
  const n = m.n ? m.n() : null;
  return `<button class="crumb" id="b-crumb" type="button" aria-haspopup="menu" aria-expanded="false" title="Cambiar de módulo">
    <span class="mdm-ic" style="--c:${m.c || 'var(--brand)'}">${icon(m.icon)}</span>
    <span>${esc(m.name)}</span>
    ${n ? `<b class="nav-b">${int(n)}</b>` : ''}
    ${icon('chev', 'chev')}</button>`;
}

/** Los meses: el anterior, el de ahora y el que viene, con su estado. */
function periodBar() {
  if (!MODS[R.mod]?.periodo) return '';
  const meses = [mesSuma(PERIODO, -1), PERIODO, mesSuma(PERIODO, 1)];
  const punto = ym => mesEstado(ym) === 'curso' ? '<i class="pt pt-curso" aria-hidden="true"></i>' : mesEstado(ym) === 'proximo' ? '<i class="pt pt-prox" aria-hidden="true"></i>' : '';
  return `<nav class="per" aria-label="Periodo">
    <button class="per-b" type="button" data-mes="${mesSuma(PERIODO, -12)}" title="Un año atrás" aria-label="Un año atrás">${icon('chevL')}</button>
    ${meses.map(ym => `<button class="per-b ${ym === PERIODO ? 'is-on' : ''}" type="button" data-mes="${ym}" aria-current="${ym === PERIODO}">${mesCorto(ym)}${punto(ym)}</button>`).join('')}
    <button class="per-b" type="button" data-mes="${mesActualYM()}" title="Volver al mes en curso" aria-label="Mes en curso">${icon('home')}</button>
  </nav>`;
}

/** Los accesos fijos de la derecha, como en el ecosistema. */
function rightCluster() {
  const atajo = (id, ico, rotulo, titulo) => `<a class="tb-sc" href="${href(MODS[id].path)}" ${R.mod === id ? 'aria-current="page"' : ''} title="${esc(titulo)}">${icon(ico)}<span>${esc(rotulo)}</span></a>`;
  const bloqueada = ESPACIO?.bloqueado === true;
  return `
    <button class="tb-ic" id="b-hist" type="button" aria-haspopup="true" aria-expanded="false" title="Historial de lo que has visto">${icon('history')}</button>
    <button class="tb-search" id="b-search" type="button" title="Buscar o ir a… (${MODK} K)" aria-label="Buscar o ir a">${icon('search')}<span class="tb-search-t">Buscar</span><kbd>${IS_MAC ? '⌘K' : '⌘K'}</kbd></button>
    <button class="tb-ath" id="b-ath" type="button" aria-haspopup="dialog" aria-expanded="false" title="Athena, tu agente">${icon('athena', 'ath-ic')}<span>Athena</span></button>
    ${MODS.inicio.ok() ? atajo('inicio', 'home', 'Inicio', 'Resumen del negocio') : ''}
    ${MODS.conexiones.ok() ? atajo('conexiones', 'gear', 'Ajustes', 'Cuentas conectadas y equipo') : ''}
    ${MODS.auditoria.ok() ? atajo('auditoria', 'shield', 'Auditoría', 'Trazabilidad de contactos y cambios') : ''}
    <button class="tb-sc tb-estado ${bloqueada ? 'is-off' : ''}" id="b-estado" type="button" aria-haspopup="true" aria-expanded="false" title="Estado del espacio">${icon(bloqueada ? 'lock' : 'unlock')}<span>${bloqueada ? 'Bloqueada' : 'Activa'}</span></button>
    <button class="tb-ic" id="b-theme" type="button" title="Cambiar tema (D)" aria-label="Cambiar tema">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon')}</button>
    <button class="avatar" id="b-acct" type="button" aria-haspopup="true" aria-expanded="false" title="Tu cuenta">${esc(initials(quienSoy() || '?'))}</button>`;
}

const quienSoy = () => ME ? ME.nombre : (AGORA_ME?.user?.email || '');

function topbar() {
  $('#tb').innerHTML = `<a class="brand" href="${href(homePath())}" aria-label="Agora Digital App, ir al inicio">${LOGO}<small>Digital App</small></a>
    <span class="crumb-sep" aria-hidden="true">/</span>
    ${crumb()}
    ${LOGO_ESPACIO()}
    ${accountSwitch()}
    <div class="tb-mid">${periodBar()}</div>
    <div class="tb-r">${rightCluster()}</div>`;
  const tabs = ALL().slice(0, 5);
  $('#tabbar').style.setProperty('--tabs', tabs.length);
  $('#tabbar').innerHTML = tabs.map(id => `<a href="${href(MODS[id].path)}" ${id === R.mod ? 'aria-current="page"' : ''}>${icon(MODS[id].icon)}${esc(MODS[id].name.split(' ')[0])}</a>`).join('');
  const abiertas = [
    ME ? `Contratos · ${ROLES[ME.rol]?.l || ME.rol}` : '',
    AGORA_ME ? `Ágora · ${AGORA_ME.user?.role === 'administrator' ? 'administración' : 'equipo'}${ws && ws.name() ? ' · ' + ws.name() : ''}` : '',
  ].filter(Boolean);
  $('#foot').textContent = abiertas.join('   ·   ') || 'Sin sesión';
}

/* ---------- El menú de módulos ---------- */
function moduleMenu() {
  const grupos = Object.keys(GRUPOS).filter(g => ALL().some(k => MODS[k].g === g));
  const col = g => `<div><p class="mdm-gt">${esc(GRUPOS[g].name)}</p>${ALL().filter(k => MODS[k].g === g).map((id, i) => {
    const m = MODS[id], n = m.n ? m.n() : null;
    return `<a class="mdm-i ${id === R.mod ? 'is-on' : ''}" href="${href(m.path)}" data-mod="${id}">
      <span class="mdm-ic" style="--c:${m.c || 'var(--brand)'}">${icon(m.icon)}</span>
      <span class="tx"><b>${esc(m.name)}</b><small>${esc(m.desc || '')}</small></span>
      ${n ? `<b class="nav-b">${int(n)}</b>` : ''}</a>`;
  }).join('')}</div>`;
  const el = openPop($('#b-crumb'), `<div class="mdm-grid">${grupos.map(col).join('')}</div>
    <div class="mdm-ft"><span>Los números del teclado abren los módulos en orden</span><span><kbd>${IS_MAC ? '⌘K' : 'Ctrl K'}</kbd> para buscar</span></div>`, 'mdm');
  if (el) el.setAttribute('role', 'menu');
}

/* ---------- Historial: lo último que se ha visto ---------- */
function anotarHistorial() {
  if (!R.mod) return;
  const m = MODS[R.mod];
  const item = {p: path(), t: m.name, i: m.icon, c: m.c || 'var(--brand)', at: Date.now()};
  const prev = store.get('historial', []).filter(x => x.p !== item.p);
  store.set('historial', [item, ...prev].slice(0, 12));
}
function historialPop() {
  const items = store.get('historial', []).filter(x => x.p !== path());
  const el = openPop($('#b-hist'), items.length
    ? `<p class="mdm-gt">Lo último que has visto</p>${items.slice(0, 8).map(x => `<a class="mdm-i" href="${href(x.p)}"><span class="mdm-ic" style="--c:${x.c}">${icon(x.i)}</span><span class="tx"><b>${esc(x.t)}</b><small>${esc(when(new Date(x.at).toISOString()))}</small></span></a>`).join('')}`
    : '<p class="empty" style="padding:22px 16px"><b>Todavía no hay historial</b>Aquí queda lo último que abras.</p>', 'ctx hist', {align: 'right'});
  if (el) el.setAttribute('role', 'menu');
}

/* ---------- Estado del espacio ---------- */
function estadoPop() {
  const bloqueada = ESPACIO?.bloqueado === true;
  const puede = esSuperAdmin();
  const el = openPop($('#b-estado'), `<div class="est">
      <div class="est-h"><span class="lt ${bloqueada ? 'lt-bad' : 'lt-ok'}"><i aria-hidden="true"></i>${bloqueada ? 'Bloqueada' : 'Activa'}</span></div>
      <p>${bloqueada
        ? 'El equipo ve la pantalla de mantenimiento. Quien administra sigue entrando con normalidad.'
        : 'El equipo entra con normalidad. Al bloquearla, solo quien administra puede seguir trabajando.'}</p>
      ${puede ? `<button class="btn btn-sm ${bloqueada ? 'btn-cta' : 'btn-danger'}" type="button" data-bloqueo>${icon(bloqueada ? 'unlock' : 'lock')}${bloqueada ? 'Reabrir el espacio' : 'Bloquear el espacio'}</button>` : '<p class="src">Solo quien administra puede cambiarlo.</p>'}
    </div>`, 'ctx est', {align: 'right'});
  if (el && puede) el.querySelector('[data-bloqueo]').onclick = async e => {
    const b = e.currentTarget; busy(b, true, 'Guardando…');
    try {
      await agoraApi('admin/maintenance', {method: 'POST', body: {on: !bloqueada}});
      ESPACIO = {...(ESPACIO || {}), bloqueado: !bloqueada};
      closePop(); topbar(); toast(bloqueada ? 'El espacio quedó abierto.' : 'El espacio quedó bloqueado.');
    } catch (x) { busy(b, false); toast(x.message); }
  };
}

/* =====================================================================================
   Athena: el agente, en el panel de la derecha
   -------------------------------------------------------------------------------------
   Lee lo que el sistema ya tiene cargado y responde sobre eso. Cuando el servidor exponga
   el agente de verdad (POST {AGORA_API}athena), basta con cambiar `preguntar`.
   ===================================================================================== */
var athEl = null, athLog = [];
const ATH_SUG = ['¿Cómo vamos este mes?', '¿Quién tiene conversaciones sin leer?', '¿Cuánto llevamos gastado en anuncios?', '¿Qué convenios están por firmar?'];

function abrirAthena(pregunta) {
  if (athEl) { if (!pregunta) return cerrarAthena(); }
  if (!athEl) {
    athEl = document.createElement('div');
    athEl.className = 'ath';
    athEl.setAttribute('role', 'dialog');
    athEl.setAttribute('aria-label', 'Athena');
    athEl.innerHTML = `<div class="ath-h"><span class="mdm-ic" style="--c:var(--deep)">${icon('athena')}</span><div><b>Athena</b><small>Lee tus datos del sistema</small></div><button class="x" type="button" data-ath-close aria-label="Cerrar">${icon('plus')}</button></div>
      <div class="ath-log" id="ath-log"></div>
      <div class="ath-sug" id="ath-sug">${ATH_SUG.map(s => `<button class="btn btn-sm" type="button" data-ath-sug="${esc(s)}">${esc(s)}</button>`).join('')}</div>
      <form class="ath-f"><label class="sr-only" for="ath-in">Pregúntale a Athena</label><input id="ath-in" autocomplete="off" placeholder="Pregúntale sobre tus cifras…"><button class="btn btn-cta" type="submit" aria-label="Enviar">${icon('send')}</button></form>`;
    $('#layer').append(athEl);
    $('#b-ath')?.setAttribute('aria-expanded', 'true');
    athEl.querySelector('[data-ath-close]').onclick = cerrarAthena;
    athEl.querySelector('form').onsubmit = e => { e.preventDefault(); const i = athEl.querySelector('#ath-in'); const t = i.value.trim(); if (!t) return; i.value = ''; decir(t); };
    athEl.querySelectorAll('[data-ath-sug]').forEach(b => b.onclick = () => decir(b.dataset.athSug));
    if (!athLog.length) pintarAthena([{de: 'bot', html: `<p>Hola${ME?.nombre ? ', ' + esc(ME.nombre.split(' ')[0]) : ''}. Leo lo que el sistema tiene cargado y te lo resumo.</p><p>Pregúntame por el mes, por la bandeja, por los anuncios o por los convenios.</p>`}]);
    else pintarAthena();
  }
  if (pregunta) decir(pregunta);
  athEl.querySelector('#ath-in')?.focus({preventScroll: true});
}
function cerrarAthena() {
  if (!athEl) return;
  const e = athEl; athEl = null;
  $('#b-ath')?.setAttribute('aria-expanded', 'false');
  if (reduced()) e.remove(); else { e.classList.add('out'); setTimeout(() => e.remove(), 220); }
}
function pintarAthena(nuevos) {
  if (nuevos) athLog = athLog.concat(nuevos);
  const log = athEl?.querySelector('#ath-log'); if (!log) return;
  log.innerHTML = athLog.map(m => m.de === 'me' ? `<div class="msg me">${esc(m.texto)}</div>` : `<div class="msg bot">${m.html}</div>`).join('');
  log.scrollTop = log.scrollHeight;
}
function decir(texto) {
  pintarAthena([{de: 'me', texto}]);
  const log = athEl.querySelector('#ath-log');
  log.insertAdjacentHTML('beforeend', '<div class="msg bot typing" id="ath-typing"><i></i><i></i><i></i></div>');
  log.scrollTop = log.scrollHeight;
  setTimeout(() => {
    athEl?.querySelector('#ath-typing')?.remove();
    pintarAthena([{de: 'bot', html: responderAthena(texto)}]);
  }, 420);
}
/** La respuesta sale de lo que ya está cargado: nada se inventa ni sale a internet. */
function responderAthena(texto) {
  const q = norm(texto);
  const ir = (p, r) => `<div class="go"><a class="btn btn-sm btn-tint" href="${href(p)}" data-ath-go>${esc(r)}</a></div>`;
  if (/mes|vamos|resumen|negocio|mrr|ingreso/.test(q)) {
    const d = DATOS.resumen;
    if (!d) return `<p>Todavía no he leído el resumen del mes. Abre <b>Resumen</b> y vuelve a preguntarme.</p>${ir('/inicio', 'Abrir Resumen')}`;
    return `<p>En ${esc(mesNombre(PERIODO))} el ingreso recurrente va en <b>${esc(usd(d.mrr))}</b>, con ${int(d.clientesActivos)} cliente${d.clientesActivos === 1 ? '' : 's'} activo${d.clientesActivos === 1 ? '' : 's'}.</p>
      <ul><li>Recaudado: ${esc(usd(d.recaudado))}</li><li>Egresos: ${esc(usd(d.egresos))}</li><li>Saldo de caja: ${esc(usd(d.caja))}</li></ul>
      <p>${Number(d.caja) < 0 ? 'La caja está en negativo: los egresos van por encima de lo cobrado.' : 'La caja está en positivo.'}</p>${ir('/inicio', 'Ver el resumen')}`;
  }
  if (/sin leer|no leida|bandeja|conversacion|sla|respuesta/.test(q)) {
    const d = DATOS.dia;
    if (!d) return `<p>Abre <b>ARP Comercial</b> y vuelvo a mirar las cifras del día.</p>${ir('/comercial', 'Abrir ARP Comercial')}`;
    const peor = (d.sinLeerPorAsesor || []).slice().sort((a, b) => b.n - a.n)[0];
    return `<p>Hoy hay <b>${int(d.sinLeer)}</b> conversaciones sin leer y <b>${int(d.slaIncumplido)}</b> fuera del tiempo de respuesta.</p>
      ${peor ? `<p>Quien más acumula es ${esc(peor.nombre)}, con ${int(peor.n)}.</p>` : ''}
      <p>El tiempo de respuesta promedio va en ${esc(d.slaPromedio)}.</p>${ir('/bandeja', 'Ir a la bandeja')}`;
  }
  if (/anuncio|meta|ads|publicidad|gastado|invers/.test(q)) {
    const a = DATOS.ads;
    if (!a) return `<p>Abre <b>ARP Comercial</b> para que lea la inversión en anuncios.</p>${ir('/comercial', 'Abrir ARP Comercial')}`;
    if (a.estado !== 'ok') return `<p>La conexión con Meta está vencida, así que no puedo darte el gasto de hoy. Hay que volver a conectarla en Ajustes.</p>${ir('/ajustes', 'Ir a Ajustes')}`;
    return `<p>Hoy llevas <b>${esc(usd(a.dia))}</b> invertidos y <b>${esc(usd(a.mes))}</b> en lo que va de ${esc(mesNombre(PERIODO).toLowerCase())}.</p>
      <ul><li>Impresiones: ${int(a.impresiones)}</li><li>Coste por conversión: ${esc(usd(a.costePorConversion))}</li></ul>${ir('/comercial', 'Ver el detalle')}`;
  }
  if (/convenio|contrato|firmar|firmado/.test(q)) {
    const c = DATA.contratos;
    if (!c) return `<p>Abre <b>Contratos</b> y te digo cómo van.</p>${ir('/contratos', 'Abrir Contratos')}`;
    const porFirmar = c.filter(x => x.estado === 'ENVIADO').length, firmados = c.filter(x => x.estado === 'FIRMADO').length;
    return `<p>Hay <b>${int(porFirmar)}</b> convenios por firmar y ${int(firmados)} ya firmados, de ${int(c.length)} en total.</p>${ir('/contratos', 'Ver los convenios')}`;
  }
  if (/tarea|pendiente|recordatorio/.test(q)) {
    const t = (DATOS.tareas || []).filter(x => x.estado !== 'hecha');
    return `<p>Quedan <b>${int(t.length)}</b> tareas abiertas; ${int(t.filter(x => x.vence && x.vence < new Date().toISOString().slice(0, 10)).length)} están vencidas.</p>${ir('/tareas', 'Ver las tareas')}`;
  }
  return `<p>De eso todavía no tengo dato. Puedo con el resumen del mes, la bandeja y el tiempo de respuesta, la inversión en anuncios, los convenios y las tareas.</p>`;
}

/* =====================================================================================
   Puentes de eventos con los módulos de Ágora
   ===================================================================================== */
const AG_TO_MOD = {dashboard: 'comercial', inbox: 'bandeja', contacts: 'contactos', board: 'oportunidades', settings: 'conexiones', help: 'ayuda'};

window.addEventListener('agora:toast', e => toast(String(e.detail || '')));
window.addEventListener('agora:unread', e => { unread = Number(e.detail) || 0; const b = $('#b-crumb .nav-b'); if (b && R.mod === 'bandeja') b.textContent = int(unread); });
window.addEventListener('agora:won-alert', e => { wonPendientes = Number(e.detail?.count) || 0; });
window.addEventListener('agora:goto', e => {
  const d = e.detail || {};
  const mod = AG_TO_MOD[d.view];
  if (!mod || !MODS[mod]?.ok()) return;
  if (ws) ws.pendingFilter = d.filter || null;
  closeAll(); go(MODS[mod].path);
});
window.addEventListener('agora:open-conversation', e => {
  const c = e.detail;
  if (!c?.id || !ws) return;
  ws.pendingConversation = c;
  closeAll(); go('/bandeja');
});
window.addEventListener('agora:logout', () => { AGORA_ME = null; AGORA_CONN = []; unread = 0; if (ws) ws.reset(); });
/* Un recordatorio puesto desde un chat se convierte en tarea: la lista se refresca. */
window.addEventListener('agora:reminder', e => {
  const r = e.detail || {};
  DATOS.tareas = null;
  toast(`Recordatorio puesto para ${esc(r.cuando || 'la fecha elegida')}.`);
});

/* ---------- Controles propios del armazón ---------- */
document.addEventListener('change', e => { if (e.target?.id === 'sub-account') ws?.select(e.target.value); });
document.addEventListener('click', e => {
  const t = e.target;
  if (t?.closest?.('[data-agora-login]')) { closeAll(); agoraLoginModal(); return; }
  if (t?.closest?.('#b-crumb')) { moduleMenu(); return; }
  if (t?.closest?.('#b-hist')) { historialPop(); return; }
  if (t?.closest?.('#b-estado')) { estadoPop(); return; }
  if (t?.closest?.('#b-ath')) { closePop(); abrirAthena(); return; }
  if (t?.closest?.('[data-ath-go]')) { cerrarAthena(); return; }
  const mes = t?.closest?.('[data-mes]');
  if (mes) { ponerPeriodo(mes.dataset.mes); return; }
});

/* =====================================================================================
   Acceso a Ágora
   ===================================================================================== */
function agoraLoginForms() {
  return `<form class="form" data-form="ag-code" novalidate>
      <label class="fld">Correo del equipo<input name="email" type="email" autocomplete="username" placeholder="tu@correo.com"></label>
      <p class="hint">Te llega un código de seis cifras al correo con el que formas parte del equipo.</p>
      <p class="fld-err" role="alert"></p>
      <button class="btn btn-cta" type="submit">Recibir código</button>
    </form>
    <form class="form" data-form="ag-verify" hidden novalidate>
      <input type="hidden" name="email">
      <label class="fld">Código de 6 cifras<input name="code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6"></label>
      <p class="fld-err" role="alert"></p>
      <div class="form-ft" style="justify-content:flex-start"><button class="btn" type="button" data-ag-back>Cambiar de correo</button><button class="btn btn-cta" type="submit">Entrar</button></div>
    </form>
    <details class="ag-admin"><summary>Acceso de administración</summary>
      <form class="form" data-form="ag-admin" novalidate>
        <label class="fld">Correo<input name="email" type="email" autocomplete="username"></label>
        <label class="fld">Contraseña<input name="password" type="password" autocomplete="current-password"></label>
        <p class="fld-err" role="alert"></p>
        <button class="btn btn-cta" type="submit">Entrar como administrador</button>
      </form>
    </details>`;
}
function bindAgoraLogin(root, onDone) {
  const err = (f, m) => { const e = f.querySelector('.fld-err'); if (e) e.textContent = m; };
  const code = root.querySelector('[data-form="ag-code"]');
  const verify = root.querySelector('[data-form="ag-verify"]');
  const admin = root.querySelector('[data-form="ag-admin"]');
  if (code) code.onsubmit = async ev => {
    ev.preventDefault();
    const email = code.email.value.trim(), b = code.querySelector('[type=submit]');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return err(code, 'Escribe un correo válido.');
    busy(b, true, 'Enviando…'); err(code, '');
    try {
      await agoraApi('team-login/request', {method: 'POST', body: {email}});
      code.hidden = true; verify.hidden = false; verify.email.value = email;
      verify.querySelector('[name=code]').focus();
      toast('Código enviado. Revisa tu correo.');
    } catch (x) { err(code, x.message); } finally { busy(b, false); }
  };
  if (verify) {
    verify.onsubmit = async ev => {
      ev.preventDefault();
      const b = verify.querySelector('[type=submit]');
      busy(b, true, 'Entrando…'); err(verify, '');
      try { await agoraApi('team-login/verify', {method: 'POST', body: {email: verify.email.value, code: verify.code.value.trim()}}); await onDone(); }
      catch (x) { busy(b, false); err(verify, x.message); }
    };
    verify.querySelector('[data-ag-back]').onclick = () => { verify.hidden = true; code.hidden = false; err(verify, ''); };
  }
  if (admin) admin.onsubmit = async ev => {
    ev.preventDefault();
    const b = admin.querySelector('[type=submit]');
    busy(b, true, 'Entrando…'); err(admin, '');
    try { await agoraApi('login', {method: 'POST', body: {email: admin.email.value.trim(), password: admin.password.value}}); await onDone(); }
    catch (x) { busy(b, false); err(admin, x.message); }
  };
}
function agoraLoginModal() {
  const s = openModal(modalHead('Entrar en Ágora', 'Para ver el tablero, la bandeja, los contactos y las oportunidades.') + `<div class="ag-login">${agoraLoginForms()}</div><div class="form-ft"><button class="btn" type="button" data-close>Ahora no</button></div>`);
  bindAgoraLogin(s, async () => { closeModal(); await bootAgora(); toast('Sesión de Ágora abierta.'); render(); });
}

/* =====================================================================================
   La subcuenta en uso
   ===================================================================================== */
const agAccountViews = ['ag_dashboard', 'ag_inbox', 'ag_contacts', 'ag_board'];
function accountSwitch() {
  if (!agoraReady() || !AGORA_CONN.length || !agAccountViews.includes(R.view)) return '';
  const una = AGORA_CONN.length === 1;
  return `<label class="tb-acct ${una ? 'single' : ''}" title="Subcuenta en uso"><span>${una ? '' : 'Cuenta'}</span><select id="sub-account" aria-label="Subcuenta en uso" ${una ? 'disabled' : ''}>${AGORA_CONN.map(c => `<option value="${esc(c.id)}" ${String(c.id) === String(ws.current()) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>`;
}

/* =====================================================================================
   Arranque de la sesión de Ágora y de la identidad del espacio
   ===================================================================================== */
async function bootAgora() {
  if (!AG_READY) return;
  try { AGORA_ME = await agoraApi('me'); } catch { AGORA_ME = null; }
  if (!AGORA_ME) { AGORA_CONN = []; ws?.reset(); return; }
  ws.setProfile(AGORA_ME);
  try {
    const {items, reason} = await agoraApi('workspace/connections');
    AGORA_CONN = Array.isArray(items) ? items : [];
    AGORA_REASON = reason || null;
    ws.setConnections(AGORA_CONN, AGORA_REASON);
  } catch { AGORA_CONN = []; ws.setConnections([]); }
  try { AG.startWonAlert(); } catch { /* la alerta nunca estorba */ }
}
/** El nombre y el logo del cliente, que el SuperAdmin sube desde Usuarios y roles. */
async function bootEspacio() {
  try { ESPACIO = await agoraApi('workspace/branding'); }
  catch { ESPACIO = null; }
}
if (ws) ws.onChange(() => {
  try { AG.startWonAlert(); } catch { /* nada */ }
  if (agAccountViews.includes(R.view)) render(); else topbar();
});

/* =====================================================================================
   Módulos propios de Agora Digital App
   -------------------------------------------------------------------------------------
   Resumen (el pulso del negocio), Tareas, Auditoría y Usuarios y roles. Escritos con las
   piezas del sistema de diseño: .hero, .micro, .panel, .bars, .tw, .seg, .lt, svg.chart.

   Cada uno lee su propia ruta del servidor. Las formas de respuesta están documentadas
   en construccion/API.md; mientras el servidor no las tenga, el archivo de pruebas las
   responde con datos inventados.
   ===================================================================================== */

var DATOS = {resumen: null, dia: null, ads: null, eficacia: null, tareas: null, auditoria: null, usuarios: null};

/* ---------- Dinero del negocio: «US$ 285», «−US$ 783» ---------- */
const usd = v => {
  if (v === null || v === undefined || v === '' || !isFinite(Number(v))) return '—';
  const n = Number(v), abs = Math.abs(n);
  const cifra = Math.abs(abs % 1) > 0.004 ? NF.format(abs) : NI.format(Math.round(abs));
  return (n < 0 ? '−' : '') + 'US$ ' + cifra;
};
const firmado = v => (Number(v) > 0 ? '+' : '') + usd(v);

/* ---------- Paleta de los gráficos de reparto ---------- */
const PAL = ['var(--brand)', 'var(--gold)', 'var(--teal)', 'var(--violet)', 'var(--info)', 'var(--deep)', 'var(--muted-2)'];

/**
 * Rueda de reparto con su leyenda al lado. `items`: [{l, n}].
 * Se usa para las conversaciones sin leer por asesor, la fuente de los leads
 * y los leads asignados por usuario.
 */
function donut(items, {centro = '', rotulo = ''} = {}) {
  const lista = (items || []).filter(x => Number(x.n) > 0);
  const suma = lista.reduce((a, b) => a + Number(b.n), 0);
  if (!suma) return `<p class="empty"><b>Sin datos todavía</b>${esc(rotulo || 'No hay nada que repartir en este periodo.')}</p>`;
  const R = 52, C = 2 * Math.PI * R;
  let corrido = 0;
  const arcos = lista.map((it, i) => {
    const largo = (Number(it.n) / suma) * C;
    const arco = `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${PAL[i % PAL.length]}" stroke-width="17" stroke-dasharray="${largo.toFixed(2)} ${(C - largo).toFixed(2)}" stroke-dashoffset="${(-corrido).toFixed(2)}" transform="rotate(-90 70 70)"><title>${esc(it.l)}: ${int(it.n)}</title></circle>`;
    corrido += largo;
    return arco;
  }).join('');
  return `<div class="dn">
    <svg class="dn-svg" viewBox="0 0 140 140" role="img" aria-label="${esc(rotulo || 'Reparto')}: ${lista.map(x => `${x.l}, ${x.n}`).join('; ')}">
      <circle cx="70" cy="70" r="${R}" fill="none" stroke="var(--fill-3)" stroke-width="17"></circle>${arcos}
      <text x="70" y="70" class="dn-c" text-anchor="middle" dominant-baseline="central">${esc(centro || int(suma))}</text>
    </svg>
    <ul class="dn-lg">${lista.map((it, i) => `<li><i style="background:${PAL[i % PAL.length]}" aria-hidden="true"></i><span>${esc(it.l)}</span><b>${int(it.n)}</b></li>`).join('')}</ul>
  </div>`;
}

/** Línea con área, para la evolución del ingreso recurrente. `serie`: [{ym, v}]. */
function lineaArea(serie, {formato = usd} = {}) {
  const pts = (serie || []).filter(p => p && isFinite(Number(p.v)));
  if (pts.length < 2) return `<p class="empty"><b>Hace falta más historia</b>Con un solo mes todavía no hay línea que dibujar.</p>`;
  const W = 620, H = 260, L = 64, Rm = 14, T = 18, B = 34;
  const w = W - L - Rm, h = H - T - B;
  const vals = pts.map(p => Number(p.v));
  const tope = Math.max(...vals), piso = Math.min(0, ...vals);
  const esc10 = v => { const p = 10 ** Math.floor(Math.log10(v || 1)); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; };
  const alto = esc10(tope || 1);
  const x = i => L + (pts.length === 1 ? w / 2 : (i * w) / (pts.length - 1));
  const y = v => T + h - ((v - piso) / ((alto - piso) || 1)) * h;
  let rejilla = '';
  for (let k = 0; k <= 3; k++) {
    const v = piso + ((alto - piso) * k) / 3;
    rejilla += `<line class="gl" x1="${L}" x2="${W - Rm}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke-dasharray="3 5"/><text x="${L - 10}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end">${esc(formato(v))}</text>`;
  }
  const linea = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(Number(p.v)).toFixed(1)}`).join(' ');
  const area = `${linea} L${x(pts.length - 1).toFixed(1)} ${y(piso).toFixed(1)} L${x(0).toFixed(1)} ${y(piso).toFixed(1)} Z`;
  const puntos = pts.map((p, i) => `<circle class="ln-p" cx="${x(i).toFixed(1)}" cy="${y(Number(p.v)).toFixed(1)}" r="5"><title>${esc(mesNombre(p.ym))}: ${esc(formato(Number(p.v)))}</title></circle>`).join('');
  const rotulos = pts.map((p, i) => `<text x="${x(i).toFixed(1)}" y="${H - 10}" text-anchor="middle">${esc(mesCorto(p.ym))}</text>`).join('');
  return `<svg class="chart ln" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución del ingreso recurrente: ${pts.map(p => `${mesCorto(p.ym)}, ${formato(Number(p.v))}`).join('; ')}">
    ${rejilla}<path class="ln-a" d="${area}"/><path class="ln-l" d="${linea}"/>${puntos}${rotulos}</svg>`;
}

/** Barras horizontales con la primitiva del sistema. `items`: [{l, v, texto}]. */
function barras(items) {
  const lista = items || [];
  if (!lista.length) return `<p class="empty"><b>Sin movimiento</b>No hay nada que mostrar en este periodo.</p>`;
  const tope = Math.max(1, ...lista.map(i => Number(i.v) || 0));
  return `<div class="bars">${lista.map(i => `<div class="bar-row"><span class="lab" title="${esc(i.l)}">${esc(i.l)}</span><span class="track"><span class="fill" style="width:${Math.min(100, (100 * (Number(i.v) || 0)) / tope).toFixed(1)}%"></span></span><span class="val">${esc(i.texto)}</span></div>`).join('')}</div>`;
}

/* =====================================================================================
   Resumen · el pulso del negocio
   ===================================================================================== */
const cargarResumen = async (forzar) => {
  if (!forzar && DATOS.resumen && DATOS.resumen.period === PERIODO) return DATOS.resumen;
  const d = await agoraApi(`workspace/resumen?period=${encodeURIComponent(PERIODO)}`);
  DATOS.resumen = {...d, period: PERIODO};
  return DATOS.resumen;
};

V.inicio = {
  need: () => cargarResumen(),
  render() {
    const estado = mesEstado(PERIODO);
    const sello = estado === 'curso' ? '<span class="sc sc-ok">en curso</span>' : estado === 'proximo' ? '<span class="sc sc-info">por delante</span>' : '<span class="sc sc-gray">cerrado</span>';
    const eyebrow = `<span class="mes-sello">${icon('home')}${esc(mesNombre(PERIODO))} · ${sello}</span>`;
    const acts = `<button class="btn btn-tint" type="button" data-informe>${icon('download')}Descargar informe</button>`;
    const cabeza = `<div class="mod-h"><div><p class="t-label">${eyebrow}</p><h1 class="t-module">Resumen</h1><p class="lede">El pulso del negocio: ingreso recurrente, resultado, salud financiera y lo que viene.</p></div><div class="acts">${acts}</div></div>`;
    if (this.error) return cabeza + failed(this.error);
    const d = DATOS.resumen;
    if (!d || d.period !== PERIODO) return cabeza + loading();

    const delta = Number(d.mrr) - Number(d.mrrAnterior || 0);
    const prom = d.clientesActivos ? Number(d.mrr) / Number(d.clientesActivos) : 0;
    const tiles = [
      ['Recaudado en el mes', usd(d.recaudado), 'Pagos recibidos, con IVA'],
      ['Recurrente anual (ARR)', usd(d.arr), 'Ingreso fijo al cierre × 12'],
      [`Saldo de caja ${icon('lock', 'tile-ic')}`, usd(d.caja), 'Automático: cobros − egresos', Number(d.caja) < 0 ? 'bad' : ''],
      ['Clientes activos', int(d.clientesActivos), d.enPausa ? `${int(d.enPausa)} en pausa` : 'Ninguno en pausa'],
      ['Clientes en baja (churn)', int(d.churn), `${esc(pct(d.churnPct))} de la cartera del inicio`],
      ['Egresos del mes', usd(d.egresos), `Incluye ${usd(d.inversion || 0)} de inversión`],
    ];

    const hero = `<section class="hero hero-resumen">
      <div class="hero-split">
        <div class="hero-cifra">
          <p class="t-label">Ingreso recurrente mensual (MRR) al cierre de ${esc(mesNombre(PERIODO).toLowerCase())}</p>
          <p class="t-hero">${esc(usd(d.mrr))}</p>
          <p class="f"><b class="${delta >= 0 ? 'up' : 'down'}">${esc(firmado(delta))}</b> frente al mes anterior. ${int(d.clientesActivos)} cliente${d.clientesActivos === 1 ? '' : 's'} activo${d.clientesActivos === 1 ? '' : 's'}, con un ingreso promedio de ${esc(usd(prom))} por cliente.</p>
        </div>
        <div class="hero-graf">${lineaArea(d.serie)}</div>
      </div>
      <div class="hero-tiles">${tiles.map(([l, v, f, cls]) => `<div class="htile ${cls || ''}"><h3>${l}</h3><p class="v">${esc(v)}</p><span class="f">${f}</span></div>`).join('')}</div>
    </section>`;

    const espacios = (d.espacios || []).length
      ? panel('Espacios atendidos', 'Cada empresa con su identidad, su plan y lo que aporta al mes.',
        `<div class="esp-grid">${d.espacios.map(e => `<article class="esp-card">
            <span class="esp-mark">${e.logo ? `<img src="${esc(e.logo)}" alt="">` : esc(initials(e.nombre))}</span>
            <div class="tx"><b>${esc(e.nombre)}</b><small>${esc(e.plan || 'Sin plan')} · ${esc(usd(e.mrr))} al mes</small></div>
            <span class="lt ${e.estado === 'activo' ? 'lt-ok' : e.estado === 'pausa' ? 'lt-warn' : 'lt-bad'}"><i aria-hidden="true"></i>${esc(e.estado === 'activo' ? 'Activo' : e.estado === 'pausa' ? 'En pausa' : 'De baja')}</span>
          </article>`).join('')}</div>`,
        esSuperAdmin() ? `<a class="btn btn-sm" href="${href('/usuarios')}">${icon('palette')}Identidad y logos</a>` : '')
      : '';

    const responsables = panel('Responsables del espacio', 'Quiénes tienen el control total del sistema.',
      `<ul class="mini-list">${(d.superadmins || []).map(u => `<li><span class="who-cell"><b>${esc(u.nombre)}</b><small>${esc(u.correo)}</small></span><span class="sc sc-info">SuperAdmin</span></li>`).join('') || '<li><span class="muted">Todavía no hay nadie asignado.</span></li>'}</ul>`,
      esSuperAdmin() ? `<a class="btn btn-sm btn-tint" href="${href('/usuarios')}">${icon('plus')}Agregar</a>` : '');

    const porVencer = panel('Lo que viene', 'Cobros por vencer en los próximos treinta días.',
      table([
        {k: 'cliente', l: 'Cliente', f: v => `<b class="strong">${esc(v)}</b>`},
        {k: 'monto', l: 'Monto', n: 1, f: v => esc(usd(v))},
        {k: 'vence', l: 'Vence', f: v => `<span title="${esc(v)}">${esc(fday(v))}</span>`},
        {k: 'estado', l: 'Estado', f: v => v === 'vencido' ? '<span class="sc sc-bad">Vencido</span>' : '<span class="sc sc-gray">Por vencer</span>'},
      ], d.porVencer || [], {empty: '<b>Nada por vencer</b>No hay cobros pendientes en los próximos treinta días.'}));

    return cabeza + hero + `<div class="grid g2 mt">${responsables}${espacios || porVencer}</div>` + (espacios ? `<div class="mt">${porVencer}</div>` : '');
  },
};

/* =====================================================================================
   Tareas · lo que cada ejecutivo tiene pendiente
   ===================================================================================== */
const cargarTareas = async forzar => {
  if (!forzar && DATOS.tareas) return DATOS.tareas;
  const d = await agoraApi(`workspace/tareas?period=${encodeURIComponent(PERIODO)}`);
  DATOS.tareas = Array.isArray(d.items) ? d.items : [];
  DATOS.tareasResumen = d.resumen || null;
  return DATOS.tareas;
};
const tareasPendientes = () => (DATOS.tareas || []).filter(t => t.estado !== 'hecha').length || null;
const hoyYMD = () => new Date().toISOString().slice(0, 10);
const ORIGEN = {recordatorio: 'Recordatorio de chat', manual: 'Creada a mano', sistema: 'Del sistema', convenio: 'Convenio'};

V.tareas = {
  need: () => cargarTareas(),
  render() {
    const st = state.tareas;
    const lede = 'Lo que cada ejecutivo tiene por delante. Los recordatorios que pones en un chat caen aquí solos.';
    const acts = `<button class="btn btn-cta" type="button" data-tarea-nueva>${icon('plus')}Nueva tarea</button>`;
    const cabeza = head('Seguimiento', 'Tareas', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.tareas) return cabeza + loading();

    const todas = DATOS.tareas, hoy = hoyYMD();
    const abiertas = todas.filter(t => t.estado !== 'hecha');
    const vencidas = abiertas.filter(t => t.vence && t.vence < hoy);
    const deHoy = abiertas.filter(t => t.vence === hoy);
    const hechas = todas.filter(t => t.estado === 'hecha');
    const responsables = [...new Set(todas.map(t => t.responsable).filter(Boolean))];

    const q = norm(st.q);
    let filas = todas.filter(t => {
      if (st.estado === 'abiertas' && t.estado === 'hecha') return false;
      if (st.estado === 'vencidas' && !(t.estado !== 'hecha' && t.vence && t.vence < hoy)) return false;
      if (st.estado === 'hoy' && t.vence !== hoy) return false;
      if (st.estado === 'hechas' && t.estado !== 'hecha') return false;
      if (st.resp && t.responsable !== st.resp) return false;
      return !q || norm(`${t.titulo} ${t.contacto || ''} ${t.responsable || ''}`).includes(q);
    });
    filas = sortRows(filas, st);

    const cols = [
      {k: 'titulo', l: 'Tarea', sort: 1, f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(ORIGEN[r.origen] || 'Tarea')}${r.detalle ? ' · ' + esc(r.detalle) : ''}</small></span>`},
      {k: 'contacto', l: 'Contacto', f: (v, r) => v ? `<button class="lnk-btn" type="button" data-tarea-chat="${esc(r.conversationId || '')}" data-contacto="${esc(r.contactId || '')}">${esc(v)}</button>` : '<span class="muted">—</span>'},
      {k: 'responsable', l: 'Responsable', sort: 1, f: v => esc(v || 'Sin asignar')},
      {k: 'vence', l: 'Vence', sort: 1, f: (v, r) => {
        if (!v) return '<span class="muted">Sin fecha</span>';
        const tarde = r.estado !== 'hecha' && v < hoy;
        return `<span class="${tarde ? 'down' : ''}" title="${esc(v)}">${esc(fday(v))}${r.hora ? ' · ' + esc(r.hora) : ''}</span>`;
      }},
      {k: 'estado', l: 'Estado', f: v => v === 'hecha' ? '<span class="lt lt-ok"><i aria-hidden="true"></i>Hecha</span>' : '<span class="lt lt-warn"><i aria-hidden="true"></i>Pendiente</span>'},
      {k: 'id', l: '', cls: 'act', f: (v, r) => r.estado === 'hecha'
        ? `<button class="btn btn-sm" type="button" data-tarea-abrir="${esc(v)}">Reabrir</button>`
        : `<button class="btn btn-sm btn-tint" type="button" data-tarea-hecha="${esc(v)}">${icon('check')}<span>Marcar hecha</span></button>`},
    ];

    return cabeza
      + `<div class="grid g4">
        ${metric('Para hoy', int(deHoy.length), deHoy.length ? 'Escribe o llama hoy mismo' : 'Nada vence hoy', {filter: 'hoy', on: st.estado === 'hoy'})}
        ${metric('Vencidas', int(vencidas.length), vencidas.length ? 'Pasó la fecha y siguen abiertas' : 'Ninguna atrasada', {filter: 'vencidas', on: st.estado === 'vencidas'})}
        ${metric('Abiertas', int(abiertas.length), `${int(todas.length)} en total`, {filter: 'abiertas', on: st.estado === 'abiertas'})}
        ${metric('Hechas', int(hechas.length), 'En este periodo', {filter: 'hechas', on: st.estado === 'hechas'})}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Tarea, contacto o responsable')}
          <label class="fld">Responsable<select data-f="resp"><option value="">Todos</option>${responsables.map(r => `<option value="${esc(r)}" ${st.resp === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
          ${st.q || st.resp || st.estado ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, filas, {sortKey: st.sk, sortDir: st.sd, empty: '<b>No hay tareas con estos filtros</b>Prueba con otro responsable o quita los filtros.'})}
        <p class="src">Los recordatorios que pones desde un chat aparecen aquí y dejan la conversación de primera en la bandeja hasta que escribes.</p></section>`;
  },
};

function tareaModal(previa) {
  const hoy = hoyYMD();
  const s = openModal(modalHead(previa?.titulo ? 'Editar tarea' : 'Nueva tarea', 'Queda a nombre de quien la tiene que hacer, con su fecha.') + `<form class="form" novalidate>
    <label class="fld">¿Qué hay que hacer?<input name="titulo" value="${esc(previa?.titulo || '')}" autofocus placeholder="Llamar para confirmar la inscripción"></label>
    <label class="fld">Detalle (opcional)<input name="detalle" value="${esc(previa?.detalle || '')}" placeholder="Quedó en responder después de hablar con su esposo"></label>
    <div class="grid g2">
      <label class="fld">Fecha<input name="vence" type="date" value="${esc(previa?.vence || hoy)}" min="${hoy}"></label>
      <label class="fld">Hora<input name="hora" type="time" value="${esc(previa?.hora || '09:00')}"></label>
    </div>
    <label class="fld">Responsable<input name="responsable" value="${esc(previa?.responsable || quienSoy())}"></label>
    <p class="fld-err" role="alert"></p>
    <div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">Guardar tarea</button></div></form>`);
  const f = s.querySelector('form');
  f.onsubmit = async ev => {
    ev.preventDefault();
    const fd = Object.fromEntries(new FormData(f)), err = f.querySelector('.fld-err');
    if (!fd.titulo.trim()) { err.textContent = 'Escribe qué hay que hacer.'; return; }
    const b = f.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try {
      await agoraApi('workspace/tareas', {method: 'POST', body: {...fd, origen: previa?.origen || 'manual', contactId: previa?.contactId || null, conversationId: previa?.conversationId || null}});
      closeModal(); await cargarTareas(true); repaint(); toast('Tarea guardada.');
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
async function cambiarTarea(id, estado) {
  try { await agoraApi(`workspace/tareas/${encodeURIComponent(id)}/estado`, {method: 'POST', body: {estado}}); await cargarTareas(true); repaint(); toast(estado === 'hecha' ? 'Tarea marcada como hecha.' : 'Tarea reabierta.'); }
  catch (x) { toast(x.message); }
}

/* =====================================================================================
   Auditoría · la trazabilidad
   ===================================================================================== */
const MODULOS_AUD = {contacto: 'Contactos', conversacion: 'Conversaciones', oportunidad: 'Oportunidades', convenio: 'Contratos', usuario: 'Usuarios', ajuste: 'Ajustes', sesion: 'Acceso'};
const ACCION_TONO = {creo: 'ok', edito: 'info', elimino: 'bad', envio: 'info', firmo: 'ok', entro: 'gray', salio: 'gray', asigno: 'info', exporto: 'warn', bloqueo: 'bad'};
const cargarAuditoria = async forzar => {
  if (!forzar && DATOS.auditoria) return DATOS.auditoria;
  const st = state.auditoria;
  const d = await agoraApi(`workspace/auditoria?period=${encodeURIComponent(PERIODO)}${st.modulo ? '&modulo=' + encodeURIComponent(st.modulo) : ''}`);
  DATOS.auditoria = Array.isArray(d.items) ? d.items : [];
  DATOS.auditoriaResumen = d.resumen || null;
  return DATOS.auditoria;
};

V.auditoria = {
  need: () => cargarAuditoria(),
  render() {
    const st = state.auditoria;
    const lede = 'Quién tocó cada contacto, qué cambió, cuándo y desde dónde. Nada se borra de aquí.';
    const acts = `<button class="btn" type="button" data-aud-exportar>${icon('download')}Exportar</button><button class="btn" type="button" data-aud-recargar>${icon('refresh')}Actualizar</button>`;
    const cabeza = head('Trazabilidad', 'Auditoría', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.auditoria) return cabeza + loading();

    const todos = DATOS.auditoria, hoy = new Date().toDateString();
    const deHoy = todos.filter(e => utc(e.at)?.toDateString() === hoy);
    const contactos = new Set(todos.filter(e => e.contactId).map(e => e.contactId));
    const actores = [...new Set(todos.map(e => e.actor).filter(Boolean))];
    const sensibles = todos.filter(e => ['elimino', 'exporto', 'bloqueo'].includes(e.accion));

    const q = norm(st.q);
    const filas = todos.filter(e => (!st.modulo || e.modulo === st.modulo) && (!st.actor || e.actor === st.actor)
      && (!q || norm(`${e.actor} ${e.objeto || ''} ${e.contacto || ''} ${e.detalle || ''}`).includes(q)));
    const pagina = filas.slice(st.p * 50, st.p * 50 + 50);

    const cols = [
      {k: 'at', l: 'Cuándo', f: v => `<span class="who-cell"><b>${esc(when(v))}</b><small>${esc(fstamp(v))}</small></span>`},
      {k: 'actor', l: 'Quién', f: (v, r) => `<span class="who-cell"><b>${esc(v)}</b><small>${esc(r.rol || '')}</small></span>`},
      {k: 'accion', l: 'Qué hizo', f: (v, r) => `<span class="sc sc-${ACCION_TONO[v] || 'gray'}">${esc(r.accionTexto || v)}</span>`},
      {k: 'modulo', l: 'Módulo', f: v => esc(MODULOS_AUD[v] || v)},
      {k: 'objeto', l: 'Sobre qué', f: (v, r) => r.contacto
        ? `<span class="who-cell"><b>${esc(r.contacto)}</b><small>${esc(v || '')}</small></span>`
        : `<span>${esc(v || '—')}</span>`},
      {k: 'id', l: '', cls: 'act', f: (v, r) => `<button class="btn btn-sm" type="button" data-aud="${esc(v)}">Ver</button>`},
    ];

    return cabeza
      + `<div class="grid g4">
        ${metric('Movimientos hoy', int(deHoy.length), `${int(todos.length)} en ${esc(mesNombre(PERIODO).toLowerCase())}`)}
        ${metric('Contactos tocados', int(contactos.size), 'Fichas con algún cambio')}
        ${metric('Personas activas', int(actores.length), 'Dejaron rastro en el periodo')}
        ${metric('Acciones delicadas', int(sensibles.length), 'Borrados, exportaciones y bloqueos')}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Persona, contacto o detalle')}
          <label class="fld">Módulo<select data-f="modulo"><option value="">Todos</option>${Object.keys(MODULOS_AUD).map(m => `<option value="${m}" ${st.modulo === m ? 'selected' : ''}>${esc(MODULOS_AUD[m])}</option>`).join('')}</select></label>
          <label class="fld">Persona<select data-f="actor"><option value="">Todas</option>${actores.map(a => `<option value="${esc(a)}" ${st.actor === a ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
          ${st.q || st.modulo || st.actor ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, pagina, {empty: '<b>No hay movimientos con estos filtros</b>Prueba con otro módulo o con otra persona.'})}${pager(st, filas.length, 50)}
        <p class="src">El registro se guarda completo en el servidor; aquí se muestran los del periodo elegido.</p></section>`;
  },
};

function auditoriaDetalle(id) {
  const e = (DATOS.auditoria || []).find(x => String(x.id) === String(id));
  if (!e) return;
  const cambios = e.antes || e.despues
    ? `<h4 class="h4">Qué cambió</h4><div class="tw"><table><thead><tr><th>Campo</th><th>Antes</th><th>Después</th></tr></thead><tbody>${
      Object.keys({...(e.antes || {}), ...(e.despues || {})}).map(k => `<tr><td>${esc(k)}</td><td class="muted">${esc(String((e.antes || {})[k] ?? '—'))}</td><td><b class="strong">${esc(String((e.despues || {})[k] ?? '—'))}</b></td></tr>`).join('')
    }</tbody></table></div>` : '';
  openModal(modalHead(esc(e.accionTexto || e.accion), esc(fstamp(e.at)))
    + kv([
      ['Persona', `${esc(e.actor)}${e.rol ? ' · ' + esc(e.rol) : ''}`],
      ['Módulo', esc(MODULOS_AUD[e.modulo] || e.modulo)],
      ['Sobre qué', esc(e.objeto || '—')],
      ['Contacto', e.contacto ? esc(e.contacto) : '—'],
      ['Desde dónde', `${esc(e.dispositivo || 'Desconocido')}${e.ip ? ' · ' + esc(e.ip) : ''}`],
      ['Origen', esc(e.origen === 'ghl' ? 'Go High Level' : e.origen || 'Sistema')],
    ])
    + cambios
    + `<div class="form-ft">${e.contactId ? `<button class="btn btn-tint" type="button" data-aud-contacto="${esc(e.contactId)}">${icon('user')}Abrir la ficha</button>` : ''}<button class="btn" type="button" data-close>Cerrar</button></div>`);
}

/* =====================================================================================
   Usuarios y roles
   ===================================================================================== */
const ROLES_SISTEMA = {
  SUPERADMIN: {l: 'SuperAdmin', d: 'Todo el sistema: espacios, identidad, usuarios y cifras del negocio.', c: 'var(--mod-seguridad)'},
  ADMIN: {l: 'Administración', d: 'Todo lo de su espacio: conexiones, equipo, convenios y tablero.', c: 'var(--brand)'},
  SUPERVISOR: {l: 'Supervisión', d: 'Ve a todo el equipo, reasigna conversaciones y revisa la auditoría.', c: 'var(--mod-azul)'},
  EJECUTIVO: {l: 'Ejecutivo', d: 'Atiende sus conversaciones, sus contactos y sus convenios.', c: 'var(--mod-oro)'},
  CONSULTA: {l: 'Consulta', d: 'Solo mira lo que tiene asignado. No cambia nada.', c: 'var(--muted-2)'},
};
const PERMISOS_MATRIZ = [
  ['Ver el Resumen del negocio', ['SUPERADMIN']],
  ['Agregar espacios y subir su logo', ['SUPERADMIN']],
  ['Crear usuarios y cambiar roles', ['SUPERADMIN', 'ADMIN']],
  ['Conectar cuentas y editar ajustes', ['SUPERADMIN', 'ADMIN']],
  ['Ver la auditoría', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Ver las cifras de todo el equipo', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Reasignar conversaciones', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR']],
  ['Atender conversaciones y contactos', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR', 'EJECUTIVO']],
  ['Crear y enviar convenios', ['SUPERADMIN', 'ADMIN', 'EJECUTIVO']],
  ['Solo consultar', ['SUPERADMIN', 'ADMIN', 'SUPERVISOR', 'EJECUTIVO', 'CONSULTA']],
];
const cargarUsuarios = async forzar => {
  if (!forzar && DATOS.usuarios) return DATOS.usuarios;
  const d = await agoraApi('workspace/usuarios');
  DATOS.usuarios = Array.isArray(d.items) ? d.items : [];
  return DATOS.usuarios;
};

V.usuarios = {
  need: () => Promise.all([cargarUsuarios(), ESPACIO ? Promise.resolve() : bootEspacio()]),
  render() {
    const st = state.usuarios;
    const lede = 'Quién entra al sistema, con qué rol y qué puede hacer. Aquí también vive la identidad del espacio.';
    const acts = esAdmin() ? `<button class="btn btn-cta" type="button" data-usuario-nuevo>${icon('plus')}Agregar persona</button>` : '';
    const cabeza = head('Acceso', 'Usuarios y roles', lede, acts);
    if (this.error) return cabeza + failed(this.error);
    if (!DATOS.usuarios) return cabeza + loading();

    const todos = DATOS.usuarios, activos = todos.filter(u => u.estado !== 'inactivo');
    const q = norm(st.q);
    const filas = todos.filter(u => (!st.rol || u.rol === st.rol) && (!q || norm(`${u.nombre} ${u.correo}`).includes(q)));

    const cols = [
      {k: 'nombre', l: 'Persona', f: (v, r) => `<span class="who-cell"><b>${esc(v)}${r.yo ? ' <span class="sc sc-gray">Tú</span>' : ''}</b><small>${esc(r.correo)}</small></span>`},
      {k: 'rol', l: 'Rol', f: v => `<span class="rol-chip" style="--c:${ROLES_SISTEMA[v]?.c || 'var(--muted)'}">${esc(ROLES_SISTEMA[v]?.l || v)}</span>`},
      {k: 'origen', l: 'De dónde', f: v => esc(v === 'ghl' ? 'Equipo de Go High Level' : v === 'contratos' ? 'Panel de Contratos' : 'Del sistema')},
      {k: 'ultimoAcceso', l: 'Último acceso', f: v => v ? `<span title="${esc(fstamp(v))}">${esc(when(v))}</span>` : '<span class="muted">Nunca</span>'},
      {k: 'estado', l: 'Estado', f: v => v === 'inactivo' ? '<span class="lt lt-bad"><i aria-hidden="true"></i>Desactivada</span>' : '<span class="lt lt-ok"><i aria-hidden="true"></i>Activa</span>'},
      {k: 'id', l: '', cls: 'act', f: (v, r) => esAdmin() && r.origen !== 'ghl' ? `<button class="btn btn-sm" type="button" data-usuario="${esc(v)}" aria-haspopup="true">${icon('more')}<span>Opciones</span></button>` : ''},
    ];

    const identidad = esSuperAdmin() ? panel('Identidad del espacio', 'El logo que verá el cliente en su pantalla de inicio y en la barra.',
      `<div class="ident">
        <div class="ident-prev">${ESPACIO?.logo ? `<img src="${esc(ESPACIO.logo)}" alt="Logo de ${esc(ESPACIO?.nombre || 'la empresa')}">` : `<span class="ident-vacio">${icon('upload')}Sin logo</span>`}</div>
        <form class="form ident-f" novalidate>
          <label class="fld">Nombre de la empresa<input name="nombre" value="${esc(ESPACIO?.nombre || '')}" placeholder="ASOCIM"></label>
          <label class="fld">Logo<input name="logo" type="file" accept="image/png,image/jpeg,image/webp"><small class="hint">PNG, JPG o WebP. Se ve mejor con el fondo transparente y al menos 240 px de ancho.</small></label>
          <p class="fld-err" role="alert"></p>
          <div class="form-ft" style="justify-content:flex-start"><button class="btn btn-cta" type="submit">Guardar identidad</button>${ESPACIO?.logo ? '<button class="btn" type="button" data-logo-quitar>Quitar el logo</button>' : ''}</div>
        </form>
      </div>`) : '';

    const matriz = panel('Qué puede hacer cada rol', 'La misma regla vale en todos los módulos.',
      `<div class="tw full"><table class="matriz"><thead><tr><th>Puede</th>${Object.keys(ROLES_SISTEMA).map(r => `<th class="n">${esc(ROLES_SISTEMA[r].l)}</th>`).join('')}</tr></thead>
        <tbody>${PERMISOS_MATRIZ.map(([q2, roles]) => `<tr><td>${esc(q2)}</td>${Object.keys(ROLES_SISTEMA).map(r => `<td class="n">${roles.includes(r) ? `<span class="si" title="Sí">${icon('check')}</span>` : '<span class="no" aria-label="No">·</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);

    return cabeza
      + `<div class="grid g4">
        ${metric('Personas activas', int(activos.length), `${int(todos.length - activos.length)} desactivada${todos.length - activos.length === 1 ? '' : 's'}`)}
        ${['SUPERADMIN', 'ADMIN', 'EJECUTIVO'].map(r => metric(ROLES_SISTEMA[r].l, int(activos.filter(u => u.rol === r).length), ROLES_SISTEMA[r].d, {filter: r, on: st.rol === r})).join('')}
      </div>`
      + `<section class="panel mt"><div class="tools">${searchFld(st.q, 'Nombre o correo')}${st.q || st.rol ? '<button class="btn clear" type="button" data-clear>Quitar filtros</button>' : ''}</div>
        ${table(cols, filas, {empty: '<b>Nadie coincide</b>Prueba con otro nombre o quita los filtros.'})}</section>`
      + (identidad ? `<div class="mt">${identidad}</div>` : '')
      + `<div class="mt">${matriz}</div>`;
  },
};

function usuarioModal(previo) {
  const roles = Object.keys(ROLES_SISTEMA).filter(r => r !== 'SUPERADMIN' || esSuperAdmin());
  const s = openModal(modalHead(previo ? 'Cambiar rol' : 'Agregar persona', previo ? esc(previo.nombre) : 'Entra con su correo y la clave temporal que le compartas.')
    + `<form class="form" novalidate>
      ${previo ? '' : `<label class="fld">Nombre completo<input name="nombre" autofocus></label><label class="fld">Correo<input name="correo" type="email"></label>
      <label class="fld">Clave temporal (mínimo 12 caracteres)<span class="pw-in"><input name="clave" value="${claveAzar()}" autocomplete="off"><button class="pw-eye" type="button" data-regen>Otra</button></span></label>`}
      <div class="seg-fld">Rol${seg('rol-sys', roles.map(r => [r, ROLES_SISTEMA[r].l]), previo?.rol || 'EJECUTIVO', 'Rol')}</div>
      <ul class="role-help">${roles.map(r => `<li><span class="rol-punto" style="--c:${ROLES_SISTEMA[r].c}"></span><span><b class="strong">${esc(ROLES_SISTEMA[r].l)}:</b> ${esc(ROLES_SISTEMA[r].d)}</span></li>`).join('')}</ul>
      <p class="fld-err" role="alert"></p>
      <div class="form-ft"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-cta" type="submit">${previo ? 'Guardar rol' : 'Agregar persona'}</button></div></form>`);
  const f = s.querySelector('form');
  s.querySelector('[data-regen]')?.addEventListener('click', () => { f.clave.value = claveAzar(); });
  f.onsubmit = async ev => {
    ev.preventDefault();
    const fd = Object.fromEntries(new FormData(f)), err = f.querySelector('.fld-err');
    fd.rol = f.querySelector('[data-seg="rol-sys"] .is-on')?.dataset.v || 'EJECUTIVO';
    if (!previo) {
      if (!String(fd.nombre || '').trim() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(fd.correo || '').trim())) { err.textContent = 'Escribe el nombre y un correo válido.'; return; }
      if (String(fd.clave || '').length < 12) { err.textContent = 'La clave temporal debe tener al menos 12 caracteres.'; return; }
    }
    const b = f.querySelector('[type=submit]'); busy(b, true, 'Guardando…');
    try {
      if (previo) await agoraApi('workspace/usuarios/rol', {method: 'POST', body: {id: previo.id, rol: fd.rol}});
      else await agoraApi('workspace/usuarios', {method: 'POST', body: fd});
      closeModal(); await cargarUsuarios(true); repaint();
      if (previo) toast('Rol actualizado.');
      else openModal(modalHead('Persona agregada', `Comparte la clave con ${esc(fd.nombre)} por un canal seguro. Se le pedirá cambiarla.`) + `<div class="secret"><code>${esc(fd.clave)}</code><button class="btn btn-sm btn-cta" type="button" data-copy="${esc(fd.clave)}">Copiar</button></div><p class="src">Correo para entrar: ${esc(fd.correo)}</p><div class="form-ft"><button class="btn" type="button" data-close>Listo</button></div>`);
    } catch (x) { busy(b, false); err.textContent = x.message; }
  };
}
function usuarioMenu(id, ancla) {
  const u = (DATOS.usuarios || []).find(x => String(x.id) === String(id));
  if (!u) return;
  const el = openPop(ancla, `<button type="button" data-u="rol">${icon('shield')}Cambiar rol</button>${u.estado === 'inactivo' ? `<button type="button" data-u="on">${icon('check')}Reactivar</button>` : `<button type="button" data-u="off">${icon('pause')}Desactivar</button>`}`, 'ctx', {align: 'right'});
  if (!el) return;
  el.setAttribute('role', 'menu');
  el.onclick = async e => {
    const a = e.target.closest('[data-u]')?.dataset.u; if (!a) return; closePop();
    if (a === 'rol') return usuarioModal(u);
    const estado = a === 'off' ? 'inactivo' : 'activo';
    confirmModal(a === 'off' ? 'Desactivar persona' : 'Reactivar persona',
      a === 'off' ? `${esc(u.nombre)} dejará de entrar al sistema. Puedes reactivarla cuando quieras.` : `${esc(u.nombre)} podrá entrar otra vez.`,
      a === 'off' ? 'Desactivar' : 'Reactivar',
      async () => { await agoraApi('workspace/usuarios/estado', {method: 'POST', body: {id: u.id, estado}}); await cargarUsuarios(true); repaint(); toast(a === 'off' ? 'Persona desactivada.' : 'Persona reactivada.'); },
      a === 'off');
  };
}
/** El logo del cliente: se lee en el navegador y se manda al servidor junto al nombre. */
async function guardarIdentidad(form) {
  const err = form.querySelector('.fld-err'), b = form.querySelector('[type=submit]');
  const archivo = form.logo.files?.[0];
  let logo = ESPACIO?.logo || null;
  if (archivo) {
    if (archivo.size > 400 * 1024) { err.textContent = 'El logo debe pesar menos de 400 KB.'; return; }
    logo = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(archivo); });
  }
  busy(b, true, 'Guardando…'); err.textContent = '';
  try {
    const d = await agoraApi('workspace/branding', {method: 'POST', body: {nombre: form.nombre.value.trim(), logo}});
    ESPACIO = {...(ESPACIO || {}), ...d, nombre: form.nombre.value.trim(), logo};
    topbar(); repaint(); toast('Identidad guardada.');
  } catch (x) { busy(b, false); err.textContent = x.message; }
}

/* =====================================================================================
   Lo que el tablero comercial necesita del armazón
   -------------------------------------------------------------------------------------
   Los módulos de Ágora van en otro paquete, así que las piezas de dibujo y el formato
   del dinero se les prestan por aquí. También guardan lo que leen, para que Athena pueda
   responder sobre ello sin volver a preguntarle al servidor.
   ===================================================================================== */
window.AgoraUI = {
  donut, barras, lineaArea, usd, firmado, mesNombre, mesCorto,
  guardarDia: d => { DATOS.dia = d; },
  guardarAds: a => { DATOS.ads = a; },
  guardarEficacia: e => { DATOS.eficacia = e; },
};

/* =====================================================================================
   Eventos de los módulos nuevos
   ===================================================================================== */
document.addEventListener('click', e => {
  const t = e.target, c = s => t.closest?.(s);
  let el;
  if (c('[data-tarea-nueva]')) { tareaModal(); return; }
  if ((el = c('[data-tarea-hecha]'))) { cambiarTarea(el.dataset.tareaHecha, 'hecha'); return; }
  if ((el = c('[data-tarea-abrir]'))) { cambiarTarea(el.dataset.tareaAbrir, 'pendiente'); return; }
  if ((el = c('[data-tarea-chat]'))) {
    const id = el.dataset.tareaChat;
    if (id && ws) { ws.pendingConversation = {id, explicit: true}; go('/bandeja'); }
    else go('/con-convenio');
    return;
  }
  if ((el = c('[data-aud]'))) { auditoriaDetalle(el.dataset.aud); return; }
  if (c('[data-aud-recargar]')) { DATOS.auditoria = null; render(); return; }
  if (c('[data-aud-exportar]')) { exportarAuditoria(); return; }
  if ((el = c('[data-aud-contacto]'))) { closeModal(); go('/con-convenio'); return; }
  if (c('[data-usuario-nuevo]')) { usuarioModal(); return; }
  if ((el = c('[data-usuario]'))) { usuarioMenu(el.dataset.usuario, el); return; }
  if (c('[data-logo-quitar]')) {
    confirmModal('Quitar el logo', 'El espacio volverá a mostrar solo el nombre.', 'Quitar', async () => {
      await agoraApi('workspace/branding', {method: 'POST', body: {nombre: ESPACIO?.nombre || '', logo: null}});
      ESPACIO = {...(ESPACIO || {}), logo: null}; topbar(); repaint(); toast('Logo quitado.');
    }, true);
    return;
  }
  if (c('[data-informe]')) { descargarInforme(); return; }
});
document.addEventListener('submit', e => {
  const f = e.target.closest('.ident-f');
  if (!f) return;
  e.preventDefault();
  guardarIdentidad(f);
});

/** El informe del mes, en un archivo que se abre en cualquier hoja de cálculo. */
function descargarInforme() {
  const d = DATOS.resumen;
  if (!d) { toast('Todavía no hay cifras que llevar al informe.'); return; }
  const filas = [
    ['Periodo', mesNombre(PERIODO)],
    ['Ingreso recurrente mensual (MRR)', d.mrr],
    ['Mes anterior', d.mrrAnterior],
    ['Recurrente anual (ARR)', d.arr],
    ['Recaudado en el mes', d.recaudado],
    ['Egresos del mes', d.egresos],
    ['Saldo de caja', d.caja],
    ['Clientes activos', d.clientesActivos],
    ['Clientes en baja', d.churn],
  ];
  bajarCsv(`resumen-${PERIODO}.csv`, [['Concepto', 'Valor'], ...filas]);
}
function exportarAuditoria() {
  const items = DATOS.auditoria || [];
  if (!items.length) { toast('No hay movimientos que exportar.'); return; }
  bajarCsv(`auditoria-${PERIODO}.csv`, [
    ['Fecha', 'Persona', 'Rol', 'Acción', 'Módulo', 'Sobre qué', 'Contacto', 'Desde dónde'],
    ...items.map(e => [fstamp(e.at), e.actor, e.rol || '', e.accionTexto || e.accion, MODULOS_AUD[e.modulo] || e.modulo, e.objeto || '', e.contacto || '', `${e.dispositivo || ''} ${e.ip || ''}`.trim()]),
  ]);
}
function bajarCsv(nombre, filas) {
  const texto = filas.map(f => f.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['﻿' + texto], {type: 'text/csv;charset=utf-8'}));
  a.download = nombre;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast('Archivo descargado.');
}

/* =====================================================================================
   Arranque: ¿qué sesiones hay abiertas?
   ===================================================================================== */
async function bootContratos() {
  try { ME = (await api('yo')).usuario || null; } catch { ME = null; }
  if (!ME) DATA.reset();
}
applyTheme();
if (AG_READY && window.AGORA_MAINTENANCE !== false) { try { AG.installMaintenance(); } catch { /* sin vigilancia */ } }
(async () => {
  await Promise.all([bootContratos(), bootAgora()]);
  if (ME || AGORA_ME) await bootEspacio();
  const p = path();
  if (!ME && !AGORA_ME) {
    if (p !== '/entrar') { store.set('volver', p); history.replaceState(null, '', HASH ? location.pathname + '#/entrar' : '/entrar'); }
  } else if (p === '/entrar' || p === '/') {
    const back = store.get('volver', ''); store.set('volver', '');
    const target = back && back !== '/entrar' && back !== '/' ? back : homePath();
    history.replaceState(null, '', HASH ? location.pathname + '#' + target : target);
  }
  render();
})();
})();
