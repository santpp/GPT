/* =====================================================================================
   Agora Digital App · datos de prueba
   -------------------------------------------------------------------------------------
   Esto NO va en el servidor. Sirve para recorrer todos los módulos sin servidor ninguno:
   se pone delante de fetch y responde las rutas de los dos sistemas con datos inventados.

   Las respuestas tienen la misma forma que las de verdad, así que lo que se ve aquí es
   lo que se verá en producción. Lo que se escribe queda en memoria: al recargar vuelve
   al punto de partida.

   Para probar contra los servidores de verdad, basta con no cargar este archivo.
   ===================================================================================== */
(() => {
  const nativeFetch = window.fetch.bind(window);
  const DAY = 86400000;
  const ahora = Date.now();
  /* El servidor de Contratos guarda la hora en UTC, con espacio en vez de «T». */
  const utcStamp = ms => new Date(ms).toISOString().replace('T', ' ').slice(0, 19);
  const isoStamp = ms => new Date(ms).toISOString();
  const ymd = ms => new Date(ms).toISOString().slice(0, 10);
  const mesActual = new Date().toISOString().slice(0, 7);

  /* =====================================================================================
     Datos de Contratos (ASOCIM)
     ===================================================================================== */
  const yo = {id: 1, nombre: 'Eduardo Bocaranda', correo: 'info@agoradigital.app', rol: 'ADMIN'};

  const uid = n => String(n).padStart(24, 'a1b2c3d4e5f60718293a4b5c').slice(-24);
  let seq = 1;
  const nuevoUid = () => uid('f0e1d2c3b4a5' + String(++seq).padStart(12, '0'));

  const CLIENTES = [
    ['Mariana Pérez Alvarado', 'mariana.perez@gmail.com', 'V-18456321', '+58 412 1122334'],
    ['Luis Alberto Ramírez', 'luis.ramirez@hotmail.com', 'V-14223877', '+58 414 5566778'],
    ['Carla Sofía Montes', 'carla.montes@gmail.com', 'V-21998455', '+58 424 9988776'],
    ['José Gregorio Díaz', 'jose.diaz@outlook.com', 'V-11234567', '+58 416 2233445'],
    ['Andreína Castillo', 'andreina.castillo@gmail.com', 'V-23445566', '+58 412 6677889'],
    ['Pedro Luis Hernández', 'pedro.hernandez@gmail.com', 'V-16778899', '+58 426 1234567'],
    ['Yoselin Guerrero', 'yoselin.guerrero@gmail.com', 'V-25667788', '+58 414 7654321'],
    ['Rafael Ángel Sánchez', 'rafael.sanchez@gmail.com', 'V-12998877', '+58 424 3344556'],
  ];
  const ESTADOS = ['FIRMADO', 'ENVIADO', 'BORRADOR', 'FIRMADO', 'ENVIADO', 'FIRMADO', 'BORRADOR', 'REVOCADA', 'FIRMADO', 'ENVIADO', 'BORRADOR', 'FIRMADO'];

  let contratos = ESTADOS.map((estado, i) => {
    const [cliente, correo] = CLIENTES[i % CLIENTES.length];
    return {
      uid: uid('c0ffee' + String(i + 1).padStart(18, '0')),
      cliente, correo, estado,
      version: i === 7 ? 2 : 1,
      creado_en: utcStamp(ahora - (i * 2.4 + 0.3) * DAY),
    };
  });

  /* El detalle se calcula a partir de la fila, para que cuadre con lo que se ve en la lista. */
  const cuotasDe = (cuota, meses, desde, porMes) => {
    const out = [];
    let n = 0;
    for (let m = 1; m <= meses; m++) {
      const base = new Date(desde.getFullYear(), desde.getMonth() + m - 1, 1);
      const dias = porMes === 1 ? [30] : porMes === 2 ? [15, 30] : [7, 14, 21, 28];
      for (const d of dias) {
        n++;
        const ultimo = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate();
        out.push({numero: n, mes: m, vencimiento: ymd(new Date(base.getFullYear(), base.getMonth(), Math.min(d, ultimo)).getTime()), monto: (cuota / porMes).toFixed(2)});
      }
    }
    return out;
  };
  function detalleDe(row) {
    const i = contratos.findIndex(c => c.uid === row.uid);
    const persona = CLIENTES[i % CLIENTES.length];
    const cuota = [150, 180, 120, 200, 165][i % 5];
    const meses = [12, 10, 12, 6, 12][i % 5];
    const porMes = [1, 1, 2, 1, 1][i % 5];
    const desde = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1);
    const cuotas = cuotasDe(cuota, meses, desde, porMes);
    const precio = cuota * meses;
    const inscripcion = 60;
    return {
      uid: row.uid, version: row.version, estado: row.estado, descuento: '5',
      cliente: {nombre: persona[0], cedula: persona[2], telefono: persona[3], correo: persona[1]},
      calculo: {
        precio_curso: precio.toFixed(2),
        cargos: [{concepto: 'Inscripción', monto: inscripcion.toFixed(2)}],
        total_a_pagar: (precio + inscripcion).toFixed(2),
        cuotas,
      },
      enlace: row.estado === 'ENVIADO' ? 'https://contratos.asocim.org/firmar/9f2b7c4e1a8d3056bb11' : null,
      enlace_guardable: true,
      pdfs: {enviado: row.estado !== 'BORRADOR', firmado: row.estado === 'FIRMADO'},
    };
  }

  let usuarios = [
    {id: 1, nombre: 'Eduardo Bocaranda', correo: 'info@agoradigital.app', rol: 'ADMIN', activo: 1},
    {id: 2, nombre: 'Rosa Natalia Ortega', correo: 'rortega@asocim.org', rol: 'REMITENTE', activo: 1},
    {id: 3, nombre: 'Daniel Figueroa', correo: 'dfigueroa@asocim.org', rol: 'REMITENTE', activo: 1},
    {id: 4, nombre: 'Marisol Vera', correo: 'mvera@asocim.org', rol: 'VISOR', activo: 1},
    {id: 5, nombre: 'Jhonny Arteaga', correo: 'jarteaga@asocim.org', rol: 'REMITENTE', activo: 0},
  ];

  let eventos = [
    {tipo: 'FIRMADO', cliente: 'Mariana Pérez Alvarado', uid: contratos[0].uid, creado_en: utcStamp(ahora - 0.1 * DAY), detalle: {version: 1}},
    {tipo: 'ENVIADO', cliente: 'Luis Alberto Ramírez', uid: contratos[1].uid, creado_en: utcStamp(ahora - 0.4 * DAY), detalle: {version: 1, vence: ymd(ahora + 7 * DAY)}},
    {tipo: 'CREADO', cliente: 'Carla Sofía Montes', uid: contratos[2].uid, creado_en: utcStamp(ahora - 0.8 * DAY), detalle: {origen: 'ghl'}},
    {tipo: 'FIRMADO', cliente: 'José Gregorio Díaz', uid: contratos[3].uid, creado_en: utcStamp(ahora - 1.2 * DAY), detalle: {version: 1}},
    {tipo: 'ENLACE_NUEVO', cliente: 'Andreína Castillo', uid: contratos[4].uid, creado_en: utcStamp(ahora - 1.6 * DAY), detalle: {motivo: 'a_peticion'}},
    {tipo: 'NUEVA_VERSION', cliente: 'Rafael Ángel Sánchez', uid: contratos[7].uid, creado_en: utcStamp(ahora - 2.1 * DAY), detalle: {version: 2, anterior: 'ENVIADO'}},
    {tipo: 'REVOCADO', cliente: 'Rafael Ángel Sánchez', uid: contratos[7].uid, creado_en: utcStamp(ahora - 2.2 * DAY), detalle: {motivo: 'datos_incorrectos'}},
    {tipo: 'CLIENTE_EDITADO', cliente: 'Pedro Luis Hernández', uid: contratos[5].uid, creado_en: utcStamp(ahora - 3 * DAY), detalle: {}},
    {tipo: 'FIRMADO', cliente: 'Yoselin Guerrero', uid: contratos[8].uid, creado_en: utcStamp(ahora - 4.4 * DAY), detalle: {version: 1}},
    {tipo: 'ENVIADO', cliente: 'Andreína Castillo', uid: contratos[9].uid, creado_en: utcStamp(ahora - 5.2 * DAY), detalle: {version: 1}},
    {tipo: 'CREADO', cliente: 'Pedro Luis Hernández', uid: contratos[10].uid, creado_en: utcStamp(ahora - 6.1 * DAY), detalle: {origen: 'ghl'}},
    {tipo: 'ENLACES_REVOCADOS', cliente: 'Carla Sofía Montes', uid: contratos[2].uid, creado_en: utcStamp(ahora - 7.3 * DAY), detalle: {}},
  ];

  const CONTACTOS_GHL = [
    {id: 'ct_8812', nombre: 'Génesis Carolina Mora', correo: 'genesis.mora@gmail.com', telefono: '+58 412 8812233', cedula: 'V-27881122'},
    {id: 'ct_4471', nombre: 'Héctor Javier Pino', correo: 'hector.pino@gmail.com', telefono: '+58 424 4471188', cedula: 'V-19447118'},
    {id: 'ct_9032', nombre: 'Dayana Michelle Rojas', correo: 'dayana.rojas@hotmail.com', telefono: '+58 414 9032255', cedula: ''},
    {id: 'ct_1150', nombre: 'Mariana Pérez Alvarado', correo: 'mariana.perez@gmail.com', telefono: '+58 412 1122334', cedula: 'V-18456321'},
    {id: 'ct_7765', nombre: 'Wilmer Antonio Salas', correo: 'wilmer.salas@gmail.com', telefono: '+58 426 7765099', cedula: 'V-13776509'},
  ];

  /* =====================================================================================
     Datos de Ágora (CRM)
     ===================================================================================== */
  const agoraMe = {
    user: {id: 1, email: 'info@agoradigital.app', role: 'administrator', identity_type: 'native', capabilities: {viewConversations: true, sendMessages: true, assignedDataOnly: false}},
    csrf: 'demo-csrf-token', locked: false, passkeys: 0, lockMinutes: null,
  };
  const conexiones = [
    {id: 1, name: 'ASOCIM · Admisiones', currency: 'USD', status: 'connected', location_id: 'loc_A7K2M9', sync_interval_seconds: 300, last_checked_at: utcStamp(ahora - 0.02 * DAY), sync_enabled: 1, last_success_at: utcStamp(ahora - 0.01 * DAY), externalUsers: 6, users_last_success_at: utcStamp(ahora - 0.5 * DAY), whatsapp_number_id: '10928371', accessChannel: true, currency_code: 'USD', unread_reminder_minutes: 10, won_alert_days: 7},
    {id: 2, name: 'StreamingNet · Ventas', currency: 'USD', status: 'connected', location_id: 'loc_S4N8P1', sync_interval_seconds: 300, last_checked_at: utcStamp(ahora - 0.05 * DAY), sync_enabled: 1, last_success_at: utcStamp(ahora - 0.03 * DAY), externalUsers: 4, users_last_success_at: utcStamp(ahora - 0.7 * DAY), whatsapp_number_id: null, unread_reminder_minutes: 15, won_alert_days: 7},
  ];
  const EQUIPO = [
    {id: 'us_01', name: 'Rosa Natalia Ortega', email: 'rortega@asocim.org'},
    {id: 'us_02', name: 'Daniel Figueroa', email: 'dfigueroa@asocim.org'},
    {id: 'us_03', name: 'Yarelis Mendoza', email: 'ymendoza@asocim.org'},
    {id: 'us_04', name: 'Jhonny Arteaga', email: 'jarteaga@asocim.org'},
  ];

  const CANALES = ['TYPE_WHATSAPP', 'TYPE_INSTAGRAM', 'TYPE_EMAIL', 'TYPE_SMS', 'TYPE_FACEBOOK'];
  const PREVIAS = [
    'Buenas tardes, quisiera saber si todavía hay cupos para el diplomado.',
    '¿El pago se puede hacer en dos partes? Me interesa empezar en enero.',
    'Listo, ya hice la transferencia. Les envío el comprobante.',
    'Gracias por la información, lo converso en casa y le escribo.',
    '¿Las clases son en línea o presenciales los sábados?',
    'Buenos días, ¿me pueden reenviar el enlace del convenio?',
    'Perfecto, quedo pendiente del correo con el convenio.',
    '¿Cuánto cuesta la inscripción aparte de la cuota mensual?',
  ];
  let conversaciones = PREVIAS.map((body, i) => ({
    id: 'cv_' + (1001 + i),
    contactId: 'ct_' + (7001 + i),
    contactName: CLIENTES[i % CLIENTES.length][0],
    lastMessageBody: body,
    lastMessageType: CANALES[i % CANALES.length],
    lastMessageDirection: i % 3 === 2 ? 'outbound' : 'inbound',
    lastMessageDate: isoStamp(ahora - (i * 37 + 8) * 60000),
    unreadCount: i < 3 ? [2, 1, 3][i] : 0,
    assignedTo: i % 2 ? 'us_01' : 'us_02',
  }));

  const mensajesDe = id => {
    const i = conversaciones.findIndex(c => c.id === id);
    const c = conversaciones[i] || conversaciones[0];
    const t = Date.parse(c.lastMessageDate);
    const guion = [
      ['inbound', 'Buenas, vi la publicación del diplomado en Instagram y quiero más información.'],
      ['outbound', '¡Hola! Con gusto. El diplomado dura 12 meses, con clases los sábados y acompañamiento en línea. La cuota mensual es de 150,00 y la inscripción, 60,00.'],
      ['inbound', '¿El pago se puede hacer en dos partes?'],
      ['outbound', 'Sí: podemos dividir la cuota en dos pagos al mes, el 15 y el 30. Te preparo el convenio con ese plan y te llega por correo para firmarlo.'],
      ['inbound', c.lastMessageBody],
    ];
    return guion.map(([direction, body], n) => ({
      id: `${c.id}_m${n + 1}`,
      body,
      direction,
      messageType: c.lastMessageType,
      status: direction === 'outbound' ? 'delivered' : 'received',
      dateAdded: isoStamp(t - (guion.length - n - 1) * 26 * 60000),
    }));
  };

  const CONTACTOS_AG = CLIENTES.map(([name, email, cedula, phone], i) => ({
    id: 'ct_' + (7001 + i), name, email, phone,
    companyName: i % 3 === 0 ? 'Particular' : '',
    tags: [['interesado', 'diplomado'], ['convenio', 'firmado'], ['seguimiento'], ['instagram'], ['convenio'], ['frío'], ['referido'], ['interesado']][i] || [],
    assignedTo: i % 2 ? 'us_01' : 'us_02',
    assignedName: i % 2 ? 'Rosa Natalia Ortega' : 'Daniel Figueroa',
    country: 'Venezuela', timezone: 'America/Caracas',
    source: ['Instagram', 'Facebook', 'Referido', 'Sitio web'][i % 4],
    dnd: false,
    customFields: [{id: 'cf_ced', name: 'Cédula', value: cedula}, {id: 'cf_pro', name: 'Programa de interés', value: 'Diplomado en Componente Docente'}],
  }));

  const ETAPAS = [
    {id: 'st_1', name: 'Nuevo interesado'},
    {id: 'st_2', name: 'En conversación'},
    {id: 'st_3', name: 'Convenio enviado'},
    {id: 'st_4', name: 'Cierre'},
  ];
  const EMBUDOS = [
    {id: 'pl_1', name: 'Admisiones 2026', stages: ETAPAS},
    {id: 'pl_2', name: 'Reinscripciones', stages: ETAPAS.slice(0, 3)},
  ];
  let oportunidades = CLIENTES.map(([name], i) => ({
    id: 'op_' + (3001 + i),
    name: 'Diplomado · ' + name.split(' ')[0] + ' ' + name.split(' ')[1],
    contactName: name,
    monetaryValue: [1860, 0, 1440, 2160, 1860, 1320, 1860, 0][i],
    pipelineId: 'pl_1',
    pipelineStageId: ETAPAS[i % 4].id,
    assignedTo: i % 2 ? 'us_01' : 'us_02',
    assignedName: i % 2 ? 'Rosa Natalia Ortega' : 'Daniel Figueroa',
    status: i % 4 === 3 ? 'won' : 'open',
    wonAt: i % 4 === 3 ? isoStamp(ahora - (i + 1) * 1.5 * DAY) : null,
  }));

  const tablero = (from, to) => ({
    restricted: false,
    readAt: isoStamp(ahora),
    conversations: {total: conversaciones.length, unread: conversaciones.reduce((s, c) => s + c.unreadCount, 0), waiting: conversaciones.filter(c => c.lastMessageDirection !== 'outbound').length},
    contacts: CONTACTOS_AG.length + 136,
    leads: {today: 7, mine: 3, linked: true},
    opportunities: {
      count: oportunidades.filter(o => o.status === 'open').length,
      value: oportunidades.filter(o => o.status === 'open').reduce((s, o) => s + o.monetaryValue, 0),
      sampled: false,
      stages: ETAPAS.map((s, i) => ({
        name: s.name,
        count: oportunidades.filter(o => o.pipelineStageId === s.id && o.status === 'open').length,
        value: oportunidades.filter(o => o.pipelineStageId === s.id && o.status === 'open').reduce((a, o) => a + o.monetaryValue, 0),
      })),
    },
    from, to,
  });

  let cifrasMes = {otherAds: 120, fixedCosts: 1800, teamGoal: 14000, closingWord: 'cierres', green: 100, amber: 70, goals: {us_01: 5000, us_02: 4500, us_03: 3000, us_04: 1500}};
  const mesBloque = period => {
    const ventas = {closings: 9, total: 13260, counted: 9, partial: false};
    const ads = 2340 + Number(cifrasMes.otherAds || 0);
    const comisiones = ventas.total * 0.1;
    const ganancia = ventas.total - ads - comisiones;
    const equipo = EQUIPO.map((u, i) => {
      const vendido = [5200, 4100, 2960, 1000][i];
      const meta = Number(cifrasMes.goals[u.id]) || null;
      const avance = meta ? (vendido / meta) * 100 : null;
      return {
        id: u.id, name: u.name, closings: [3, 3, 2, 1][i], goal: meta, sold: vendido,
        /* Los leads que la cuenta le asignó en el mes: de ahí sale la conversión. */
        leads: [14, 16, 11, 9][i],
        difference: meta ? vendido - meta : null, progress: avance,
        state: avance === null ? 'sin-meta' : avance >= cifrasMes.green ? 'lograda' : avance >= cifrasMes.amber ? 'cerca' : 'apoyo',
      };
    });
    return {
      period,
      canEdit: true,
      commission: {kind: 'percent', amount: 10},
      missing: [],
      sales: ventas,
      mine: {closings: 2, sold: 3720},
      goal: {target: Number(cifrasMes.teamGoal) || null, progress: cifrasMes.teamGoal ? (ventas.total / cifrasMes.teamGoal) * 100 : null, missing: Math.max(0, Number(cifrasMes.teamGoal || 0) - ventas.total)},
      settings: {...cifrasMes},
      team: equipo,
      profitability: {
        sales: ventas.total, ads, adsFromAccount: 2340, adsOther: Number(cifrasMes.otherAds || 0), adsReason: null,
        commissions: comisiones, profit: ganancia, fixedCosts: Number(cifrasMes.fixedCosts || 0),
        net: ganancia - Number(cifrasMes.fixedCosts || 0),
        costPerClosing: ads / ventas.closings,
        returnPerHundred: (ventas.total / ads) * 100,
        marketingCost: ads + Number(cifrasMes.fixedCosts || 0),
        marginPerUnit: ganancia / ventas.total,
      },
    };
  };

  const MANUAL = `<h1>Manual de Ágora para el equipo</h1>
    <p>Esta es una versión reducida del manual, incluida en los datos de prueba. En el sistema instalado se sirve el manual completo desde <code>assets/manual/vendedores.html</code>.</p>
    <h2>Conversaciones</h2>
    <p>La bandeja reúne WhatsApp, Instagram, Messenger, correo y SMS en una sola lista. Lo que escribe el cliente entra a la izquierda; tu respuesta, a la derecha.</p>
    <ul><li><b>Sin respuesta:</b> las conversaciones donde lo último lo escribió el cliente, de la que más lleva esperando a la que menos.</li>
    <li><b>Asignar:</b> deja la conversación a nombre de quien la va a atender.</li>
    <li><b>¿Venta ganada?:</b> marca el cierre y pide el monto, que es lo que cuenta en el tablero.</li></ul>
    <h2>Tablero</h2>
    <p>Arriba, lo del día. Abajo, la rentabilidad del mes: lo vendido, lo que se va en publicidad y comisiones, y lo que queda.</p>
    <h2>Convenios</h2>
    <p>El área de Contratos crea el convenio de pago con el contacto ya elegido, lo envía a firmar y guarda el PDF firmado.</p>`;

  /* =====================================================================================
     Resumen del negocio, operación del día, anuncios y eficacia
     ===================================================================================== */
  const hoyYmd = ymd(ahora);
  const LOGO_ASOCIM = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 56"><rect width="220" height="56" rx="10" fill="%23282E49"/><text x="110" y="35" text-anchor="middle" font-family="Helvetica,Arial" font-size="22" font-weight="700" fill="%23FFFFFF" letter-spacing="3">ASOCIM</text></svg>'.replace(/%23/g, '#'));

  let espacio = {nombre: 'ASOCIM', logo: LOGO_ASOCIM, bloqueado: false};

  /* Las cifras de noviembre son las del tablero real; los meses de atrás, su historia. */
  const MRR_MES = {'2026-06': 0, '2026-07': 0, '2026-08': 0, '2026-09': 0, '2026-10': 285, '2026-11': 285, '2026-12': 285};
  const mesesAtras = (ym, n) => { const [y, m] = ym.split('-').map(Number); const out = []; for (let i = n - 1; i >= 0; i--) { const d = new Date(y, m - 1 - i, 1); out.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`); } return out; };
  const mrrDe = ym => MRR_MES[ym] ?? (ym > '2026-12' ? 285 : 0);
  function resumenDe(period) {
    const mrr = mrrDe(period), antes = mrrDe(mesesAtras(period, 2)[0]);
    const activos = mrr > 0 ? 1 : 0;
    return {
      period, mrr, mrrAnterior: antes, clientesActivos: activos, enPausa: 0,
      recaudado: period === mesActual ? 0 : mrr,
      arr: mrr * 12,
      caja: period === mesActual ? -783 : -763,
      churn: 0, churnPct: 0,
      egresos: 20, inversion: 0,
      serie: mesesAtras(period, 6).map(ym => ({ym, v: mrrDe(ym)})),
      espacios: [{id: 1, nombre: 'ASOCIM', logo: LOGO_ASOCIM, plan: 'Plan Operación', mrr, estado: activos ? 'activo' : 'pausa'}],
      superadmins: [{id: 1, nombre: 'Eduardo Bocaranda', correo: 'info@agoradigital.app'}],
      porVencer: [{cliente: 'ASOCIM', monto: mrr, vence: `${period}-30`, estado: 'pendiente'}],
    };
  }

  /* Las cifras del día salen de los tableros de la operación. */
  const diaOperacion = {
    conversacionesDia: 14, atendidas: 9,
    sinLeer: 5, sinLeerAyer: 14,
    sinLeerPorAsesor: [{nombre: 'Lisbella Montilla', n: 3}, {nombre: 'María Carvajal', n: 1}, {nombre: 'Rosangélica Peña', n: 1}],
    slaIncumplido: 4, slaIncumplidoAyer: 43, slaTolerancia: 3,
    slaPromedio: '3 min 12 s', slaPromedioSeg: 192, slaPromedioSegAyer: 420, slaMetaTexto: '5 min',
    peorRespuesta: '18 min', peorAsesor: 'María Carvajal',
    leads: 4, leadsAyer: 27,
    leadsPorFuente: [{fuente: 'Redes sociales', n: 4}],
    leadsPorUsuario: [{nombre: 'Lisbella Montilla', n: 2}, {nombre: 'María Carvajal', n: 1}, {nombre: 'Rosangélica Peña', n: 1}],
  };

  const adsDe = period => ({
    estado: 'ok', period,
    dia: 18.4, diaAyer: 23.15, mes: 412.75, presupuestoMes: 600,
    impresiones: 12480, clics: 311, conversiones: 9,
    costePorConversion: 45.86, costePorLead: 4.6, retornoPorCien: 69.1,
    actualizado: 'hace 20 minutos',
    campanas: [
      {nombre: 'Diplomado · Captación', gasto: 210.4, conversiones: 5},
      {nombre: 'Retargeting del sitio', gasto: 118.25, conversiones: 3},
      {nombre: 'Mensajes a WhatsApp', gasto: 84.1, conversiones: 1},
    ],
  });

  const eficaciaDe = userId => {
    const todos = [
      {nombre: 'Lisbella Montilla', cerradas: 4, valor: 6240, dias: 8},
      {nombre: 'María Carvajal', cerradas: 3, valor: 4320, dias: 11},
      {nombre: 'Rosangélica Peña', cerradas: 2, valor: 2700, dias: 16},
    ];
    const lista = userId ? todos.filter(u => u.nombre === userId) : todos;
    const cerradas = lista.reduce((a, u) => a + u.cerradas, 0);
    const valor = lista.reduce((a, u) => a + u.valor, 0);
    const dias = Math.round(lista.reduce((a, u) => a + u.dias * u.cerradas, 0) / Math.max(1, cerradas));
    return {
      pipelineId: '', userId,
      pipelines: [{id: 'pl_1', nombre: 'Admisiones 2026'}, {id: 'pl_2', nombre: 'Reinscripciones'}],
      usuarios: todos.map(u => ({id: u.nombre, nombre: u.nombre})),
      duracionPromedioDias: dias, duracionTexto: `${dias} días`, metaDias: 10,
      valorTotal: valor, cerradas, ticket: cerradas ? Math.round(valor / cerradas) : 0,
      velocidad: Math.round((valor / Math.max(1, dias)) * 30), tasaCierre: 27,
      porUsuario: lista,
    };
  };

  /* ---------- Tareas y recordatorios ---------- */
  const masDias = n => ymd(ahora + n * DAY);
  let recordatorios = {cv_1002: {at: masDias(1) + 'T09:00', nota: 'Quedó en confirmar con su esposo'}};
  let tareas = [
    {id: 'tk_rec_cv_1002', titulo: 'Escribirle a Luis Alberto Ramírez', detalle: 'Quedó en confirmar con su esposo', responsable: 'Lisbella Montilla', vence: masDias(1), hora: '09:00', estado: 'pendiente', origen: 'recordatorio', contacto: 'Luis Alberto Ramírez', contactId: 'ct_7002', conversationId: 'cv_1002'},
    {id: 'tk_101', titulo: 'Llamar a Mariana para cerrar la inscripción', detalle: 'Pidió el convenio por WhatsApp', responsable: 'Lisbella Montilla', vence: hoyYmd, hora: '14:30', estado: 'pendiente', origen: 'recordatorio', contacto: 'Mariana Pérez Alvarado', contactId: 'ct_7001', conversationId: 'cv_1001'},
    {id: 'tk_102', titulo: 'Enviar el convenio a Carla Sofía', detalle: 'Ya pasó el comprobante', responsable: 'María Carvajal', vence: hoyYmd, hora: '16:00', estado: 'pendiente', origen: 'convenio', contacto: 'Carla Sofía Montes', contactId: 'ct_7003', conversationId: 'cv_1003'},
    {id: 'tk_103', titulo: 'Revisar los leads sin asignar de ayer', detalle: '', responsable: 'Rosangélica Peña', vence: ymd(ahora - DAY), hora: '09:00', estado: 'pendiente', origen: 'sistema', contacto: null},
    {id: 'tk_104', titulo: 'Completar el monto de la venta de José Gregorio', detalle: 'Quedó ganada sin monto', responsable: 'María Carvajal', vence: ymd(ahora - 2 * DAY), hora: '10:00', estado: 'pendiente', origen: 'sistema', contacto: 'José Gregorio Díaz', contactId: 'ct_7004'},
    {id: 'tk_105', titulo: 'Seguimiento a Andreína sobre horarios', detalle: 'Preguntó por los sábados', responsable: 'Lisbella Montilla', vence: masDias(3), hora: '11:00', estado: 'pendiente', origen: 'recordatorio', contacto: 'Andreína Castillo', contactId: 'ct_7005', conversationId: 'cv_1005'},
    {id: 'tk_106', titulo: 'Confirmar el pago de Pedro Luis', detalle: '', responsable: 'María Carvajal', vence: ymd(ahora - DAY), hora: '15:00', estado: 'hecha', origen: 'manual', contacto: 'Pedro Luis Hernández', contactId: 'ct_7006'},
    {id: 'tk_107', titulo: 'Cargar las fotos nuevas del manual', detalle: '', responsable: 'Eduardo Bocaranda', vence: masDias(5), hora: '08:00', estado: 'pendiente', origen: 'manual', contacto: null},
  ];

  /* ---------- Auditoría ---------- */
  const auditoria = [
    {id: 'a1', at: isoStamp(ahora - 12 * 60000), actor: 'Lisbella Montilla', rol: 'Ejecutivo', accion: 'edito', accionTexto: 'Editó la ficha', modulo: 'contacto', objeto: 'Ficha del contacto', contacto: 'Mariana Pérez Alvarado', contactId: 'ct_7001', dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema', antes: {telefono: '+58 412 1122334'}, despues: {telefono: '+58 412 1122999'}},
    {id: 'a2', at: isoStamp(ahora - 48 * 60000), actor: 'María Carvajal', rol: 'Ejecutivo', accion: 'envio', accionTexto: 'Envió un mensaje', modulo: 'conversacion', objeto: 'WhatsApp', contacto: 'Carla Sofía Montes', contactId: 'ct_7003', dispositivo: 'App Android', ip: '190.202.14.21', origen: 'sistema'},
    {id: 'a3', at: isoStamp(ahora - 95 * 60000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'creo', accionTexto: 'Creó un convenio', modulo: 'convenio', objeto: 'Convenio v1', contacto: 'Andreína Castillo', contactId: 'ct_7005', dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema'},
    {id: 'a4', at: isoStamp(ahora - 3 * 3600000), actor: 'Rosangélica Peña', rol: 'Ejecutivo', accion: 'asigno', accionTexto: 'Reasignó la conversación', modulo: 'conversacion', objeto: 'De Rosangélica a Lisbella', contacto: 'José Gregorio Díaz', contactId: 'ct_7004', dispositivo: 'Chrome · macOS', ip: '190.202.14.33', origen: 'sistema'},
    {id: 'a5', at: isoStamp(ahora - 5 * 3600000), actor: 'Sincronización', rol: 'Sistema', accion: 'creo', accionTexto: 'Importó un contacto', modulo: 'contacto', objeto: 'Alta automática', contacto: 'Yoselin Guerrero', contactId: 'ct_7007', dispositivo: 'Servidor', ip: '', origen: 'ghl'},
    {id: 'a6', at: isoStamp(ahora - 8 * 3600000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'edito', accionTexto: 'Cambió la comisión', modulo: 'ajuste', objeto: 'ASOCIM · Admisiones', contacto: null, dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema', antes: {comision: '8 %'}, despues: {comision: '10 %'}},
    {id: 'a7', at: isoStamp(ahora - 26 * 3600000), actor: 'Lisbella Montilla', rol: 'Ejecutivo', accion: 'entro', accionTexto: 'Entró al sistema', modulo: 'sesion', objeto: 'Código por correo', contacto: null, dispositivo: 'App Android', ip: '190.202.14.21', origen: 'sistema'},
    {id: 'a8', at: isoStamp(ahora - 28 * 3600000), actor: 'María Carvajal', rol: 'Ejecutivo', accion: 'exporto', accionTexto: 'Exportó contactos', modulo: 'contacto', objeto: '48 fichas', contacto: null, dispositivo: 'Chrome · Windows', ip: '190.202.14.44', origen: 'sistema'},
    {id: 'a9', at: isoStamp(ahora - 32 * 3600000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'firmo', accionTexto: 'Registró una firma', modulo: 'convenio', objeto: 'Convenio v1 firmado', contacto: 'Mariana Pérez Alvarado', contactId: 'ct_7001', dispositivo: 'Servidor', ip: '', origen: 'sistema'},
    {id: 'a10', at: isoStamp(ahora - 50 * 3600000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'elimino', accionTexto: 'Eliminó un borrador', modulo: 'convenio', objeto: 'Borrador v1', contacto: 'Wilmer Antonio Salas', contactId: 'ct_7009', dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema'},
    {id: 'a11', at: isoStamp(ahora - 72 * 3600000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'creo', accionTexto: 'Agregó una persona', modulo: 'usuario', objeto: 'Rosangélica Peña · Ejecutivo', contacto: null, dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema'},
    {id: 'a12', at: isoStamp(ahora - 96 * 3600000), actor: 'Eduardo Bocaranda', rol: 'SuperAdmin', accion: 'bloqueo', accionTexto: 'Bloqueó el espacio', modulo: 'ajuste', objeto: 'Mantenimiento de 20 minutos', contacto: null, dispositivo: 'Chrome · Windows', ip: '190.202.14.8', origen: 'sistema'},
  ];

  /* ---------- Usuarios del sistema ---------- */
  let usuariosSistema = [
    {id: 'us_1', nombre: 'Eduardo Bocaranda', correo: 'info@agoradigital.app', rol: 'SUPERADMIN', estado: 'activo', origen: 'sistema', ultimoAcceso: isoStamp(ahora - 9 * 60000), yo: true},
    {id: 'us_2', nombre: 'Rosa Natalia Ortega', correo: 'rortega@asocim.org', rol: 'ADMIN', estado: 'activo', origen: 'contratos', ultimoAcceso: isoStamp(ahora - 2 * 3600000)},
    {id: 'us_3', nombre: 'Lisbella Montilla', correo: 'lmontilla@asocim.org', rol: 'EJECUTIVO', estado: 'activo', origen: 'ghl', ultimoAcceso: isoStamp(ahora - 20 * 60000)},
    {id: 'us_4', nombre: 'María Carvajal', correo: 'mcarvajal@asocim.org', rol: 'EJECUTIVO', estado: 'activo', origen: 'ghl', ultimoAcceso: isoStamp(ahora - 55 * 60000)},
    {id: 'us_5', nombre: 'Rosangélica Peña', correo: 'rpena@asocim.org', rol: 'EJECUTIVO', estado: 'activo', origen: 'ghl', ultimoAcceso: isoStamp(ahora - 4 * 3600000)},
    {id: 'us_6', nombre: 'Daniel Figueroa', correo: 'dfigueroa@asocim.org', rol: 'SUPERVISOR', estado: 'activo', origen: 'contratos', ultimoAcceso: isoStamp(ahora - 26 * 3600000)},
    {id: 'us_7', nombre: 'Marisol Vera', correo: 'mvera@asocim.org', rol: 'CONSULTA', estado: 'inactivo', origen: 'contratos', ultimoAcceso: isoStamp(ahora - 40 * DAY)},
  ];

  /* =====================================================================================
     Las rutas
     ===================================================================================== */
  const ok = d => ({status: 200, body: d});
  const err = (m, status = 400, code) => ({status, body: {error: m, code}});

  const RUTAS = [
    /* ---------- Contratos ---------- */
    ['GET', /^yo$/, () => ok({usuario: yo})],
    ['POST', /^login$/, () => ok({usuario: yo})],
    ['POST', /^logout$/, () => ok({ok: true})],
    ['POST', /^clave$/, () => ok({ok: true})],
    ['GET', /^contratos$/, () => ok({contratos})],
    ['GET', /^contratos\/([a-f0-9]{24})$/, m => {
      const row = contratos.find(c => c.uid === m[1]);
      return row ? ok(detalleDe(row)) : err('Ese convenio no existe.', 404);
    }],
    ['POST', /^contratos\/calculo$/, (m, body) => {
      const cuota = Number(String(body.cuota).replace(',', '.')) || 0, meses = Number(body.meses) || 0, porMes = Number(body.cuotas_por_mes) || 1;
      const desde = new Date(Number(body.anio), Number(body.mes) - 1, 1);
      const cuotas = cuotasDe(cuota, meses, desde, porMes);
      const precio = cuota * meses;
      return ok({precio_curso: precio.toFixed(2), cargos: [], total_a_pagar: precio.toFixed(2), cuotas});
    }],
    ['POST', /^contratos$/, (m, body) => {
      const nuevo = {uid: nuevoUid(), cliente: body.cliente?.nombre || 'Sin nombre', correo: body.cliente?.correo || '', estado: 'BORRADOR', version: 1, creado_en: utcStamp(Date.now())};
      contratos = [nuevo, ...contratos];
      eventos = [{tipo: 'CREADO', cliente: nuevo.cliente, uid: nuevo.uid, creado_en: nuevo.creado_en, detalle: {origen: 'ghl'}}, ...eventos];
      return ok({uid: nuevo.uid});
    }],
    ['POST', /^contratos\/([a-f0-9]{24})\/enviar$/, m => {
      const row = contratos.find(c => c.uid === m[1]); if (row) row.estado = 'ENVIADO';
      eventos = [{tipo: 'ENVIADO', cliente: row?.cliente, uid: m[1], creado_en: utcStamp(Date.now()), detalle: {version: row?.version}}, ...eventos];
      return ok({enlace: 'https://contratos.asocim.org/firmar/' + m[1].slice(0, 20), vence: utcStamp(Date.now() + 7 * DAY)});
    }],
    ['POST', /^contratos\/([a-f0-9]{24})\/enlace$/, m => ok({enlace: 'https://contratos.asocim.org/firmar/' + m[1].slice(4, 24), vence: utcStamp(Date.now() + 7 * DAY)})],
    ['POST', /^contratos\/([a-f0-9]{24})\/revocar$/, m => {
      const row = contratos.find(c => c.uid === m[1]); if (row) row.estado = 'REVOCADA';
      return ok({ok: true});
    }],
    ['POST', /^contratos\/([a-f0-9]{24})\/editar$/, m => {
      const row = contratos.find(c => c.uid === m[1]);
      if (row && row.estado !== 'BORRADOR') { row.version += 1; row.estado = 'BORRADOR'; }
      return ok({version: row?.version || 1});
    }],
    ['POST', /^contratos\/([a-f0-9]{24})\/cliente$/, (m, body) => {
      const row = contratos.find(c => c.uid === m[1]);
      if (row) { row.cliente = body.nombre || row.cliente; row.correo = body.correo || row.correo; }
      return ok({ok: true});
    }],
    ['DELETE', /^contratos\/([a-f0-9]{24})$/, m => { contratos = contratos.filter(c => c.uid !== m[1]); return ok({ok: true}); }],
    ['GET', /^usuarios$/, () => ok({usuarios})],
    ['POST', /^usuarios$/, (m, body) => { usuarios = [...usuarios, {id: usuarios.length + 1, nombre: body.nombre, correo: body.correo, rol: body.rol, activo: 1}]; return ok({ok: true}); }],
    ['POST', /^usuarios\/rol$/, (m, body) => { const u = usuarios.find(x => x.id === body.id); if (u) u.rol = body.rol; return ok({ok: true}); }],
    ['POST', /^usuarios\/clave$/, () => ok({ok: true})],
    ['POST', /^usuarios\/activar$/, (m, body) => { const u = usuarios.find(x => x.id === body.id); if (u) u.activo = 1; return ok({ok: true}); }],
    ['POST', /^usuarios\/desactivar$/, (m, body) => { const u = usuarios.find(x => x.id === body.id); if (u) u.activo = 0; return ok({ok: true}); }],
    ['GET', /^registro$/, () => ok({eventos})],
    ['POST', /^ghl\/contactos\/buscar$/, (m, body) => {
      const q = String(body.consulta || '').toLowerCase();
      const r = CONTACTOS_GHL.filter(c => (c.nombre + ' ' + c.correo + ' ' + c.telefono).toLowerCase().includes(q));
      return ok({contactos: r, aviso: r.length ? '' : 'No hay contactos con esa búsqueda en la subcuenta.'});
    }],

    /* ---------- Ágora ---------- */
    ['GET', /^status$/, () => ok({maintenance: false})],
    ['GET', /^health$/, () => ok({status: 'ok'})],
    ['GET', /^me$/, () => ok(agoraMe)],
    ['POST', /^team-login\/request$/, () => ok({sent: true})],
    ['POST', /^team-login\/verify$/, () => ok({ok: true})],
    ['GET', /^workspace\/connections$/, () => ok({items: conexiones.map(c => ({id: c.id, name: c.name, currency: c.currency})), reason: null})],
    ['GET', /^workspace\/dashboard$/, (m, b, q) => ok(tablero(q.get('from'), q.get('to')))],
    ['GET', /^workspace\/board-month$/, (m, b, q) => ok(mesBloque(q.get('period') || mesActual))],
    ['POST', /^workspace\/board-month$/, (m, body) => { cifrasMes = {...cifrasMes, ...body, goals: {...cifrasMes.goals, ...(body.goals || {})}}; return ok({saved: true}); }],
    ['GET', /^workspace\/self$/, () => ok({options: EQUIPO, linked: 'us_01', detected: 'us_01'})],
    ['PUT', /^workspace\/self$/, () => ok({ok: true})],
    ['GET', /^workspace\/won-alert$/, () => ok({count: 0, escalate: false, canEdit: true, team: {missing: 0, bySeller: []}})],
    ['GET', /^workspace\/pulse$/, () => ok({token: 'demo-token-1', unread: conversaciones.reduce((s, c) => s + c.unreadCount, 0), reason: null, retryAfter: 0})],
    ['GET', /^workspace\/inbox$/, (m, b, q) => {
      let items = conversaciones;
      if (q.get('status') === 'unread') items = items.filter(c => c.unreadCount > 0);
      if (q.get('direction') === 'inbound') items = items.filter(c => c.lastMessageDirection !== 'outbound');
      const query = (q.get('query') || '').toLowerCase();
      if (query) items = items.filter(c => (c.contactName + ' ' + c.lastMessageBody).toLowerCase().includes(query));
      return ok({
        items, total: conversaciones.length, unread: conversaciones.reduce((s, c) => s + c.unreadCount, 0),
        limit: Number(q.get('limit')) || 20, hasMore: false, nextCursor: null,
        channels: {TYPE_WHATSAPP: 'WhatsApp', TYPE_INSTAGRAM: 'Instagram', TYPE_EMAIL: 'Email', TYPE_SMS: 'SMS', TYPE_FACEBOOK: 'Messenger'},
        reminders: recordatorios,
        restricted: false, partial: false, syncIntervalSeconds: 300, syncedAt: isoStamp(ahora), state: {},
      });
    }],
    ['GET', /^workspace\/conversation$/, (m, b, q) => {
      const c = conversaciones.find(x => x.id === q.get('conversationId'));
      return c ? ok({conversation: c}) : err('Esa conversación ya no está disponible.', 404);
    }],
    ['GET', /^workspace\/messages$/, (m, b, q) => ok({
      items: mensajesDe(q.get('conversationId')), hasMore: false, lastMessageId: null,
      channels: [{type: 'WhatsApp', label: 'WhatsApp', available: true, needsSubject: false}, {type: 'Email', label: 'Email', available: true, needsSubject: true}, {type: 'SMS', label: 'SMS', available: false, reason: 'needs_phone'}],
    })],
    ['POST', /^workspace\/send$/, (m, body, q) => {
      const c = conversaciones.find(x => x.id === q.get('conversationId'));
      if (c) { c.lastMessageBody = body.message || body.body || ''; c.lastMessageDirection = 'outbound'; c.lastMessageDate = isoStamp(Date.now()); }
      return ok({message: {id: 'nuevo_' + Date.now(), body: body.message || body.body || '', direction: 'outbound', messageType: 'TYPE_WHATSAPP', status: 'delivered', dateAdded: isoStamp(Date.now())}});
    }],
    ['POST', /^workspace\/read$/, (m, b, q) => { const c = conversaciones.find(x => x.id === q.get('conversationId')); if (c) c.unreadCount = 0; return ok({ok: true}); }],
    ['GET', /^workspace\/templates$/, () => ok({configured: false, items: [], error: ''})],
    ['GET', /^workspace\/assign$/, () => ok({assignees: EQUIPO, assignedTo: 'us_01'})],
    ['POST', /^workspace\/assign$/, (m, body) => ok({assignedTo: body.assignedTo || null, assignedName: EQUIPO.find(u => u.id === body.assignedTo)?.name || null, moved: 0})],
    ['GET', /^workspace\/contact$/, (m, b, q) => {
      const c = conversaciones.find(x => x.id === q.get('conversationId')) || conversaciones[0];
      const contacto = CONTACTOS_AG.find(x => x.id === c.contactId) || CONTACTOS_AG[0];
      return ok({contact: contacto, fields: [], assignees: EQUIPO, canEdit: true, notes: [], tasks: [], appointments: []});
    }],
    ['GET', /^workspace\/activity(\/.*)?$/, () => ok({items: [], notes: [], tasks: [], appointments: []})],
    ['POST', /^workspace\/activity(\/.*)?$/, () => ok({ok: true})],
    ['GET', /^workspace\/contacts$/, (m, b, q) => {
      const query = (q.get('query') || '').toLowerCase();
      const items = query ? CONTACTOS_AG.filter(c => (c.name + ' ' + c.email + ' ' + c.phone).toLowerCase().includes(query)) : CONTACTOS_AG;
      return ok({items, total: items.length, restricted: false, partial: false});
    }],
    ['GET', /^workspace\/record$/, (m, b, q) => {
      const c = CONTACTOS_AG.find(x => x.id === q.get('contactId')) || CONTACTOS_AG[0];
      return ok({contact: c, fields: [{id: 'cf_ced', name: 'Cédula', folder: 'Datos personales'}, {id: 'cf_pro', name: 'Programa de interés', folder: 'Admisión'}], assignees: EQUIPO, canEdit: true});
    }],
    ['POST', /^workspace\/record$/, () => ok({ok: true})],
    ['GET', /^workspace\/tags$/, () => ok({items: ['interesado', 'diplomado', 'convenio', 'firmado', 'seguimiento', 'instagram', 'referido', 'frío']})],
    ['GET', /^workspace\/contact-fields$/, () => ok({items: [], folders: []})],
    ['GET', /^workspace\/pipelines$/, () => ok({pipelines: EMBUDOS, assignees: EQUIPO})],
    ['GET', /^workspace\/board$/, (m, b, q) => {
      const pid = q.get('pipelineId') || 'pl_1';
      const embudo = EMBUDOS.find(p => p.id === pid) || EMBUDOS[0];
      const abiertas = oportunidades.filter(o => o.status === 'open' && o.pipelineId === 'pl_1');
      return ok({
        pipelines: EMBUDOS.map(p => ({id: p.id, name: p.name})), pipelineId: embudo.id,
        stages: embudo.stages.map(s => {
          const items = abiertas.filter(o => o.pipelineStageId === s.id);
          return {id: s.id, name: s.name, total: items.length, value: items.reduce((a, o) => a + o.monetaryValue, 0), items};
        }),
        total: abiertas.length, canEdit: true, restricted: false, partial: false,
      });
    }],
    ['GET', /^workspace\/opportunities$/, () => ok({items: oportunidades.slice(0, 2), pipelines: EMBUDOS, assignees: EQUIPO})],
    ['POST', /^workspace\/opportunity\/(new|edit|status)$/, (m, body, q) => {
      const o = oportunidades.find(x => x.id === q.get('opportunityId'));
      if (o) Object.assign(o, body);
      return ok({ok: true, opportunity: o || null});
    }],
    ['GET', /^workspace\/won$/, (m, b, q) => {
      const ganadas = oportunidades.filter(o => o.status === 'won');
      const items = ganadas.map(o => ({...o, value: o.monetaryValue, missing: !o.monetaryValue}));
      return ok({
        totals: {count: items.length, sum: items.reduce((s, o) => s + (o.value || 0), 0), missing: items.filter(o => o.missing).length},
        items, bySeller: EQUIPO.slice(0, 2).map((u, i) => ({id: u.id, name: u.name, count: [1, 1][i], missing: 0})),
        canSeeAll: true, canEdit: true, partial: false,
      });
    }],
    ['GET', /^workspace\/sync$/, () => ok({ok: true})],

    /* ---------- Conexiones (administración de Ágora) ---------- */
    ['GET', /^admin\/diagnostics$/, () => ok({ready: true})],
    ['GET', /^admin\/integrations$/, () => ok({
      items: conexiones,
      accessChannel: {connectionId: 1, ready: true},
      backup: {at: isoStamp(ahora - 0.6 * DAY), ok: true, encrypted: true},
    })],
    ['GET', /^admin\/announcements$/, () => ok({items: [{id: 1, title: 'Nuevos módulos disponibles', at: isoStamp(ahora - 2 * DAY), seen: 4, expiresAt: null}]})],
    ['POST', /^admin\/announcements$/, () => ok({id: 2})],
    ['DELETE', /^admin\/announcements\/\d+$/, () => ok({ok: true})],
    ['GET', /^devices$/, () => ok({
      items: [
        {label: 'Chrome · Windows', platform: 'web', created_at: utcStamp(ahora - 9 * DAY), last_seen_at: utcStamp(ahora - 0.02 * DAY), last_sent_at: utcStamp(ahora - 0.3 * DAY)},
        {label: 'Pixel 10a', platform: 'android', created_at: utcStamp(ahora - 4 * DAY), last_seen_at: utcStamp(ahora - 0.05 * DAY), last_sent_at: utcStamp(ahora - 0.4 * DAY)},
      ],
      browser: true, android: true,
      discovery: {at: isoStamp(ahora - 40000), via: 'cron'},
      delivery: {at: isoStamp(ahora - 38000), sent: 3, configured: true},
      queue: {sent: 42, pending: 0, failed: 0},
      externalCheck: null, externalCheckUse: null,
    })],
    ['POST', /^devices\/test$/, () => ok({results: [{label: 'Chrome · Windows', platform: 'web', result: 'sent'}]})],

    /* ---------- Resumen del negocio ---------- */
    ['GET', /^workspace\/resumen$/, (m, b, q) => ok(resumenDe(q.get('period') || mesActual))],

    /* ---------- Operación del día, anuncios y eficacia de ventas ---------- */
    ['GET', /^workspace\/dia$/, () => ok(diaOperacion)],
    ['GET', /^workspace\/ads$/, (m, b, q) => ok(adsDe(q.get('period') || mesActual))],
    ['GET', /^workspace\/eficacia$/, (m, b, q) => ok(eficaciaDe(q.get('userId') || ''))],

    /* ---------- Tareas ---------- */
    ['GET', /^workspace\/tareas$/, () => ok({items: tareas, resumen: {pendientes: tareas.filter(t => t.estado !== 'hecha').length, hechas: tareas.filter(t => t.estado === 'hecha').length}})],
    ['POST', /^workspace\/tareas$/, (m, body) => {
      tareas = [{id: 'tk_' + (900 + tareas.length), titulo: body.titulo, detalle: body.detalle || '', responsable: body.responsable || yo.nombre,
        vence: body.vence || hoyYmd, hora: body.hora || '', estado: 'pendiente', origen: body.origen || 'manual',
        contacto: body.contacto || null, contactId: body.contactId || null, conversationId: body.conversationId || null}, ...tareas];
      return ok({ok: true});
    }],
    ['POST', /^workspace\/tareas\/([a-z0-9_]+)\/estado$/, (m, body) => {
      const t = tareas.find(x => x.id === m[1]); if (t) t.estado = body.estado || 'hecha';
      return ok({ok: true});
    }],

    /* ---------- Recordatorios de seguimiento ---------- */
    ['POST', /^workspace\/reminders$/, (m, body, q) => {
      const id = q.get('conversationId');
      recordatorios[id] = {at: body.at, nota: body.nota || ''};
      const c = conversaciones.find(x => x.id === id);
      tareas = [{id: 'tk_rec_' + id, titulo: `Escribirle a ${c ? c.contactName : 'el contacto'}`, detalle: body.nota || 'Recordatorio puesto desde el chat',
        responsable: yo.nombre, vence: String(body.at).slice(0, 10), hora: String(body.at).slice(11, 16), estado: 'pendiente',
        origen: 'recordatorio', contacto: c ? c.contactName : null, contactId: body.contactId || null, conversationId: id},
        ...tareas.filter(t => t.id !== 'tk_rec_' + id)];
      return ok({at: body.at});
    }],
    ['DELETE', /^workspace\/reminders$/, (m, b, q) => {
      const id = q.get('conversationId');
      delete recordatorios[id];
      tareas = tareas.filter(t => t.id !== 'tk_rec_' + id);
      return ok({ok: true});
    }],

    /* ---------- Auditoría ---------- */
    ['GET', /^workspace\/auditoria$/, () => ok({items: auditoria, resumen: {total: auditoria.length}})],

    /* ---------- Usuarios y roles ---------- */
    ['GET', /^workspace\/usuarios$/, () => ok({items: usuariosSistema})],
    ['POST', /^workspace\/usuarios$/, (m, body) => {
      usuariosSistema = [...usuariosSistema, {id: 'us_n' + usuariosSistema.length, nombre: body.nombre, correo: body.correo, rol: body.rol || 'EJECUTIVO', estado: 'activo', origen: 'sistema', ultimoAcceso: null}];
      return ok({ok: true});
    }],
    ['POST', /^workspace\/usuarios\/rol$/, (m, body) => { const u = usuariosSistema.find(x => String(x.id) === String(body.id)); if (u) u.rol = body.rol; return ok({ok: true}); }],
    ['POST', /^workspace\/usuarios\/estado$/, (m, body) => { const u = usuariosSistema.find(x => String(x.id) === String(body.id)); if (u) u.estado = body.estado; return ok({ok: true}); }],

    /* ---------- Identidad del espacio ---------- */
    ['GET', /^workspace\/branding$/, () => ok(espacio)],
    ['POST', /^workspace\/branding$/, (m, body) => { espacio = {...espacio, nombre: body.nombre ?? espacio.nombre, logo: body.logo ?? null}; return ok(espacio); }],
    ['POST', /^admin\/maintenance$/, (m, body) => { espacio.bloqueado = body.on === true; return ok({maintenance: espacio.bloqueado}); }],

    ['GET', /^admin\/integrations\/\d+\/commission$/, () => ok({current: {kind: 'percent', amount: 10, since: mesActual}, history: [{kind: 'percent', amount: 8, since: '2026-01'}]})],
  ];

  /* =====================================================================================
     El interceptor
     ===================================================================================== */
  const responder = (body, status = 200) => new Response(JSON.stringify(body), {status, headers: {'Content-Type': 'application/json'}});

  window.fetch = async function (input, init = {}) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const metodo = (init.method || (input && input.method) || 'GET').toUpperCase();

    /* El manual de Ágora. */
    if (/manual\/vendedores\.html$/.test(url)) return new Response(MANUAL, {status: 200, headers: {'Content-Type': 'text/html'}});

    const m = String(url).match(/\/api\/(.*)$/);
    if (!m) return nativeFetch(input, init);

    const [ruta, consulta = ''] = m[1].split('?');
    const q = new URLSearchParams(consulta);
    let body = {};
    try { body = init.body ? JSON.parse(init.body) : {}; } catch { body = {}; }

    for (const [verbo, patron, fn] of RUTAS) {
      if (verbo !== metodo) continue;
      const hit = ruta.match(patron);
      if (!hit) continue;
      await new Promise(r => setTimeout(r, 90 + Math.random() * 160));   // un retardo pequeño, para ver los esqueletos
      const {status, body: salida} = fn(hit, body, q);
      return responder(salida, status);
    }
    /* Una ruta que los datos de prueba no cubren: se contesta vacío, para que el módulo
       siga su camino en vez de romperse. */
    return responder({items: [], total: 0, ok: true, demo: 'ruta no cubierta: ' + ruta}, 200);
  };

  window.__DEMO__ = true;
  console.info('[demo] Datos de prueba activos. Ninguna llamada sale a la red.');
})();
