/* =====================================================================================
   Agora Digital App · configuración
   -------------------------------------------------------------------------------------
   Lo único que hay que tocar al instalar. Cada sistema conserva su servidor y sus rutas;
   aquí sólo se dice dónde está cada uno.

   · Los dos en el mismo dominio (lo habitual si Ágora y el panel comparten servidor):
       window.AGORA_API     = '/api/';
       window.CONTRATOS_API = '/api/';
     Ojo: si de verdad comparten servidor, las rutas tienen que convivir sin pisarse
     (Ágora usa /api/me, /api/workspace/…, /api/admin/…; el panel usa /api/yo,
     /api/contratos, /api/usuarios, /api/registro, /api/ghl/…).

   · Cada uno en su dominio (lo recomendado mientras sean dos servidores):
       window.AGORA_API     = 'https://agora.tudominio.com/api/';
       window.CONTRATOS_API = 'https://contratos.tudominio.com/api/';
     Las sesiones van por cookie, así que el servidor de cada sistema debe permitir el
     origen de esta página (CORS con credenciales) y marcar sus cookies con
     SameSite=None; Secure. Si no se puede, deja los dos en el mismo dominio detrás de
     un proxy: /agora/api/ y /contratos/api/.

   Las barras finales importan: la base se pega tal cual delante de la ruta.
   ===================================================================================== */
window.AGORA_API = '/api/';
window.CONTRATOS_API = '/api/';

/* Carpeta de los archivos de esta página (logos del aviso de mantenimiento y manual). */
window.AGORA_ASSETS = '/assets/';
/* El PDF del manual se sube una vez y las actualizaciones no lo tocan. */
window.AGORA_MANUAL_PDF = '/assets/manual-vendedores.pdf';

/* Vigilancia de la pantalla de mantenimiento de Ágora (déjala en true en producción). */
window.AGORA_MAINTENANCE = true;
