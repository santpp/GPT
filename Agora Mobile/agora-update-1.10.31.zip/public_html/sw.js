const CACHE="agora-shell-1.10.31-b68c1472de6a2a1f";
const SHELL=["/", "/conexiones.html", "/manifest.webmanifest", "/assets/release-b68c1472de6a2a1f/agora-logo.png", "/assets/release-b68c1472de6a2a1f/agora-logo.svg", "/assets/release-b68c1472de6a2a1f/agora-mark.png", "/assets/release-b68c1472de6a2a1f/agora-mark.svg", "/assets/release-b68c1472de6a2a1f/announce.js", "/assets/release-b68c1472de6a2a1f/app.css", "/assets/release-b68c1472de6a2a1f/app.js", "/assets/release-b68c1472de6a2a1f/board.js", "/assets/release-b68c1472de6a2a1f/consumption.js", "/assets/release-b68c1472de6a2a1f/contact-editor.js", "/assets/release-b68c1472de6a2a1f/contacts.js", "/assets/release-b68c1472de6a2a1f/contracts.js", "/assets/release-b68c1472de6a2a1f/dark.css", "/assets/release-b68c1472de6a2a1f/dashboard.js", "/assets/release-b68c1472de6a2a1f/fonts/LEEME.txt", "/assets/release-b68c1472de6a2a1f/format.js", "/assets/release-b68c1472de6a2a1f/help.js", "/assets/release-b68c1472de6a2a1f/icon.svg", "/assets/release-b68c1472de6a2a1f/icons/apple-touch-icon.png", "/assets/release-b68c1472de6a2a1f/icons/badge-96.png", "/assets/release-b68c1472de6a2a1f/icons/contratos.svg", "/assets/release-b68c1472de6a2a1f/icons/favicon-180.png", "/assets/release-b68c1472de6a2a1f/icons/favicon-32.png", "/assets/release-b68c1472de6a2a1f/icons/favicon-48.png", "/assets/release-b68c1472de6a2a1f/icons/icon-192.png", "/assets/release-b68c1472de6a2a1f/icons/icon-512.png", "/assets/release-b68c1472de6a2a1f/icons/icon-maskable-512.png", "/assets/release-b68c1472de6a2a1f/integrations.js", "/assets/release-b68c1472de6a2a1f/layout.css", "/assets/release-b68c1472de6a2a1f/live-inbox.js", "/assets/release-b68c1472de6a2a1f/maintenance.js", "/assets/release-b68c1472de6a2a1f/manual/img/01-conversaciones.png", "/assets/release-b68c1472de6a2a1f/manual/img/02-canal.png", "/assets/release-b68c1472de6a2a1f/manual/img/03-sin-respuesta.png", "/assets/release-b68c1472de6a2a1f/manual/img/04-ficha.png", "/assets/release-b68c1472de6a2a1f/manual/img/05-ganadas.png", "/assets/release-b68c1472de6a2a1f/manual/img/06-alerta.png", "/assets/release-b68c1472de6a2a1f/manual/img/07-tablero.png", "/assets/release-b68c1472de6a2a1f/manual/img/08-ayuda.png", "/assets/release-b68c1472de6a2a1f/manual/img/09-perfil.png", "/assets/release-b68c1472de6a2a1f/manual/img/10-embudos.png", "/assets/release-b68c1472de6a2a1f/manual/vendedores.html", "/assets/release-b68c1472de6a2a1f/message-view.js", "/assets/release-b68c1472de6a2a1f/native.js", "/assets/release-b68c1472de6a2a1f/opportunity-editor.js", "/assets/release-b68c1472de6a2a1f/passkeys.js", "/assets/release-b68c1472de6a2a1f/push.js", "/assets/release-b68c1472de6a2a1f/skeleton.js", "/assets/release-b68c1472de6a2a1f/text.css", "/assets/release-b68c1472de6a2a1f/theme.js", "/assets/release-b68c1472de6a2a1f/tour.js", "/assets/release-b68c1472de6a2a1f/won-alert.js", "/assets/release-b68c1472de6a2a1f/won.js", "/assets/release-b68c1472de6a2a1f/workspace.js"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('message',e=>{
 if(e.data?.type==='ACTIVATE')self.skipWaiting();
 // La app pregunta qué versión atiende los avisos, para notar si se quedó atrás.
 if(e.data?.type==='VERSION')e.ports?.[0]?.postMessage({cache:CACHE});
});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('agora-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
// A notice arrives for a conversation: it is shown, and opening it goes to that
// conversation. Nothing of the message is stored by the worker.
self.addEventListener('push',event=>{
 let data={};
 try{data=event.data?event.data.json():{}}catch{data={}}
 // El aviso trae el título y el texto arriba; los datos de navegación van aparte.
 // Antes se leían los datos como si fueran el aviso y se perdía quién escribía.
 const source=data.notification&&typeof data.notification==='object'?data.notification:data;
 const title=typeof source.title==='string'&&source.title?source.title:'Ágora';
 const body=typeof source.body==='string'&&source.body?source.body:'Tienes un mensaje nuevo.';
 const path=typeof data.data?.path==='string'?data.data.path:'/bandeja';
 const safe=/^\/[A-Za-z0-9/_-]{0,120}$/.test(path)?path:'/bandeja';
 const unread=Number.isFinite(Number(data.unread))?Math.max(0,Number(data.unread)):null;
 const connection=/^\d{1,12}$/.test(String(data.data?.connectionId??''))?String(data.data.connectionId):'';
 event.waitUntil(Promise.all([
  self.registration.showNotification(title,{body,data:{path:safe,connection},tag:safe,renotify:true,icon:'/assets/release-b68c1472de6a2a1f/icons/icon-192.png',badge:'/assets/release-b68c1472de6a2a1f/icons/badge-96.png'}),
  // El número del icono donde el sistema lo permite (iPhone instalada, escritorio).
  unread!==null&&self.navigator?.setAppBadge?(unread>0?self.navigator.setAppBadge(unread):self.navigator.clearAppBadge()).catch(()=>{}):Promise.resolve(),
 ]));
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 const path=event.notification.data?.path||'/bandeja';
 const connection=/^\d{1,12}$/.test(String(event.notification.data?.connection??''))?event.notification.data.connection:'';
 // La dirección completa de Ágora, no sólo la ruta: así el sistema sabe a qué
 // app instalada pertenece y no la abre en una pestaña de Chrome.
 // Con la subcuenta del aviso, para abrir esa conversación y no otra.
 const target=new URL(path,self.location.origin).href+(connection&&path.startsWith('/conversations/')?'?c='+connection:'');
 event.waitUntil((async()=>{
  const open=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  const mine=open.filter(client=>new URL(client.url).origin===self.location.origin);
  // Si la app ya está abierta, se reutiliza esa ventana, en primer plano.
  for(const client of mine){
   try{const focused=await client.focus();await (focused||client).navigate(target);return}catch(error){}
  }
  await self.clients.openWindow(target);
 })());
});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(u.pathname).then(hit=>hit||caches.match('/'))));return}
 if(SHELL.includes(u.pathname))e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
});
